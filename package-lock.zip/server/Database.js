
const { Pool } = require("pg");

const pool = new Pool({
  user: "postgres",
  password: "1234",
  host: "localhost",
  port: 5433,
  database: "pms",
});

// const createTblQry = `CREATE TABLE LOGIN (
// USER_ID SERIAL PRIMARY KEY,
// FIRSTNAME VARCHAR(200) NOT NULL,
// LASTNAME VARCHAR(200) NOT NULL,
// EMAIL VARCHAR(200) NOT NULL,
// PASSWORD VARCHAR (200) UNIQUE NOT NULL,


// pool
//   .query(createTblQry)
//   .then((response) => {
//     console.log("Table created");

//     console.log(response);
//   })
//   .catch((err) => {
//     console.log(err);
//   });
module.exports = pool;

// const express = require("express");
// const cors = require("cors");
// const bodyParser = require("body-parser");
// const bcrypt = require("bcrypt");
// const { Pool } = require("pg");

// const app = express();
// const PORT = process.env.PORT || 4000;

// const pool = new Pool({
//   user: "postgres",
//   password: "1234",
//   host: "localhost",
//   port: 5433,
//   database: "pms",
// });

// // Middleware
// app.use(express.json());
// app.use(cors({ origin: "http://localhost:3000" }));
// app.use(bodyParser.json({ type: "application/json" }));
// app.use(bodyParser.urlencoded({ extended: true }));

// // Login endpoint
// app.post("/login", async (req, res) => {
//   console.log("Login request received:", req.body);
//   const { UserName, Password } = req.body;

//   try {
//     // Check if user exists
//     const userQuery = "SELECT * FROM REGISTRATION WHERE EMAIL = $1";
//     const user = await pool.query(userQuery, [UserName]);

//     if (user.rows.length === 0) {
//       return res.status(401).json({ 
//         success: false, 
//         message: "Invalid email or password" 
//       });
//     }

//     // Verify password
//     const validPassword = await bcrypt.compare(Password, user.rows[0].password);
    
//     if (!validPassword) {
//       return res.status(401).json({ 
//         success: false, 
//         message: "Invalid email or password" 
//       });
//     }

//     // Return success with user info
//     res.json({
//       success: true,
//       message: "Login successful",
//       user: {
//         firstName: user.rows[0].firstname,
//         lastName: user.rows[0].lastname,
//         email: user.rows[0].email
//       }
//     });

//   } catch (err) {
//     console.error("Login error:", err);
//     res.status(500).json({ 
//       success: false, 
//       message: "Server error occurred" 
//     });
//   }
// });

// // Registration endpoint (keep your existing registration endpoint)
// app.post("/register", async (req, res) => {
//   console.log("Received request:", req.method, req.url);
//   console.log("Request body:", req.body);
  
//   const { FIRSTNAME, LASTNAME, EMAIL, PASSWORD } = req.body;
  
//   try {
//     // Check if user already exists
//     const existingUser = await pool.query(
//       "SELECT * FROM REGISTRATION WHERE EMAIL = $1",
//       [EMAIL]
//     );

//     if (existingUser.rows.length > 0) {
//       return res.status(400).json({ 
//         success: false, 
//         message: "User already exists" 
//       });
//     }

//     const hashedPassword = await bcrypt.hash(PASSWORD, 10);
    
//     const insertSTMT = `INSERT INTO REGISTRATION (FIRSTNAME, LASTNAME, EMAIL, PASSWORD) 
//                        VALUES ($1, $2, $3, $4)`;
//     await pool.query(insertSTMT, [FIRSTNAME, LASTNAME, EMAIL, hashedPassword]);
    
//     res.json({ success: true, message: "User registered successfully" });
//   } catch (err) {
//     console.error("Error saving data:", err);
//     res.status(500).json({ error: "Database error occurred", details: err });
//   }
// });

// app.listen(PORT, () => console.log(`Server running on localhost:${PORT}`));