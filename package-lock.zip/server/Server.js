const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const { Pool } = require("pg");
const fileUpload = require("express-fileupload");

const pool = new Pool({
  user: "postgres",
  password: "1234",
  host: "localhost",
  port: 5433,
  database: "pms",
});

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(express.json());
app.use(cors({ origin: "http://localhost:3000" }));
app.use(bodyParser.json({ type: "application/json" }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  fileUpload({
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    abortOnLimit: true,
  })
);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Error details:", err.message);
  console.error("Stack trace:", err.stack);
  res.status(500).json({
    success: false,
    message: "Something broke!",
  });
});

// Health check endpoint
app.get("/", async (req, res) => {
  try {
    const result = await pool.query("SELECT 1");
    res.json({ success: true, message: "Database connected" });
  } catch (err) {
    console.error("Database connection error:", err);
    res.status(500).json({ error: "Database connection failed", details: err });
  }
});
// Registration EndPoint

app.post("/register", async (req, res) => {
  try {
    const { FIRSTNAME, LASTNAME, EMAIL, PASSWORD } = req.body;

    // Input validation
    if (
      !FIRSTNAME?.trim() ||
      !LASTNAME?.trim() ||
      !EMAIL?.trim() ||
      !PASSWORD
    ) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    // Check if email is already registered
    const existingUser = await pool.query(
      "SELECT 1 FROM REGISTRATION WHERE LOWER(EMAIL) = LOWER($1)",
      [EMAIL.trim()]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: "Email already registered",
      });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(PASSWORD, 10);

    // Insert new user into the database
    const result = await pool.query(
      `INSERT INTO REGISTRATION (FIRSTNAME, LASTNAME, EMAIL, PASSWORD) 
       VALUES ($1, $2, $3, $4) 
       RETURNING ID, FIRSTNAME, LASTNAME, EMAIL`,
      [
        FIRSTNAME.trim(),
        LASTNAME.trim(),
        EMAIL.toLowerCase().trim(),
        hashedPassword,
      ]
    );

    // Respond with the new user details
    res.status(201).json({
      success: true,
      message: "User registered successfully",
      user: {
        id: result.rows[0].id,
        firstName: result.rows[0].firstname,
        lastName: result.rows[0].lastname,
        email: result.rows[0].email,
      },
    });
  } catch (error) {
    console.error("Registration error:", error);

    // Handle unique constraint violation
    if (error.code === "23505") {
      return res.status(409).json({
        success: false,
        message: "Email already registered",
      });
    }

    // Handle other errors
    return res.status(500).json({
      success: false,
      message: "Server error during registration",
    });
  }
});

// 2. Login Endpoint Fix
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email?.trim() || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
        error: "MISSING_FIELDS",
      });
    }

    const userQuery =
      "SELECT * FROM REGISTRATION WHERE LOWER(EMAIL) = LOWER($1)";
    const user = await pool.query(userQuery, [email.trim()]);

    if (user.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
        error: "INVALID_CREDENTIALS",
      });
    }

    const validPassword = await bcrypt.compare(password, user.rows[0].password);

    if (!validPassword) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
        error: "INVALID_CREDENTIALS",
      });
    }

    return res.json({
      success: true,
      message: "Login successful",
      user: {
        id: user.rows[0].id,
        firstName: user.rows[0].firstname,
        lastName: user.rows[0].lastname,
        email: user.rows[0].email,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error during login",
      error: "SERVER_ERROR",
    });
  }
});

// Department endpoints
app.get("/departments", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM departments");
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.post("/departments", async (req, res) => {
  const { name } = req.body;
  try {
    await pool.query("INSERT INTO departments (name) VALUES ($1)", [name]);
    res.status(201).send("Department added");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.put("/departments/:id", async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    await pool.query("UPDATE departments SET name = $1 WHERE id = $2", [
      name,
      id,
    ]);
    res.send("Department updated");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.delete("/departments/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM departments WHERE id = $1", [id]);
    res.send("Department deleted");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// Funder Master endpoints
app.get("/fundermaster", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM fundermaster");
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.post("/fundermaster", async (req, res) => {
  const { name } = req.body;
  try {
    await pool.query("INSERT INTO fundermaster (name) VALUES ($1)", [name]);
    res.status(201).send("fundermaster added");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.put("/fundermaster/:id", async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    await pool.query("UPDATE fundermaster SET name = $1 WHERE id = $2", [
      name,
      id,
    ]);
    res.send("fundermaster updated");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

app.delete("/fundermaster/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM fundermaster WHERE id = $1", [id]);
    res.send("fundermaster deleted");
  } catch (err) {
    console.error(err);
    res.status(500).send("Server error");
  }
});

// Attachments endpoint
app.post("/api/attachments", async (req, res) => {
  try {
    const { SelectFinancialYear, Description, Submitted } = req.body;

    if (!req.files || !req.files.AttachFiles) {
      return res.status(400).json({
        success: false,
        message: "No file uploaded",
      });
    }

    const file = req.files.AttachFiles;

    const query = `
      INSERT INTO attachments (financial_year, description, file_name, file_data, submitted)
      VALUES ($1, $2, $3, $4, $5) 
      RETURNING id, financial_year, description, file_name;
    `;

    const values = [
      SelectFinancialYear,
      Description,
      file.name,
      file.data,
      Submitted === "true",
    ];

    const result = await pool.query(query, values);
    res.status(200).json({
      success: true,
      message: "File uploaded successfully",
      data: result.rows[0],
    });
  } catch (error) {
    console.error("Error saving attachment:", error);
    res.status(500).json({
      success: false,
      message: "Failed to upload file",
    });
  }
});
app.get("/api/attachments", async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM attachments");
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: "Server error" });
  }
});

app.delete("/api/attachments/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query("DELETE FROM attachments WHERE id = $1", [id]);

    if (result.rowCount === 0) {
      return res.status(404).send({ success: false, message: "Attachment not found" });
    }
    
    res.send({ success: true, message: "Attachment deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: "Server error" });
  }
});

// app.put("/api/attachments/:id", async (req, res) => {
//   const { id } = req.params;
//   const { description } = req.body; // Assuming you're updating description

//   try {
//     const result = await pool.query("UPDATE attachments SET description = $1 WHERE id = $2", [description, id]);

//     if (result.rowCount === 0) {
//       return res.status(404).send({ success: false, message: "Attachment not found" });
//     }

//     res.send({ success: true, message: "Attachment updated" });
//   } catch (err) {
//     console.error(err);
//     res.status(500).send({ success: false, message: "Server error" });
//   }
// });
app.put("/api/attachments/:id", async (req, res) => {
  const { id } = req.params;
  const { SelectFinancialYear, Description, Submitted } = req.body;

  try {
    // Check if the attachment exists
    const existingAttachment = await pool.query("SELECT * FROM attachments WHERE id = $1", [id]);
    if (existingAttachment.rowCount === 0) {
      return res.status(404).send({ success: false, message: "Attachment not found" });
    }

    const fileUpdates = [];
    if (req.files && req.files.AttachFiles) {
      const file = req.files.AttachFiles;
      fileUpdates.push(`file_name = '${file.name}', file_data = '${file.data}'`); // Update file data
    }

    const updates = [
      `financial_year = $1`,
      `description = $2`,
      ...(fileUpdates.length > 0 ? fileUpdates : []),
      `submitted = $3`,
    ].join(', ');

    const values = [
      SelectFinancialYear,
      Description,
      Submitted === "true",
      id
    ];

    const query = `UPDATE attachments SET ${updates} WHERE id = $${values.length}`;

    const result = await pool.query(query, values);

    res.send({ success: true, message: "Attachment updated" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ success: false, message: "Server error" });
  }
});


// Database error handler
pool.on("error", (err) => {
  console.error("Unexpected database error:", err);
});

// Start server
app
  .listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  })
  .on("error", (err) => {
    console.error("Failed to start server:", err);
  });
