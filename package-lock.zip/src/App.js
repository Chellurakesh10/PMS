import "./App.css";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useLocation,
} from "react-router-dom";
import Dashboard from "./Components/Dashboard/Dashboard";
import ActivityDashboard from "./Components/ActivityDashboard/ActivityDashboard";
import BudgetingForm from "./Components/BugetingForms/BudgetingForm";
import ExpenditureForm from "./Components/ExpenditureForm/ExpenditureForm";
import ProgramRegistration from "./Components/BugetingForms/ProgramRegistration/ProgramRegistration";
import ProgramRegistration2 from "./Components/BugetingForms/ProgramRegistration/ProgramRegistration2/ProgramRegistration2";
import ProjectList from "./Components/BugetingForms/ProgramRegistration/ProjectList/ProjectList";
import Masters from "./Components/Masters/Masters";
import ProgramStatus from "./Components/BugetingForms/ProgramStatus/ProgramStatus";
import ProjectFrameworks1 from "./Components/BugetingForms/ProjectFrameworks/ProjectFrameworks1";
import DepartmentMasters from "./Components/Masters/DepartmentMasters/DepartmentMasters";
import FunderMaster from "./Components/Masters/FunderMaster/FunderMaster";
import ProjectRegistration from "./Components/BugetingForms/ProjectFrameworks/ProjectRegistration/ProjectRegistration";
import ProjectGoalsAndOutcomes from "./Components/BugetingForms/ProjectFrameworks/ProjectGoalsAndOutcomes/ProjectGoalsAndOutcomes";
import Indicators from "./Components/BugetingForms/ProjectFrameworks/Indicators/Indicators";
import ProjectActivities from "./Components/BugetingForms/ProjectFrameworks/ProjectActivities/ProjectActivities";
import SubmittedForms from "./Components/ActivityDashboard/SubmittedForms/SubmittedForms";
import InProgressForm from "./Components/ActivityDashboard/InProgressForms/InProgressForms";
import ReceivedForms from "./Components/ActivityDashboard/ReceivedForms/ReceivedForms";
import ReferBackForms from "./Components/ActivityDashboard/ReferBackForms/ReferBackForms";
import AttachFiles from "./Components/BugetingForms/AttachFiles/AttachFiles";
import ApprovedForms from "./Components/ActivityDashboard/ApprovedForms/ApprovedForms";
import CoastedAnnualizedPlan from "./Components/BugetingForms/CoastedAnnualizedPlan/CoastedAnnualizedPlan";
import AcitivitiesAnnualCost from "./Components/BugetingForms/CoastedAnnualizedPlan/AcitivitiesAnnualCost/AcitivitiesAnnualCost";
import ActivitiesCodeAnnualCost from "./Components/BugetingForms/CoastedAnnualizedPlan/ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCost";
import ActivitiesCodeAnnualCosts from "./Components/ExpenditureForm/CoastedAnnualizedPlan/ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCosts";
import ProjectFrameworks2 from "./Components/ExpenditureForm/ProjectFrameworks2/ProjectFrameworks2";
import Login from "./Components/Login/Login";
import AttachFiles1 from "./Components/ExpenditureForm/AttachFiles1/AttachFiles1";
import ProgramRegistration1 from "./Components/ExpenditureForm/ProgramRegistration/ProgramRegistration1";
import ProgramStatus1 from "./Components/ExpenditureForm/ProgramStatus/ProgramStatus1";
import CoastedAnnualizedPlan1 from "./Components/ExpenditureForm/CoastedAnnualizedPlan/CoastedAnnualizedPlan1";
import OutputsannualCost1 from "./Components/ExpenditureForm/CoastedAnnualizedPlan/OutputsAnnualCost/OutputsAnnualCost1";
import Header2 from "./Components/Header2";
import { useState } from "react";
import OutputsannualCost from "./Components/BugetingForms/CoastedAnnualizedPlan/OutputsAnnualCost/OutputsannualCost";
import PerfomanceIndicator from "./Components/BugetingForms/ProjectFrameworks/PerfomanceIndicator/PerfomanceIndicator";
import ActivitiesAnnualCosts from "./Components/ExpenditureForm/CoastedAnnualizedPlan/ActivitiesAnnualCost/ActivitiesAnnualCosts";
import Reports from "./Components/Reports/Reports";
import Registration from "./Components/Registration/Registration";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [sliderOpen, setSliderOpen] = useState(false);

  const toggleSlider = () => setSliderOpen(!sliderOpen);
  const login = () => setIsAuthenticated(true);
  const logout = () => setIsAuthenticated(false);
  const HeaderWrapper = () => {
    const location = useLocation();
    return location.pathname !== "/register" ? (
      <Header2
        isAuthenticated={isAuthenticated}
        logout={logout}
        toggleSlider={toggleSlider}
        sliderOpen={sliderOpen}
      />
    ) : null;
  };

  return (
    <div className="App">
      <BrowserRouter>
        <HeaderWrapper />
        <Routes>
          <Route
            path="/"
            element={
              isAuthenticated ? (
                <Navigate to="/Dashboard" />
              ) : (
                <Login login={login} />
              )
            }
          />
          <Route path="/register" element={<Registration />} />
          <Route
            path="/Dashboard"
            element={isAuthenticated ? <Dashboard /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard"
            element={
              isAuthenticated ? <ActivityDashboard /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm"
            element={isAuthenticated ? <BudgetingForm /> : <Navigate to="/" />}
          />
          <Route
            path="/expenditureForm"
            element={
              isAuthenticated ? <ExpenditureForm /> : <Navigate to="/" />
            }
          />
          <Route
            path="/masters"
            element={isAuthenticated ? <Masters /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard/SubmittedForms"
            element={isAuthenticated ? <SubmittedForms /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard/ReceivedForms"
            element={isAuthenticated ? <ReceivedForms /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard/InProgressForms"
            element={isAuthenticated ? <InProgressForm /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard/ApprovedForms"
            element={isAuthenticated ? <ApprovedForms /> : <Navigate to="/" />}
          />
          <Route
            path="/activityDashboard/ReferBackForms"
            element={isAuthenticated ? <ReferBackForms /> : <Navigate to="/" />}
          />
          <Route
            path="/budgetingForm/ProgramStatus"
            element={isAuthenticated ? <ProgramStatus /> : <Navigate to="/" />}
          />
          <Route
            path="/budgetingForm/ProgramRegistration"
            element={
              isAuthenticated ? <ProgramRegistration /> : <Navigate to="/" />
            }
          />

          <Route
            path="/budgetingForm/ProgramRegistration/ProgramRegistration2"
            element={
              isAuthenticated ? <ProgramRegistration2 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/ProgramRegistration/ProjectList"
            element={isAuthenticated ? <ProjectList /> : <Navigate to="/" />}
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1"
            element={
              isAuthenticated ? <ProjectFrameworks1 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1/ProjectRegistration"
            element={
              isAuthenticated ? <ProjectRegistration /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1/ProjectGoalsAndOutcomes"
            element={
              isAuthenticated ? (
                <ProjectGoalsAndOutcomes />
              ) : (
                <Navigate to="/" />
              )
            }
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1/Indicators"
            element={isAuthenticated ? <Indicators /> : <Navigate to="/" />}
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1/PerformanceIndicator"
            element={
              isAuthenticated ? <PerfomanceIndicator /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/ProjectFrameworks1/ProjectActivities"
            element={
              isAuthenticated ? <ProjectActivities /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/CoastedAnnualizedPlan"
            element={
              isAuthenticated ? <CoastedAnnualizedPlan /> : <Navigate to="/" />
            }
          />
          <Route
            path="/budgetingForm/CoastedAnnualizedPlan/OutputsAnnualCost"
            element={<OutputsannualCost />}
          />
          <Route
            path="/budgetingForm/CoastedAnnualizedPlan/AcitivitiesAnnualCost"
            element={<AcitivitiesAnnualCost />}
          />
          <Route
            path="/budgetingForm/CoastedAnnualizedPlan/ActivitiesCodeAnnualCost"
            element={<ActivitiesCodeAnnualCost />}
          />
          <Route
            path="/budgetingForm/AttachFiles"
            element={isAuthenticated ? <AttachFiles /> : <Navigate to="/" />}
          />
          <Route
            path="/expenditureForm/ProgramStatus"
            element={isAuthenticated ? <ProgramStatus1 /> : <Navigate to="/" />}
          />
          <Route
            path="/expenditureForm/ProgramRegistration1"
            element={
              isAuthenticated ? <ProgramRegistration1 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/expenditureForm/CoastedAnnualizedPlan1"
            element={
              isAuthenticated ? <CoastedAnnualizedPlan1 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/expenditureForm/AttachFiles1"
            element={isAuthenticated ? <AttachFiles1 /> : <Navigate to="/" />}
          />
          <Route
            path="/expenditureForm/ProjectFrameworks2"
            element={
              isAuthenticated ? <ProjectFrameworks2 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/expenditureForm/CoastedAnnualizedPlan1/OutputsAnnualCost1"
            element={
              isAuthenticated ? <OutputsannualCost1 /> : <Navigate to="/" />
            }
          />
          <Route
            path="/expenditureForm/CoastedAnnualizedPlan1/ActivitiesAnnualCosts"
            element={
              isAuthenticated ? <ActivitiesAnnualCosts /> : <Navigate to="/" />
            }
          />
          <Route
            path="/expenditureForm/CoastedAnnualizedPlan1/ActivitiesCodeAnnualCosts"
            element={
              isAuthenticated ? (
                <ActivitiesCodeAnnualCosts />
              ) : (
                <Navigate to="/" />
              )
            }
          />
          <Route
            path="/masters/DepartmentMasters"
            element={
              isAuthenticated ? <DepartmentMasters /> : <Navigate to="/" />
            }
          />
          <Route
            path="/masters/FunderMaster"
            element={isAuthenticated ? <FunderMaster /> : <Navigate to="/" />}
          />
          <Route
            path="reports"
            element={isAuthenticated ? <Reports /> : <Navigate to="/" />}
          />
          <Route
            path="/NotFound"
            element={isAuthenticated ? <Reports /> : <Navigate to="/" />}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
