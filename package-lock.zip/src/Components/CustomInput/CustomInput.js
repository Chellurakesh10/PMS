import React from 'react'

import './CustomInput.css'

const CustomInput = ({ type, placeholder, className, name, value, onChange }) => (
  <input
    type={type}
    placeholder={placeholder}
    className={className || "default"}
    name={name}
    value={value}
    onChange={onChange} 
  />
);

export default CustomInput
