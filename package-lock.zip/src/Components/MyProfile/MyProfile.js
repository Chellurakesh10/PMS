import React from "react";

const MyProfile = () => {
  const userDetails = JSON.parse(localStorage.getItem("userDetails"));

  if (!userDetails) {
    return <div>No user data available.</div>;
  }

  return (
    <div className="profile-container">
      <h1>My Profile</h1>
      <p>
        <strong>First Name:</strong> {userDetails.firstName}
      </p>
      <p>
        <strong>Last Name:</strong> {userDetails.lastName}
      </p>
      <p>
        <strong>Email:</strong> {userDetails.email}
      </p>
     
    </div>
  );
};

export default MyProfile;
