import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";
import CustomInput from "../CustomInput/CustomInput";
import CustomButton from "../CustomButton/CustomButton";

const generateCaptcha = () => {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from(
    { length: 6 },
    () => chars[Math.floor(Math.random() * chars.length)]
  ).join("");
};

const Login = ({ login }) => {
  const navigate = useNavigate()
  const [formdata, setFormdata] = useState({ UserName: "", Password: "" });
  const [errors, setErrors] = useState({});
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [captchaInput, setCaptchaInput] = useState("");
  const [captchaError, setCaptchaError] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState("");

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const validateForm = () => {
    let newErrors = {};
    if (!formdata.UserName) newErrors.UserName = "Email is required";
    else if (!isValidEmail(formdata.UserName))
      newErrors.UserName = "Email is invalid";
    if (!formdata.Password) newErrors.Password = "Password is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError("");

    if (!validateForm()) return;

    if (captcha.toLowerCase() !== captchaInput.toLowerCase()) {
      setCaptchaError(true);
      alert("Invalid CAPTCHA");
      regenerateCaptcha();
      setCaptchaInput("");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("http://localhost:4000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: formdata.UserName.trim(),
          password: formdata.Password,
        }),
      });

      const data = await response.json();

      if (data.success) {
        login(data.user.firstName + " " + data.user.lastName);
        navigate("/dashboard");
      } else {
        setLoginError(data.message);
        regenerateCaptcha();
        setCaptchaInput("");
      }
    } catch (error) {
      console.error("Login error:", error);
      setLoginError("Connection error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) =>
    setFormdata({ ...formdata, [e.target.name]: e.target.value });
  const regenerateCaptcha = () => setCaptcha(generateCaptcha());

  const isCaptchaDisabled = !(formdata.UserName && formdata.Password);
  const myStyle = {
    backgroundImage: "url('/logoImages/bacgroundimage.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    height: "100vh",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  };

  return (
    <div className="Log-container" style={myStyle}>
      <div className="Log-fluid-container1">
        <div className="Log-Head">
          <img src="/logoImages/previewlogo.png" alt="logo" />
          <p>Sign in to start your session</p>
        </div>
        <form className="Log-form" onSubmit={handleLogin}>
          {loginError && <div className="error-message">{loginError}</div>}
          <div className="Log-input">
            <label htmlFor="email">UserName:</label>
            <CustomInput
              id="email"
              type="email"
              placeholder="Enter Email"
              className="input"
              name="UserName"
              value={formdata.UserName}
              onChange={handleChange}
              autoComplete="username"
            />
            {errors.UserName && <div className="errors">{errors.UserName}</div>}
          </div>
          <div className="Log-input">
            <label htmlFor="password">Password:</label>
            <CustomInput
              id="password"
              type="password"
              placeholder="Enter Password"
              className="input"
              name="Password"
              value={formdata.Password}
              onChange={handleChange}
              autoComplete="current-password"
            />
            {errors.Password && <div className="errors">{errors.Password}</div>}
          </div>
          <div className="Log-input">
            <label htmlFor="captcha">CAPTCHA:</label>
            <CustomInput
              id="captcha"
              type="text"
              placeholder="Enter CAPTCHA"
              className={`input ${captchaError ? "error" : ""}`}
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              disabled={isCaptchaDisabled}
              autoComplete="off"
            />
            {captchaError && (
              <span className="error-message">CAPTCHA does not match</span>
            )}
            <div className="captcha-container">
              <span className="captcha-text">{captcha}</span>
              <button
                type="button"
                onClick={regenerateCaptcha}
                className="regen-captcha"
                disabled={isCaptchaDisabled}
              >
                Regenerate
              </button>
            </div>
          </div>
          <div className="Log-link">
            <div className="Log-Reg">
              <Link to="/register">Need an Account?</Link>
            </div>
          </div>
          <div className="Log-but">
            <CustomButton
              buttonstyle="log"
              ButtonName={loading ? "Signing in..." : "Sign In"}
              disabled={loading}
            />
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
