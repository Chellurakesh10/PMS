import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "./SubNavigationLink.css";

const SubNavigationLinks = ({ title, links }) => {
  const [subMenuOpen, setSubMenuOpen] = useState(false);

  const toggleSubMenu = () => {
    setSubMenuOpen((prevState) => !prevState);
  };

  return (
    <li>
      <button
        onClick={toggleSubMenu}
        aria-expanded={subMenuOpen}
        aria-haspopup={links.some((link) => link.links)}
        className="sub-menu-toggle"
        type="button"
      >
        {title} {subMenuOpen ? "▲" : "▼"}
      </button>
      {subMenuOpen && (
        <ul className="sub-navigation">
          {links.map((link, i) =>
            link.links ? (
              <SubNavigationLinks
                key={`${title}-${link.label}-${i}`}
                title={link.label}
                links={link.links}
              />
            ) : (
              <li key={`${title}-${link.label}-${i}`}>
                <NavLink
                  to={typeof link.to === "string" ? link.to : link.to.pathname}
                  state={
                    typeof link.to === "object" ? link.to.state : link.state
                  }
                  onClick={(event) => {
                    if (link.toggleSlider) {
                      link.toggleSlider();
                    }
                    event.target.focus();
                  }}
                  className={({ isActive }) => (isActive ? "active-link" : "")}
                >
                  {link.label}
                </NavLink>
              </li>
            )
          )}
        </ul>
      )}
    </li>
  );
};

export default SubNavigationLinks;
