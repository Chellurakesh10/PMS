import React from "react";
import "./Dashboard.css"
import CustomButton from "../CustomButton/CustomButton";
import SelectCustom from "../SelectCustom/SelectCustom";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const data = [
  {
    name: "FY2024/2025",
    BudgetCost: 50000000,
    ExpenditureCost: 49000000,
  },
  {
    name: "FY2025/2026",
    BudgetCost: 50000000,
    ExpenditureCost: 49800000,
  },
];

const Dashboard = () => {
  return (
    <div className="DashContainer">
      <div className="Dashfluid-container">
        <div className="D-Head">
          <h1>Dashboard</h1>
        </div>
        <div className="D-class">
          <h3>Program Budget vs Expenditure</h3>
        </div>
        <div className="D-form">
          <div className="D-form-set">
            <SelectCustom>
              <option>1011</option>
              <option>101</option>
              <option>1202</option>
            </SelectCustom>
          </div>
          <div className="D-form-set">
            <SelectCustom>
              <option></option>
              <option></option>
              <option></option>
            </SelectCustom>
          </div>
          <div className="D-form-set">
            <CustomButton ButtonName={"Get"} />
          </div>
        </div>
        <div className="D-graph">
          <ResponsiveContainer width="95%" height={400} >
            <BarChart
              data={data}
              barSize={60}
              margin={{ top: 20, left: 30,right:20, bottom: 5, width: "40%" }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="BudgetCost" fill="#67b7dc" />
              <Bar dataKey="ExpenditureCost" fill="#6794dc" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
