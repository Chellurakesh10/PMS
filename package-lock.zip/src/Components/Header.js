import React, { useState } from "react";
import { Typography, ImageList } from "@mui/material";
import { AppBar, Toolbar, Box } from "@mui/material";
import Header2 from "./Header2";
import { useLocation } from 'react-router-dom';



export default function Header({ isAuthenticated, logout }) {
  const [sliderOpen, setSliderOpen] = useState(false);
  const location = useLocation();
  
  if (location.pathname === "/") {
    return null; // Hide header on the login page
  }

  const toggleSlider = () => {
    setSliderOpen(!sliderOpen);

    
  };
  return (
    <>
      <AppBar
        position="static"
        sx={{
          backgroundColor: "#60d9eb",
          // backgroundImage: url(Images/top.png),
          height: 150,
          width:"100%",
          flexGrow: 1,
          display: { md: "flex" },
        }}
      >
        <Toolbar>
          <ImageList
            sx={{
              width: 150,
              height: 150,
              alignItems: "center",
              color: "red",
              display: { xs: "none", md: "flex" },
            }}
          >
            <img src="\logoImages\favicon (1).ico" alt="Logo" />
          </ImageList>

          <Box
            sx={{
              flexGrow: 1,
              flexDirection: "column",
              display: { xs: "none", md: "flex" },
              alignItems: "center",
              justifyContent: "space-around",
            }}
          >
            <Typography
              variant="h6"
              component="div"
              sx={{
                flexGrow: 1,
                display: { xs: "none", md: "flex" },
                alignItems: "center",
                color: "red",
              }}
            >
              THE REPUBLIC OF UGANDA
            </Typography>
            <Typography
              variant="h6"
              component="div"
              sx={{
                flexGrow: 1,
                display: { xs: "none", md: "flex" },
                alignItems: "center",
                color: "blueviolet",
              }}
            >
              Ministry of Water and Environment
            </Typography>
            <Typography
              variant="h6"
              component="div"
              sx={{
                flexGrow: 1,
                display: { xs: "none", md: "flex" },
                alignItems: "center",
                color: "blueviolet",
              }}
            >
              DEPARTMENT OF ENVIRONMENT SECTOR SUPPORT SERVICES
            </Typography>
          </Box>

          <Box
            sx={{
              flexGrow: 1,
              display: { xs: "flex", md: "none" },
              vertical: "Top",
              justifyContent: "space-around",
              alignItems: "center",
            }}
          >
            <ImageList
              sx={{
                width: 100,
                height: 100,
                alignItems: "center",
                color: "red",
                display: { xs: "flex", md: "none" },
              }}
            >
              <img src="\logoImages\favicon.ico" alt="Logo" />
            </ImageList>
            <Box>
              <Typography
                variant="p"
                component="div"
                sx={{
                  flexGrow: 1,
                  flexDirection: "column",
                  display: { xs: "flex", md: "none" },
                  color: "red",
                }}
              >
                THE REPUBLIC OF UGANDA
              </Typography>
              <Typography
                variant="p"
                component="div"
                sx={{
                  flexGrow: 1,
                  flexDirection: "column",
                  display: { xs: "flex", md: "none" },
                  color: "blue",
                }}
              >
                Ministry of Water and Environment
              </Typography>
              <Typography
                variant="p"
                component="div"
                sx={{
                  flexGrow: 1,
                  flexDirection: "column",
                  display: { xs: "flex", md: "none" },
                  color: "blue",
                }}
              >
                DEPARTMENT OF ENVIRONMENT SECTOR SUPPORT SERVICES
              </Typography>
            </Box>
          </Box>
        </Toolbar>
      </AppBar>
      <Box>
        <Header2 toggleSlider={toggleSlider} sliderOpen={sliderOpen} />
      </Box>
    </>
  );
}
