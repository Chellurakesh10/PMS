import React, { useState } from 'react';
import AvatarDropdown from './AvatarDropdown';
import Login from './Login'; // Import your Login component

const App = () => {
  const [userName, setUserName] = useState(""); // State to store the user's name
  const [isAuthenticated, setIsAuthenticated] = useState(false); // State for authentication

  const login = (name) => {
    setUserName(name); // Set the user name for the AvatarDropdown
    setIsAuthenticated(true); // Mark as authenticated
  };

  return (
    <div>
      {isAuthenticated ? (
        <AvatarDropdown userName={userName} /> // Show AvatarDropdown if authenticated
      ) : (
        <Login login={login} /> // Show Login component if not authenticated
      )}
    </div>
  );
};

export default App;
