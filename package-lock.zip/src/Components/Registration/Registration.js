import React, { useState } from "react";
import "./Registration.css";
import CustomInput from "../CustomInput/CustomInput";
import CustomButton from "../CustomButton/CustomButton";
import { useNavigate } from "react-router-dom";

const Registration = () => {
  const navigate = useNavigate();
  const [formdata, setFormdata] = useState({
    FirstName: "",
    LastName: "",
    Email: "",
    Password: "",
    ConfirmPassword: "", // Corrected here
    submitted: false,
  });

  const [errors, setErrors] = useState({});

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const isValidPassword = (Password) => {
    const symbolRegex = /[!@$%^&*(),.?":{}|<>]/;
    const numberRegex = /[0-9]/;
    const upperCaseRegex = /[A-Z]/;
    const lowerCaseRegex = /[a-z]/;
    return (
      Password.length >= 8 &&
      symbolRegex.test(Password) &&
      numberRegex.test(Password) &&
      upperCaseRegex.test(Password) &&
      lowerCaseRegex.test(Password)
    );
  };

  const validateForm = () => {
    let newErrors = {};

    if (!formdata.FirstName) {
      newErrors.FirstName = "First Name is required";
    }

    if (!formdata.LastName) {
      newErrors.LastName = "Last Name is required";
    }

    if (!formdata.Email) {
      newErrors.Email = "Email is required";
    } else if (!isValidEmail(formdata.Email)) {
      newErrors.Email = "Email is invalid";
    }

    if (!formdata.Password) {
      newErrors.Password = "Password is required";
    } else if (!isValidPassword(formdata.Password)) {
      newErrors.Password =
        "Password must be at least 8 characters, contain one uppercase letter, one number, and one symbol";
    }

    if (!formdata.ConfirmPassword) {
      // Corrected here
      newErrors.ConfirmPassword = "Confirm Password is required";
    } else if (formdata.ConfirmPassword !== formdata.Password) {
      newErrors.ConfirmPassword = "Passwords must match";
    }
    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };
  const handleRegister = async (e) => {
    e.preventDefault();

    const isValid = validateForm();
    if (!isValid) return;

    try {
      const response = await fetch("http://localhost:4000/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          FIRSTNAME: formdata.FirstName.trim(),
          LASTNAME: formdata.LastName.trim(),
          EMAIL: formdata.Email.trim(),
          PASSWORD: formdata.Password,
        }),
      });

      const data = await response.json();

      if (data.success) {
        alert("Registration successful!");
        navigate("/");
      } else {
        alert(data.message || "Registration failed");
      }
    } catch (error) {
      console.error("Registration error:", error);
      alert("Registration failed. Please try again.");
    }
  };

  // const handleRegister = async (e) => {
  //   e.preventDefault();

  //   const isValid = validateForm();
  //   if (isValid) {
  //     try {
  //       const response = await fetch("http://localhost:4000/register", {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //         body: JSON.stringify({
  //           FIRSTNAME: formdata.FirstName,
  //           LASTNAME: formdata.LastName,
  //           EMAIL: formdata.Email,
  //           PASSWORD: formdata.Password
  //         }),
  //       });

  //       const data = await response.json();
  //       if (data.success) {
  //         alert("User registered successfully");
  //         navigate("/");
  //       } else {
  //         alert(data.error);
  //       }
  //     } catch (error) {
  //       console.error("Error registering user:", error);
  //       alert("Registration failed");
  //     }
  //   }
  // };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormdata({
      ...formdata,
      [name]: value,
    });
  };

  const myStyle = {
    backgroundImage: "url('/logoImages/bacgroundimage.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
    height: "100vh",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  };

  return (
    <div className="R-container" style={myStyle}>
      <div className="Reg-fluid-container">
        <div className="Reg-head">
          <img src="\logoImages\previewlogo.png" alt="logo" />
          <p>Registration</p>
        </div>
        <div className="Reg-Form">
          <div className="Reg-inputs">
            <label>First Name</label>
            <CustomInput
              className={"input"}
              type={"text"}
              placeholder={"First Name"}
              name={"FirstName"}
              value={formdata.FirstName}
              onChange={handleChange}
            />
            {errors.FirstName && <p className="error">{errors.FirstName}</p>}
          </div>
          <div className="Reg-inputs">
            <label>Last Name</label>
            <CustomInput
              className={"input"}
              type={"text"}
              placeholder={"Last Name"}
              name={"LastName"}
              value={formdata.LastName}
              onChange={handleChange}
            />
            {errors.LastName && <p className="error">{errors.LastName}</p>}
          </div>
          <div className="Reg-inputs">
            <label>Email</label>
            <CustomInput
              className={"input"}
              type={"text"}
              placeholder={"Email"}
              name={"Email"}
              value={formdata.Email}
              onChange={handleChange}
            />
            {errors.Email && <p className="error">{errors.Email}</p>}
          </div>
          <div className="Reg-inputs">
            <label>Password</label>
            <CustomInput
              className="input"
              type="password"
              placeholder="Password"
              name="Password"
              value={formdata.Password}
              onChange={handleChange}
            />
            {errors.Password && <p className="error">{errors.Password}</p>}
          </div>
          <div className="Reg-inputs">
            <label>Confirm Password</label>
            <CustomInput
              className="input"
              type="password"
              placeholder="Confirm Password"
              name="ConfirmPassword"
              value={formdata.ConfirmPassword}
              onChange={handleChange}
            />
            {errors.ConfirmPassword && (
              <p className="error">{errors.ConfirmPassword}</p>
            )}
          </div>

          <div className="Reg-but">
            <CustomButton
              buttonStyle="sub-but"
              ButtonName="Register"
              onClick={handleRegister}
            />
          </div>
          <div className="Reg-log">
            <a href="./">Already Registered? Log in</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Registration;
