import React from "react";
import SubNavigationLinks from "./SubNavigationLinks/SubNavigationLinks";
import { NavLink } from "react-router-dom";

const NavigationLinks = ({ toggleSlider }) => {
  return (
    <div>
      <ul>
        <li>
          <NavLink
            to="/"
            onClick={toggleSlider}
            className={({ isActive }) => (isActive ? "active-link" : "")}
            tabIndex={0}
          >
            <span>Dashboard</span>
          </NavLink>
        </li>
        <SubNavigationLinks
          title="Activity Dashboard"
          links={[
            {
              to: "/activityDashboard/SubmittedForms",
              toggleSlider: toggleSlider,
              label: "Submitted Forms",
            },
            {
              to: "/activityDashboard/ReceivedForms",
              toggleSlider: toggleSlider,
              label: "Received Forms",
            },
            {
              to: "/activityDashboard/InProgressForms",
              toggleSlider: toggleSlider,
              label: "InProgress Forms",
            },
            {
              to: "/activityDashboard/ApprovedForms",
              toggleSlider: toggleSlider,
              label: "Approval Forms",
            },
            {
              to: "/activityDashboard/ReferBackForms",
              toggleSlider: toggleSlider,
              label: "Refer Back Forms",
            },
          ]}
        />
        <SubNavigationLinks
          title="Budgeting Form"
          links={[
            {
              to: "/budgetingForm",
              state: { component: "ProgramStatus" },
              toggleSlider: toggleSlider,
              label: "Program Status",
            },
            {
              label: "Program Registration",
              links: [
                {
                  to: "/budgetingForm/ProgramRegistration",
                  state: { component: "ProgramRegistration2" },
                  toggleSlider: toggleSlider,
                  label: "Project Registration",
                },
                {
                  to: "/budgetingForm/ProgramRegistration",
                  state: { component: "ProjectList" },
                  toggleSlider: toggleSlider,
                  label: "Project List",
                },
              ],
            },
            {
              label: "Project Frameworks",
              links: [
                {
                  to: "/budgetingForm/ProjectFrameworks1",
                  state: { component: "ProjectRegistration" },
                  toggleSlider: toggleSlider,
                  label: "Project Registration",
                },
                {
                  to: "/budgetingForm/ProjectFrameworks1",
                  state: { component: "ProjectGoalsAndOutcomes" },
                  toggleSlider: toggleSlider,
                  label: "Project Goals And Outcomes",
                },
                {
                  to: "/budgetingForm/ProjectFrameworks1",
                  state: { component: "Indicators" },
                  toggleSlider: toggleSlider,
                  label: "Indicators",
                },
                {
                  to: "/budgetingForm/ProjectFrameworks1",
                  state: { component: "PerformanceIndicator" },
                  toggleSlider: toggleSlider,
                  label: "Performance Indicators",
                },
                {
                  to: "/budgetingForm/ProjectFrameworks1",
                  state: { component: "ProjectActivities" },
                  toggleSlider: toggleSlider,
                  label: "Project Activities",
                },
              ],
            },
            {
              label: "Coasted Annualized Plan",
              links: [
                {
                  to: "/budgetingForm/CoastedAnnualizedPlan",
                  state: { component: "OutputsannualCost" },
                  toggleSlider: toggleSlider,
                  label: "Outputs Annual Cost",
                },
                {
                  to: "/budgetingForm/CoastedAnnualizedPlan",
                  state: { component: "AcitivitiesAnnualCost" },
                  toggleSlider: toggleSlider,
                  label: "Activities Annual Cost",
                },
                {
                  to: "/budgetingForm/CoastedAnnualizedPlan",
                  state: { component: "ActivitiesCodeAnnualCost" },
                  toggleSlider: toggleSlider,
                  label: "Activities Code Annual Cost",
                },
              ],
            },
            {
              to: "/budgetingForm",
              state: { component: "AttachFiles" },
              toggleSlider: toggleSlider,
              label: "Attach Files",
            },
          ]}
        />
        <SubNavigationLinks
          title="Expenditure Form"
          links={[
            {
              to: "/expenditureForm",
              state: { component: "ProgramStatus1" },
              toggleSlider: toggleSlider,
              label: "Program Status",
            },
            {
              label: "Coasted Annualized Plan",
              links: [
                {
                  to: "/expenditureForm/CoastedAnnualizedPlan1",
                  state: { component: "OutputsannualCost1" },
                  toggleSlider: toggleSlider,
                  label: "Outputs Annual Cost",
                },
                {
                  to: "/expenditureForm/CoastedAnnualizedPlan1",
                  state: { component: "ActivitiesAnnualCosts" },
                  toggleSlider: toggleSlider,
                  label: "Activities Annual Cost",
                },
                {
                  to: "/expenditureForm/CoastedAnnualizedPlan1",
                  state: { component: "ActivitiesCodeAnnualCosts" },
                  toggleSlider: toggleSlider,
                  label: "Activities Code Annual Cost",
                },
              ],
            },
            {
              to: "/expenditureForm",
              state: { component: "AttachFiles1" },
              toggleSlider: toggleSlider,
              label: "Attach Files",
            },
            {
              to: "/expenditureForm",
              state: { component: "ProjectFrameworks2" },
              toggleSlider: toggleSlider,
              label: "Project Frameworks",
            },
            {
              to: "/expenditureForm",
              state: { component: "ProgramRegistration1" },
              toggleSlider: toggleSlider,
              label: "Program Registration",
            },
          ]}
        />
        <SubNavigationLinks
          title="Masters"
          links={[
            {
              to: "/masters",
              state: { component: "DepartmentMasters" },
              toggleSlider: toggleSlider,
              label: "Department Masters",
            },
            {
              to: "/masters",
              state: { component: "FunderMaster" },
              toggleSlider: toggleSlider,
              label: "Funder Masters",
            },
          ]}
        />
        <li>
          <NavLink
            to="/"
            onClick={toggleSlider}
            className={({ isActive }) => (isActive ? "active-link" : "")}
            tabIndex={0}
          >
            <span>Reports</span>
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default NavigationLinks;