import React, { useEffect, useState } from "react";
import { AiOutlineFundProjectionScreen } from "react-icons/ai";
import { FcDepartment } from "react-icons/fc";
// import Header from '../Header';
import "./Masters.css";
import DepartmentMasters from "./DepartmentMasters/DepartmentMasters";
import FunderMaster from "./FunderMaster/FunderMaster";
import { useLocation, useNavigate } from "react-router-dom";

const Masters = () => {
  const tabName = useLocation();
  const navigate = useNavigate();

  const [activeComponent, setActiveComponent] = useState(
    tabName.state?.component || "DepartmentMasters"
  );

  useEffect(() => {
    console.log("Location state:", tabName.state);

    if (
      tabName.state?.component &&
      tabName.state.component !== activeComponent
    ) {
      setActiveComponent(tabName.state.component);
    } else if (!tabName.state?.component) {
      setActiveComponent("DepartmentMasters"); // Fallback component
    }
  }, [tabName.state, activeComponent]);

  const handleButtonClick = (component) => {
    console.log("Switching to:", component);
    setActiveComponent(component);

    // Navigate to the new path if required
    navigate("/masters/", { state: { component } });
  };

  const validComponents = [
    "DepartmentMasters",
    "FunderMaster",
  ];
  return (
    <div className="mastercontainer">
      {/* <Header /> */}
      <div className="M-fluid-container">
        <ul>
          <li>
            <button
              className={
                activeComponent === "DepartmentMasters"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("DepartmentMasters")}
            >
              <span>
                <FcDepartment />
                Department Master
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "FunderMaster" ? "active-link focus" : ""
              }
              onClick={() => handleButtonClick("FunderMaster")}
            >
              <span>
                <AiOutlineFundProjectionScreen />
                Funder Master
              </span>
            </button>
          </li>
        </ul>
      </div>
      <div className="masterbodycontainer">
        {validComponents.includes(activeComponent) ? (
          <>
            {activeComponent === "DepartmentMasters" && <DepartmentMasters />}
            {activeComponent === "FunderMaster" && <FunderMaster />}
          </>
        ) : (
          <div>Component not found</div>
        )}
      </div>
    </div>
  );
};

export default Masters;
