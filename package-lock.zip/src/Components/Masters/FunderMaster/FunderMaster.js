import React, { useState, useEffect } from "react";
import "./FunderMaster.css";
import CustomButton from "../../CustomButton/CustomButton";
import CustomInput from "../../CustomInput/CustomInput";
import { RiDeleteBin5Line } from "react-icons/ri";
import { GrDocumentUpdate } from "react-icons/gr";

const FunderMaster = () => {
  const [funderName, setFunderName] = useState("");
  const [fundermaster, setfundermaster] = useState([]);

  useEffect(() => {
    fetchfundermaster();
  }, []);

  const fetchfundermaster = async () => {
    const response = await fetch("http://localhost:4000/fundermaster");
    const data = await response.json();
    setfundermaster(data);
  };

  const handleInputChange = (e) => {
    setFunderName(e.target.value);
  };

  const handleAdd = async () => {
    if (funderName.trim()) {
      await fetch("http://localhost:4000/fundermaster", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name: funderName.trim() }),
      });
      setFunderName(""); // Corrected to setFunderName
      fetchfundermaster(); // Refresh the list
      alert("funderName Added");
    } else {
      alert("funderName cannot be empty");
    }
  };

  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this fundermaster?");
    if (confirmDelete) {
      await fetch(`http://localhost:4000/fundermaster/${id}`, {
        method: "DELETE",
      });
      fetchfundermaster(); // Refresh the list
      alert("funderName Deleted");
    } else {
      alert("funderName was not deleted");
    }
  };

  const handleUpdate = async (id) => {
    const updatedName = prompt("Enter new name for the fundermaster:", fundermaster.find(dep => dep.id === id)?.name);
    if (updatedName) {
      await fetch(`http://localhost:4000/fundermaster/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name: updatedName.trim() }),
      });
      fetchfundermaster(); // Refresh the list
      alert("funderName Updated");
    } else {
      alert("funderName was not updated");
    }
  };

  return (
    <div className="FM-continer">
      <div className="Fm-fluid-container">
        <div className="Fm-head">
          <h1>Funders Master</h1>
        </div>
        <div className="Fm-form">
          <div className="Fm-input1">
            <label>Funder Name</label>
            <CustomInput
              type={"text"}
              placeholder={"Funder Name"}
              value={funderName}
              onChange={handleInputChange}
            />
          </div>
          <div className="Fm-input1">
            <CustomButton ButtonName={"Add"} onClick={handleAdd} />
          </div>
        </div>
        <div className="FM-Tab">
          <table className="Fm-input">
            <thead>
              <tr>
                <th>Funder Name</th>
                <th>Update</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {fundermaster.map((funder) => (
                <tr key={funder.id}>
                  <td>{funder.name}</td>
                  <td>
                    <button onClick={() => handleUpdate(funder.id)}><GrDocumentUpdate /></button>
                  </td>
                  <td>
                    <button onClick={() => handleDelete(funder.id)}><RiDeleteBin5Line /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FunderMaster;
