import React, { useState, useEffect } from "react";
import "./DepartmentMasters.css";
import CustomButton from "../../CustomButton/CustomButton";
import CustomInput from "../../CustomInput/CustomInput";
import { RiDeleteBin5Line } from "react-icons/ri";
import { GrDocumentUpdate } from "react-icons/gr";

const DepartmentMasters = () => {
  const [departmentName, setDepartmentName] = useState("");
  const [departments, setDepartments] = useState([]);

  // Fetch departments on component mount
  useEffect(() => {
    fetchDepartments();
  }, []);

  // Function to fetch departments from the server
  const fetchDepartments = async () => {
    try {
      const response = await fetch("http://localhost:4000/departments");
      const data = await response.json();
      setDepartments(data);
    } catch (error) {
      console.error("Failed to fetch departments:", error);
    }
  };

  // Handle input change
  const handleInputChange = (e) => {
    setDepartmentName(e.target.value);
  };

  // Handle adding a new department
  const handleAdd = async () => {
    if (departmentName.trim()) {
      try {
        await fetch("http://localhost:4000/departments", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: departmentName.trim() }),
        });
        setDepartmentName("");
        fetchDepartments(); // Refresh the list
        alert("Department Name Added");
      } catch (error) {
        console.error("Failed to add department:", error);
        alert("Failed to add department");
      }
    } else {
      alert("Department Name cannot be empty");
    }
  };

  // Handle deleting a department
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this department?");
    if (confirmDelete) {
      try {
        await fetch(`http://localhost:4000/departments/${id}`, {
          method: "DELETE",
        });
        fetchDepartments(); // Refresh the list
        alert("Department Name Deleted");
      } catch (error) {
        console.error("Failed to delete department:", error);
        alert("Failed to delete department");
      }
    }
  };

  // Handle updating a department
  const handleUpdate = async (id) => {
    const existingDepartment = departments.find(dep => dep.id === id);
    const updatedName = prompt("Enter new name for the Department:", existingDepartment?.name);
    
    if (updatedName && updatedName.trim()) {
      try {
        await fetch(`http://localhost:4000/departments/${id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: updatedName.trim() }),
        });
        fetchDepartments(); // Refresh the list
        alert("Department Name Updated");
      } catch (error) {
        console.error("Failed to update department:", error);
        alert("Failed to update department");
      }
    } else {
      alert("Department Name was not updated");
    }
  };

  return (
    <div className="container">
      <div className="Dm-fluid-container">
        <div className="Dm-head">
          <h1>Department Master</h1>
        </div>
        <div className="Dm-form">
          <div className="Dm-input1">
            <label>Department Name</label>
            <CustomInput
              type="text"
              value={departmentName}
              placeholder="Department Name"
              onChange={handleInputChange}
            />
          </div>
          <div className="Dm-input">
            <CustomButton ButtonName="Add" onClick={handleAdd} />
          </div>
        </div>
        <div className="Dm-Tab">
          <table className="Dm-input">
            <thead>
              <tr>
                <th>Department Name</th>
                <th>Update</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {departments.map((department) => (
                <tr key={department.id}>
                  <td>{department.name}</td>
                  <td>
                    <button onClick={() => handleUpdate(department.id)}>
                      <GrDocumentUpdate />
                    </button>
                  </td>
                  <td>
                    <button onClick={() => handleDelete(department.id)}>
                      <RiDeleteBin5Line />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DepartmentMasters;
