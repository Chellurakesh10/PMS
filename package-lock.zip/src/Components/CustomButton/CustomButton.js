import React from 'react'
import './CustomButton.css'
const CustomButton = (props) => {
    const{ButtonName,onClick,buttonstyle} = props;
    
    return (
      <div>
          <button className={buttonstyle || "default-button"} onClick={onClick}>{ButtonName || "Button"}</button>
        
      </div>
    )
}

export default CustomButton
