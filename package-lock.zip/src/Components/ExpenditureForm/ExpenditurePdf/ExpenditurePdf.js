import React,{useRef} from 'react'
import './ExpenditurePdf.css'

const ExpenditurePdf = () => {
    const printRef = useRef();

    // const handleDownloadPdf = () => {
    //   const buttons = document.querySelectorAll(".form-but");
    //   buttons.forEach((button) => (button.style.display = "none"));

    //   const element = printRef.current;
    //   const options = {
    //     margin: [0.5, 0.5],
    //     filename: "BudgetForm.pdf",
    //     image: { type: "jpeg", quality: 0.98 },
    //     html2canvas: { scale: 2 },
    //     jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
    //   };

    //   html2pdf()
    //     .set(options)
    //     .from(element)
    //     .save()
    //     .then(() => {
    //       buttons.forEach((button) => (button.style.display = "block"));
    //     });
    // };
    const handlePrint = () => {
        const buttons = document.querySelectorAll(".form-but");
        buttons.forEach((button) => (button.style.display = "none"));

        window.print();

        buttons.forEach((button) => (button.style.display = "block"));
    };

    return (
        <div className="Container">
            <div className="fluid-container">
                <div className="form-fill">
                    <div className="form-img">
                        <img src="\public\favicon (1).ico" ait="" />
                    </div>
                    <div>
                        <h2>The Republic of Uganda</h2>
                    </div>
                </div>
            </div>

            <div ref={printRef} id="budgetForm" style={{ padding: "20px" }}>
                <h1>EXPENDITURE FORM</h1>
                {/*1. Program Registration */}
                <div className="form-container">
                    <h2>PROGRAM REGISTRATION</h2>
                    <div className="Table1">
                        <div className="form-table1">
                            <h3>Main Details</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Program Name</th>
                                        <th>Program Code</th>
                                        <th>Stakeholders department</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="form-table1">
                            <h3>Program Duration</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Duration years</th>
                                        <th>End Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="form-table">
                            <h3>Program Budget & Expenditure</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Program Budget Cost(UGX)</th>
                                        <th>Program Expenditure Cost(UGX)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="form-table">
                            <h3>Project List Table</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Program Name</th>
                                        <th>Program Code</th>
                                        <th>Funder List</th>
                                        <th>Estimated Project Cost(UGX)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                {/*2. Project Registration */}
                <div className="form-container">
                    <h2>PROJECT REGISTRATION</h2>
                    <div className="Table1">
                        <div className="form-table1">
                            <h3>Main Details</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Program Name</th>
                                        <th>Program Code</th>
                                        <th>Project Name</th>
                                        <th>Project Code</th>
                                        <th>Department</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div className="form-table1">
                            <h3>Program Duration</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Start Date</th>
                                        <th>Duration (years)</th>
                                        <th>End Date</th>
                                        <th>Estimated Project cost(UGX)</th>
                                        <th>Funders</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="form-table">
                            <h3>Program Budget & Expenditure</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Program Budget Cost(UGX)</th>
                                        <th>Program Expenditure Cost(UGX)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="form-table1">
                            <h3>Responsible Officer</h3>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Name</th>
                                        <th>Mobile Number</th>
                                        <th>Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                {/* 3.OUTPUTS ANNUAL COST TABLE */}
                <div className="form-container">
                    <h2>OUTPUTS ANNUAL COST TABLE</h2>
                    <div className="Table">
                        <div className="form-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Outputs</th>
                                        <th>Activities</th>
                                        <th>Activity Code</th>
                                        <th>Activity Cost</th>
                                        <th>Financial Year</th>
                                        <th>Annual Budjecting Cost (UGX)</th>
                                        <th>Annual Expenditure Cost (UGX)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                {/* ACTIVITIES ANNUAL COST TABLE */}
                <div className="form-container">
                    <h2>ACTIVITIES ANNUAL COST TABLE</h2>
                    <div className="form-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Outputs</th>
                                    <th>Activities</th>
                                    <th>Financial Year</th>
                                    <th>Annual Budjecting Cost (UGX)</th>
                                    <th>Annual Expenditure Cost (UGX)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                {/* ACTIVITIES CODE ANNUAL COST TABLE */}
                <div className="form-container">
                    <h2>ACTIVITIES CODE ANNUAL COST TABLE</h2>
                    <div className="form-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Type Of Framework</th>
                                    <th>Framework Description</th>
                                    <th>Indicators</th>
                                    <th>Financial Year</th>
                                    <th>Indicators Performance</th>
                                    <th>Indicator Type</th>
                                    <th>Means Of Verification</th>
                                    <th>Assumptions</th>
                                    <th>Risks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                {/* Attach Files */}
                <div className="form-container">
                    <h2>Attach Files</h2>
                    <div className="form-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Financial Year</th>
                                    <th>Description</th>
                                    <th>Attach Files</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <button className="view">View</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="form-but">
                    {/* <button onClick={handleDownloadPdf}>Download</button> */}

                    <button onClick={handlePrint}>Print</button>

                    <button onClick={() => console.log("Close action")}>Close</button>
                </div>
            </div>
        </div>
    );
}

export default ExpenditurePdf
