import React, { useState } from "react";
import "./ProjectFrameworks2.css";
import CustomInput from "../../CustomInput/CustomInput";

const ProjectFrameworks2 = () => {
  const [frameworks, setFrameworks] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Department: "",
    StartDate: "",
    EndDate: "",
    DurationYear: "",
    TotalEstimatedCost: "",
    TotalExpenditureCost: "",
  });
  const handleSave = (e) => {
    e.preventDefault();
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFrameworks({
      ...frameworks,
      [name]: value,
    });
  };

  return (
    <div className="form-pf-container">
      <div className="form-pf-container-fluid">
        <div className="form-pf-head">
          <h1>Project Registration Form</h1>
        </div>
        <div className="form-pf-form">
          <div className="form-ps-input">
            <label>Project Name</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={frameworks.ProgramName}
              placeholder="Program Name"
            />
          </div>
          <div className="form-ps-input">
            <label>Program Code</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={frameworks.ProgramName}
              placeholder="Program Code"
            />
          </div>
        </div>
        <div className="form-pf-form">
          <div className="form-ps-input">
            <label>Program Name</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={frameworks.ProgramName}
              placeholder="Project Name"
            />
          </div>
          <div className="form-ps-input">
            <label>Project Code</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={frameworks.ProgramName}
              placeholder="Project Code"
            />
          </div>
          <div className="form-ps-input">
            <label>Department</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={frameworks.ProgramName}
              placeholder={"Department"}
            />
          </div>
        </div>

        <div className="form-pf-head">
          <h4>Responsible officer Details</h4>
        </div>
        <div className="form-pf-form">
          <div className="form-ps-input">
            <label>Name</label>
            <CustomInput type={"text"} placeholder={"Name"} />
          </div>
          <div className="form-ps-input">
            <label>Tittle</label>
            <CustomInput type={"text"} placeholder={"Tittle"} />
          </div>
          <div className="form-ps-input">
            <label>Mobile Number</label>
            <CustomInput type={"text"} placeholder={"MobileNumber"} />
          </div>
          <div className="form-ps-input">
            <label>Email</label>
            <CustomInput type={"text"} placeholder={"Email"} />
          </div>
        </div>
        <div className="form-pf-head">
          <h3>Program Duration</h3>
        </div>
        <div className="form-pf-form">
          <div className="form-ps-input">
            <label>Start Date</label>
            <CustomInput
              type={"date"}
              placeholder={"startDate"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
          <div className="form-ps-input">
            <label>Duration Year</label>
            <CustomInput
              type={"text"}
              placeholder={"DurationYear"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
          <div className="form-ps-input">
            <label>End Date</label>
            <CustomInput
              type={"date"}
              placeholder={"EndDate"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
        </div>
        <div className="form-pf-head">
          <h4>Project funding Details</h4>
        </div>
        <div className="form-pf-form1">
          <div className="form-ps-input1">
            <label>Enter Funder With Comma Seperate(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"EnterFunderWithCommaSeperate"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
          <div className="form-ps-input1">
            <label>Estimated Project Cost (UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"EstimatedProjectCost"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
          <div className="form-ps-input1">
            <label>Project Expenditure Cost (UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"ProjectExpenditureCost"}
              name="ProgramName"
              value={frameworks.ProgramName}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectFrameworks2;
