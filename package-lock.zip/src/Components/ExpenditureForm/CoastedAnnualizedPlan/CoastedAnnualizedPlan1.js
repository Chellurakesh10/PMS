import React, { useEffect, useState } from "react";
import "./CoastedAnnualizedPlan1.css";
import OutputsannualCost1 from "./OutputsAnnualCost/OutputsAnnualCost1";
import ActivitiesCodeAnnualCosts from "./ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCosts";
import { useLocation } from "react-router-dom";
import ActivitiesAnnualCosts from "./ActivitiesAnnualCost/ActivitiesAnnualCosts";
import { MdOutput } from "react-icons/md";
import { SiActivision } from "react-icons/si";
import { SiActivitypub } from "react-icons/si";

const CoastedAnnualizedPlan1 = () => {
  const tabName = useLocation();
  // const navigate = useNavigate();

  const [activeComponent, setActiveComponent] = useState(
    "OutputsannualCost1" || tabName.state?.component
  );
  useEffect(() => {
    console.log("Current Location state:", tabName.state);
    console.log("Current activeComponent:", activeComponent);

    // Set activeComponent only if it's different from the current one
    if (
      tabName.state?.component &&
      tabName.state.component === activeComponent
    ) {
      setActiveComponent(tabName.state.component);
    }
  }, [tabName.state, activeComponent]);

  const handleButtonClick = (component) => {
    console.log("Clicked Component:", component);
    setActiveComponent(component);

    // navigate(`/ExpenditureForm/CoastedAnnualizedPlan1?tab=${component}`, { replace: true });

    window.history.pushState(
      null,
      "",
      `/ExpenditureForm/CoastedAnnualizedPlan1#${component}`
    );

    // navigate(`/ExpenditureForm/CoastedAnnualizedPlan1/${component}`, {
    //   state: { component },
    // });
  };

  return (
    <div className="planFluid-container">
      <div className="Head">
        <h1>Coasted Annualized Plan</h1>
      </div>
      <div className="planForm">
        <ul>
          <li>
            <button
              className={
                activeComponent === "OutputsannualCost1"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("OutputsannualCost1")}
            >
              <span>
                <MdOutput />
                Outputs Annual Cost
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "ActivitiesAnnualCosts"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("ActivitiesAnnualCosts")}
            >
              <span>
                <SiActivision />
                Activities Annual Cost
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "ActivitiesCodeAnnualCosts"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("ActivitiesCodeAnnualCosts")}
            >
              <span>
                <SiActivitypub />
                Activities Code Annual Cost
              </span>
            </button>
          </li>
        </ul>
      </div>
      <div className="expendPlanbodycontainer">
        {activeComponent === "OutputsannualCost1" && <OutputsannualCost1 />}
        {activeComponent === "ActivitiesAnnualCosts" && (
          <ActivitiesAnnualCosts />
        )}
        {activeComponent === "ActivitiesCodeAnnualCosts" && (
          <ActivitiesCodeAnnualCosts />
        )}
      </div>

      {/* <div className="expendbodycontainer">
        {validComponents1.hasOwnProperty(activeComponent) ? (
          <>
            {React.createElement(validComponents1[activeComponent])}
          </>
        ) : (
          <div>
            Component not found
          </div>
        )}
      </div> */}
    </div>
  );
};

export default CoastedAnnualizedPlan1;
