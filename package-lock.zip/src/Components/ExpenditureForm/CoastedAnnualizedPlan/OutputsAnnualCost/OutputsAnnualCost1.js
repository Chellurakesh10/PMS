import React, { useState } from "react";
import './OutputsAnnualCost1.css'
import CustomInput from "../../../CustomInput/CustomInput";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import CustomButton from "../../../CustomButton/CustomButton";
import { useNavigate } from "react-router-dom";

const OutputsannualCost1 = () => {
  const navigate = useNavigate();
  const [outdata, setOutData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Outputs: "",
    TotalSubTotalOfExpenditureOutput:"",
    TotalSubTotalOfOutput:"",
    SelectFinancialYear:"",
    submitted:false
  });
  const [errors, setErrors] = useState("");
  const validateForm = () => {
    let newErrors = {};

    if(!outdata.ProgramName){
      newErrors.ProgramName = "Program Name is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  const handleChange = () => {};

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];

  const handleSaveandNext = (e) => {
    e.preventDefault()

    const isValid = validateForm()

    if(isValid){
      navigate("/ExpenditureForm/CoastedAnnualizedPlan1/", {
        state: {
          component: "ActivitiesAnnualCosts", 
 
        },
      });
    }


  }

  return (
    <div className="Oac-container-fluid">
      <div className="Oac-Head">
        <h1>Outputs Annual Cost</h1>
      </div>
      <div className="Oac-form">
        <div className="form-input">
          <label>Program Name :</label>
          <CustomInput
            type={"text"}
            name={"ProgramName"}
            placeholder={"Program Name"}
          />
          {errors.ProgramName && <p className="error">{errors.ProgramName}</p>}
        </div>
        <div className="form-input">
          <label>Program Code :</label>
          <CustomInput
            type={"text"}
            name={"ProgramCode"}
            placeholder={"Program Code"}
          />
          {errors.ProgramCode && <p className="error">{errors.ProgramCode}</p>}
        </div>
        <div className="form-input">
          <label>Project Name :</label>
          <CustomInput
            type={"text"}
            name={"ProjectName"}
            placeholder={"Project Name"}
          />{errors.ProjectName && <p className="error">{errors.ProjectName}</p>}
        </div>
        <div className="form-input">
          <label>Project Code :</label>
          <CustomInput
            type={"text"}
            name={"ProjectCode"}
            placeholder={"Project Code"}
          />
          {errors.ProjectCode && <p className="error">{errors.ProjectCode}</p>}
        </div>
      </div>
      <div className="Oac-form">
        <div className="Pa-info">
          <label>Outputs</label>
          <SelectCustom
            name="Outputs"
            options={OutputsOptions}
            value={outdata.TypesofFrameworks}
            onChange={handleChange}
          />
          {errors.Outputs && <p className="error">{errors.Outputs}</p>}
        </div>
        <div className="Pa-info">
          <label>Select Financial Year :</label>
          <SelectCustom
            name="SelectFinancialYear"
            value={outdata.SelectFinancialYear}
            options={SelectFinancialYearOptions}
            onChange={handleChange}
          />
          {errors.SelectFinancialYear && (
            <p className="error">{errors.SelectFinancialYear}</p>
          )}
        </div>
        <div className="Pa-info">
          <label>Annual Outcomes Cost(UGX) :</label>
          <CustomInput
            type={"text"}
            name={"AnnualOutcomesCost"}
            placeholder={"Annual Outcomes Cost(UGX)"}
          />
          {errors.AnnualOutcomesCost && <p className="error">{errors.AnnualOutcomesCost}</p>}
        </div>
        <div className="Pa-info">
          <label>Annual Expenditure Outcome Cost(UGX) :</label>
          <CustomInput
            type={"text"}
            name={"AnnualExpenditureOutcomesCost"}
            placeholder={"Annual Expenditure Outcomes Cost(UGX)"}
          />
          {errors.AnnualExpenditureOutcomesCost && <p className="error">{errors.AnnualExpenditureOutcomesCost}</p>}
        </div>
        <div className="Pa-info">
          <label>Total Sub Total Of Output(UGX) :</label>
          <CustomInput
            type={"text"}
            name={"TotalSubTotalOfOutput"}
            placeholder={"Total Sub Total Of Output(UGX)"}
          />
          {errors.TotalSubTotalOfOutput && <p className="error">{errors.TotalSubTotalOfOutput}</p>}
        </div>
        <div className="Pa-info">
          <label>Total Sub Total Of Expenditure Output(UGX) :</label>
          <CustomInput
            type={"text"}
            name={"TotalSubTotalOfExpenditureOutput"}
            placeholder={"Total Sub Total Of Expenditure Output(UGX)"}
          />
          {errors.TotalSubTotalOfExpenditureOutput && <p className="error">{errors.TotalSubTotalOfExpenditureOutput}</p>}
        </div>
        <div className="form-input">
          <CustomButton ButtonName={"+Add"} />
        </div>
      </div>

      <div className="Oac-form4">
        <CustomButton buttonstyle={"but"} onClick={"handleSaveandNext"} ButtonName={"Next"} />
      </div>
    </div>
  );
};

export default OutputsannualCost1;
