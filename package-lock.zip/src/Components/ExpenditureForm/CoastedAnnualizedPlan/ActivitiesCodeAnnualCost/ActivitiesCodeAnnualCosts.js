import React, { useState } from "react";
import "./ActivitiesCodeAnnualCosts.css";
import CustomButton from "../../../CustomButton/CustomButton";
import CustomInput from "../../../CustomInput/CustomInput";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import { useNavigate } from "react-router-dom";

const ActivitiesCodeAnnualCosts = () => {
  const [activitiesdata, setActivitiesData] = useState({
    programName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Activities: "",
    SelectFinancialYear: "",
    AnnualActivityCost: "",
    TotalSubTotalActivity: "",
    Outputs: "",
    submitted: false,
  });
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();

    if (isValid) {
      setActivitiesData({
        ...activitiesdata,
        submitted: true,
      });
      navigate("/expenditureForm", {
        state: { component: "AttachFiles1" },
      });
    } else {
      alert("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setActivitiesData({
      ...activitiesdata,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];
  const ActivitiesOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  return (
    <div className="container">
      <div className="ACA-fluid-container">
        <div className="ACA-head">
          <h1>Activities Code Annual Cost</h1>
        </div>
        <div className="ACA-form">
          <div className="ACA-inputs">
            <label>Program Name:</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"Program Name"}
            />
            {errors.ProgramName && <p className="error">{errors.ProgramName}</p>}
          </div>
          <div className="ACA-inputs">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
            />
            {errors.ProgramCode && <p className="error">{errors.ProgramCode}</p>}
          </div>
          <div className="ACA-inputs">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
            />
            {errors.ProjectName && <p className="error">{errors.ProjectName}</p>}
          </div>
          <div className="ACA-inputs">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
            />
            {errors.ProjectCode && <p className="error">{errors.ProjectCode}</p>}
          </div>
        </div>
        <div className="ACA-form2">
          <div className="ACA-label">
            <label>Output</label>
            <SelectCustom
              name="Outputs"
              options={OutputsOptions}
              value={activitiesdata.Outputs}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="ACA-label">
            <label>Activities</label>
            <SelectCustom
              name="Activities"
              options={ActivitiesOptions}
              value={activitiesdata.Activities}
              onChange={handleChange}
            />
            {errors.Activities && <p className="error">{errors.Activities}</p>}
          </div>
          <div className="ACA-label">
            <label>Code :</label>
            <CustomInput type={"text"} name={"Code"} placeholder={"Code"} />
            {errors.Code && <p className="error">{errors.Code}</p>}
          </div>
        </div>
        <div className="ACA-form3">
          <div className="ACA-add">
            <label>Name:</label>
            <CustomInput type={"text"} name={"Name"} placeholder={"Code"} />
            {errors.Name && <p className="error">{errors.Name}</p>}
          </div>
          <div className="ACA-add">
            <label>Select FinancialYear :</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={activitiesdata.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>
          <div className="ACA-add">
            <label>Annual Budgeting Cost(UGX):</label>
            <CustomInput type={"text"} name={"AnnualBudgetingCost"} placeholder={"Annual Budgeting Cost"} />
            {errors.AnnualBudgetingCost && <p className="error">{errors.AnnualBudgetingCost}</p>}
          </div>
          <div className="ACA-add">
            <label>Annual Expenditure Cost(UGX):</label>
            <CustomInput type={"text"} name={"AnnualExpenditureCost"} placeholder={"Code"} />
            {errors.AnnualExpenditureCost && <p className="error">{errors.AnnualExpenditureCost}</p>}
          </div>
          <div className="ACA-add">
            <label>Total Sub Total of Activity Code (UGX):</label>
            <CustomInput
              type={"text"}
              name={"TotalSubTotalofActivityCode"}
              placeholder={"Annual Activity Code Cost(UGX)"}
            />
            {errors.TotalSubTotalofActivityCode && <p className="error">{errors.TotalSubTotalofActivityCode}</p>}
          </div>
          <div className="ACA-add">
            <label>Total Expenditure Activity Code (UGX):</label>
            <CustomInput
              type={"text"}
              name={"TotalExpenditureActivityCode"}
              placeholder={"Total Expenditure Activity Code (UGX)"}
            />
            {errors.TotalExpenditureActivityCode && <p className="error">{errors.TotalExpenditureActivityCode}</p>}
          </div>
          <div className="ACA-add">
            <CustomButton ButtonName={"+Add"} />
          </div>
        </div>
        <div className="ACA-form5">
          <CustomButton buttonstyle={"But"} onClick={handleNext} ButtonName={"Next"} />
        </div>
      </div>
    </div>
  );
};

export default ActivitiesCodeAnnualCosts;
