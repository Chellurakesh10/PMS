import React, { useState } from "react";
import "./ActivitiesAnnualCosts.css";
import CustomButton from "../../../CustomButton/CustomButton";
import CustomInput from "../../../CustomInput/CustomInput";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import { useNavigate } from "react-router-dom";

const ActivitiesAnnualCosts = () => {
  const [formdata, setFormData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    AnnualCosts: "",
    submitted: false,
  });
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();

    if (isValid) {
      setFormData({
        ...formdata,
        submitted: true,
      });
      navigate("/expenditureForm/CoastedAnnualizedPlan", {
        state: { component: "ActivitiesCodeAnnualCost" },
      });
    } else {
      alert("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formdata,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];
  const ActivitiesOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  return (
    <div className="container">
      <div className="from-container-fluid">
        <div className="form-head">
          <h1>Activities Annual Cost</h1>
        </div>
        <div className="form-from1">
          <div className="form-input">
            <label>Program Name :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"ProgramName"}
            />
          </div>
          <div className="form-input">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
            />
          </div>
          <div className="form-input">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
            />
          </div>
          <div className="form-input">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"Project Code"}
              placeholder={"Project Code"}
            />
          </div>
        </div>
        <div className="Form-form2">
          <div className="form-label">
            <label>Output</label>
            <SelectCustom
              name="Outputs"
              options={OutputsOptions}
              value={formdata.Outputs}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="form-label">
            <label>Activities</label>
            <SelectCustom
              name="Activities"
              options={ActivitiesOptions}
              value={formdata.Activities}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
        </div>
        <div className="Form-form3">
          <div className="form-sec">
            <label>Select FinancialYear</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={formdata.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>
          <div className="form-sec">
            <label>Annual Activity Cost(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>
          <div className="form-sec">
            <label>Annual Expenditure Activity Cost(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>
          <div className="form-sec">
            <label>Sub Total Of Activity(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>

          <div className="form-sec">
            <label>Total Sub Total Activity (UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>
          <div className="form-sec">
            <CustomButton ButtonName={"Add"} />
          </div>
        </div>
        <div className="Form-form4">
          <div className="form-but">
            <CustomButton
              buttonStyle={"Net"}
              onClick={handleNext}
              ButtonName={"Next"}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivitiesAnnualCosts;
