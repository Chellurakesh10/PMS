import React, { useState } from "react";
import "./ProgramRegistration1.css";
import SelectCustom from "../../SelectCustom/SelectCustom";
import CustomInput from "../../CustomInput/CustomInput";

const ProgramRegistration1 = () => {
  const [formdata, setFormData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    ProjectDuration: "",
    StartDate: "",
    EndDate: "",
    TotalEstimatedCost: "",
    TotalExpenditureCost: "",
  });
  const ProgramNameOption = [
    { value: "Wemis", label: "Wemis" },
    { value: "Sanitation", label: "Sanitation" },
    { value: "Water", label: "water" },
    { value: "BoreHole", label: "BoreHole" },
    { value: "fssd", label: "fssd" },
    { value: "Option1", label: "Option1" },
    { value: "Option1", label: "Option1" },
    { value: "Option1", label: "Option1" },
  ];

  const ProgramCodeOption = [
    { value: "5578", label: "5578" },
    { value: "44444", label: "44444" },
    { value: "1324", label: "1324" },
    { value: "1246", label: "1246" },
    { value: "765", label: "765" },
    { value: "141414", label: "141414" },
    { value: "6539", label: "6539" },
  ]



  return (
    <div className="Pr-container">
      <div className="PR-container-fluid">
        <div className="head">
          <h1>ProgramRegistration</h1>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Program Name:</label>
            <SelectCustom
              name="ProgramName"
              value={formdata.ProgramName}
              placeholder="Program Name"
              options={ProgramNameOption}
            />
          </div>
          <div className="Pr-input">
            <label>Program Code:</label>
            <SelectCustom name="ProgramCode"
              placeholder="Program Code"
              value={formdata.ProgramName}
              options={ProgramCodeOption} />
          </div>
          <div className="Pr-input">
            <label>Stakeholders Department:</label>
            <CustomInput type={"text"}
              name={"StakeHoldersDepartment"}
              value={formdata.StakeHoldersDepartment}
              placeholder={"Stakeholders Department"} />
          </div>
        </div>
        <div className="head">
          <p>Program Duration</p>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Start Date</label>
            <CustomInput type={"date"}
              name="StartDate"
              value={formdata.StartDate}
              placeholder={"StartDate"} />
          </div>
          <div className="Pr-input">
            <label>Duration Years</label>
            <CustomInput type={"text"}
              name="DurationYears"
              value={formdata.DurationYears}
              placeholder={"DurationYears"} />
          </div>
          <div className="Pr-input">
            <label>End Date</label>
            <CustomInput type={"date"}
              name={"EndDate"}
              value={formdata.EndDate}
              placeholder={"EndDate"} />
          </div>
        </div>
        <div className="head">
          <p>Program Amount Details</p>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Total Estimated Cost(UGx)</label>
            <CustomInput
              type={"text"}
              placeholder={"Total Estimated Cost"}
              name={"TotalEstimatedCost"}
              value={formdata.TotalEstimatedCost}
            />
          </div>
          <div className="Pr-input">
            <label>Total Expenditure Cost(UGx)</label>
            <CustomInput
              type={"text"}
              placeholder={"Total Expenditure Cost"}
              name={"TotalExpenditureCost"}
              value={formdata.TotalExpenditureCost}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgramRegistration1;
