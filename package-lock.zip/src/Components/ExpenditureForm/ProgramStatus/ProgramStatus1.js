import React, {  useState } from "react";
import "./ProgramStatus1.css";
import CustomButton from "../../CustomButton/CustomButton";
import SelectCustom from "../../SelectCustom/SelectCustom";
import {  useNavigate } from "react-router-dom";

const ProgramStatus1 = () => {

  const [data, setData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    submitted: false,
  });

  const [errors, setErrors] = useState("");

  const navigate = useNavigate();

  const validateForm = () => {
    let newErrors = {};

    if (!data.ProgramName) {
      newErrors.ProgramName = "Program Name is Required";
    }
    if (!data.ProgramCode) {
      newErrors.ProgramCode = "Program Code is Required";
    }
    if (!data.ProjectName) {
      newErrors.ProjectName = "Project Name is Required";
    }
    if (!data.ProjectCode) {
      newErrors.ProjectCode = "Project Code is Required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  //   useEffect(() => {
  //   if (
  //     location.state?.component &&
  //     location.state.component !== activeComponent
  //   ) {
  //     setActiveComponent(location.state.component); // Switch component based on passed state
  //   }
  //   if (location.state?.data) {
  //     // Handle received data(if needed)
  //     console.log("Received data:", location.state.data);
  //   }
  // }, [location.state]);

  const handleSearch = (e) => {
    e.preventDefault();
  
    const isValid = validateForm();
  
    if (isValid) {
     
      navigate("/ExpenditureForm/", {
        state: {
          component: "CoastedAnnualizedPlan1", 
          data, 
        },
      });
    } else {
      alert("Form validation failed");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setData((prevData) => ({
      ...prevData,
      [name]: value,
      // Reset related fields when a parent field changes
      ...(name === "ProgramName" && { ProgramCode: "" }),
      ...(name === "ProjectName" && { ProjectCode: "" }),
    }));
  };


  const programNameOptions = [
    { value: "", label: "Choose List" },
    { value: "Wemis", label: "Wemis" },
    { value: "Water", label: "Water" },
    { value: "TestOne", label: "Test One" },
    { value: "Sanitation", label: "Sanitation" },
    { value: "PMS Test", label: "PMS Test" },
    { value: "Test", label: "Test" },
  ];

  const programCodeOptions = {
    Wemis: [{ value: "1", label: "1" }],
    Water: [{ value: "121212", label: "121212" }],
    TestOne: [{ value: "87", label: "87" }],
    Sanitation: [{ value: "4444", label: "4444" }],
    PMSTest: [{ value: "5676", label: "5676" }],
  };

  const projectNameOptions = [
    { value: "", label: "Choose List" },
    { value: "compilance", label: "compilance" },
    { value: "Permits", label: "Permits" },
  ];

  const projectCodeOptions = {
    compilance: [
      { value: "1", label: "1" },
      { value: "2", label: "2" },
      { value: "3", label: "3" },
      { value: "4", label: "4" },
      { value: "5", label: "5" },
    ],
    Permits: [
      { value: "1", label: "1" },
      { value: "2", label: "2" },
      { value: "3", label: "3" },
      { value: "4", label: "4" },
    ],
  };

  return (
    <div className="Ps-container">
      <div className="Ps-container-fluid">
        <div className="head">
          <h1>Program Status</h1>
        </div>
        <div className="Row">
          <div className="set">
            <label>Program Name:</label>
            <SelectCustom
              name="ProgramName"
              options={programNameOptions}
              value={data.ProgramName}
              onChange={handleChange}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="set">
            <label>Program Code:</label>
            <SelectCustom
              name="ProgramCode"
              options={
                programCodeOptions[data.ProgramName] || [
                  { value: "", label: "Choose List" },
                ]
              }
              value={data.ProgramCode}
              onChange={handleChange}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
          <div className="set">
            <label>Project Name:</label>
            <SelectCustom
              name="ProjectName"
              options={projectNameOptions}
              value={data.ProjectName}
              onChange={handleChange}
            />
            {errors.ProjectName && (
              <p className="error">{errors.ProjectName}</p>
            )}
          </div>
          <div className="set">
            <label>Project Code:</label>
            <SelectCustom
              name="ProjectCode"
              options={
                projectCodeOptions[data.ProjectName] || [
                  { value: "", label: "Choose from list" },
                ]
              }
              value={data.ProjectCode}
              onChange={handleChange}
            />
            {errors.ProjectCode && (
              <p className="error">{errors.ProjectCode}</p>
            )}
          </div>
        </div>
        <div className="search">
          <CustomButton ButtonName={"Search"} onClick={handleSearch} />
        </div>
      </div>
    </div>
  );
};

export default ProgramStatus1;
