import React, { useState } from "react";
import "./AttachFiles1.css";
import CustomInput from "../../CustomInput/CustomInput";
import SelectCustom from "../../SelectCustom/SelectCustom";
import CustomButton from "../../CustomButton/CustomButton";

const AttachFiles1 = () => {
  const [filedata, setFileData] = useState({
    SelectFinancialYear: "",
    Description: "",
    AttachFiles: null,
    Submitted: false,
  });

  const [fileList, setFileList] = useState([]); 
  const [preview, setPreview] = useState(null);

  const SelectFinancialYearoption = [
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
    { value: "2024", label: "2024" },
  ];

  const validateForm = () => {
    return (
      filedata.SelectFinancialYear !== "" &&
      filedata.Description !== "" &&
      filedata.AttachFiles !== null
    );
  };


  const handlePreview = () => {
    if (validateForm()) {
      setPreview({
        SelectFinancialYear: filedata.SelectFinancialYear,
        Description: filedata.Description,
        AttachFiles: URL.createObjectURL(filedata.AttachFiles),
      });
    } else {
      alert("Please fill out the form correctly.");
    }
  };


  const handleAddFile = () => {
    if (validateForm()) {
      const newFile = {
        SelectFinancialYear: filedata.SelectFinancialYear,
        Description: filedata.Description,
        AttachFiles: filedata.AttachFiles,
      };
      setFileList([...fileList, newFile]); // Add the new file to the fileList
      setFileData({ SelectFinancialYear: "", Description: "", AttachFiles: null }); // Reset form
    } else {
      alert("Please fill out all fields.");
    }
  };

  const handleFileChange = (e) => {
    setFileData({
      ...filedata,
      AttachFiles: e.target.files[0],
    });
  };

  const handleInputChange = (e) => {
    setFileData({
      ...filedata,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="attachcontainer">
      <div className="attachfluid-container">
        <div className="head">
          <h1>Attach Files</h1>
        </div>
        <h4>Attach any related files here (up to 5 MB)</h4>
        <div className="AF-form">
          <div className="Af-input">
            <label>Select Financial Year</label>
            <SelectCustom
              name={"SelectFinancialYear"}
              value={filedata.SelectFinancialYear}
              options={SelectFinancialYearoption}
              onChange={(selectedOption) =>
                setFileData({ ...filedata, SelectFinancialYear: selectedOption.value })
              }
            />
          </div>
          <div className="Af-input">
            <label>Description</label>
            <CustomInput
              type={"text"}
              placeholder={"Description"}
              name={"Description"}
              value={filedata.Description}
              onChange={handleInputChange}
            />
          </div>
          <div className="Af-input">
            <label>Attach Files</label>
            <CustomInput
              type={"file"}
              name={"AttachFiles"}
              onChange={handleFileChange}
              placeholder={"Attach Files"}
            />
          </div>

          <div className="Af-input">
            <CustomButton buttonstyle={"add"} ButtonName={"ADD"} onClick={handleAddFile} /> {/* Add file to table */}
          </div>
        </div>

        {/* Display the table */}
        <div className="Af-Tab">
          <table>
            <thead>
              <tr>
                <th>Financial Year</th>
                <th>File Description</th>
                <th>Attach Files</th>
                <th>View</th>
                <th>Update</th>
                <th>Update With File</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {fileList.map((file, index) => (
                <tr key={index}>
                  <td>{file.SelectFinancialYear}</td>
                  <td>{file.Description}</td>
                  <td>{file.AttachFiles.name}</td>
                  <td>
                    <button onClick={() => window.open(URL.createObjectURL(file.AttachFiles))}>
                      View
                    </button>
                  </td>
                  <td>
                    <button>Update</button>
                  </td>
                  <td>
                    <button>Update With File</button>
                  </td>
                  <td>
                    <button
                      onClick={() => {
                        const updatedList = fileList.filter((_, i) => i !== index);
                        setFileList(updatedList); 
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="Af-but">
          <CustomButton ButtonName={"Preview"} onClick={handlePreview} />
        </div>

        {preview && (
          <div className="preview-section">
            <h2>Preview</h2>
            <p>
              <strong>Financial Year:</strong> {preview.SelectFinancialYear}
            </p>
            <p>
              <strong>Description:</strong> {preview.Description}
            </p>
            {preview.AttachFiles && (
              <div>
                <strong>Attached File:</strong>
                <img
                  src={preview.AttachFiles}
                  alt="Preview"
                  style={{ maxWidth: "100%", height: "50%" }}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default AttachFiles1;
