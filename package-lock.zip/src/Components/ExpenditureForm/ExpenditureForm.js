import React, { useEffect, useState } from "react";
import "./ExpenditureForm.css";
import { MdAppRegistration } from "react-icons/md";
import { SiRobotframework } from "react-icons/si";
import { IoDocumentAttachSharp } from "react-icons/io5";
import { GrStatusUnknown } from "react-icons/gr";
import { SiInfracost } from "react-icons/si";
import CoastedAnnualizedPlan1 from "./CoastedAnnualizedPlan/CoastedAnnualizedPlan1";
import ProjectFrameworks2 from "./ProjectFrameworks2/ProjectFrameworks2";
import AttachFiles1 from "./AttachFiles1/AttachFiles1";
import ProgramStatus1 from "./ProgramStatus/ProgramStatus1";
import ProgramRegistration1 from "./ProgramRegistration/ProgramRegistration1";
import { useLocation, useNavigate } from "react-router-dom";

const ExpenditureForm = () => {
  const tabName = useLocation();
  const navigate = useNavigate();

  const [activeComponent, setActiveComponent] = useState(
    tabName.state?.component || "ProgramStatus1"
  );

  useEffect(() => {
    if (tabName.state?.component && tabName.state.component !== activeComponent) {
      setActiveComponent(tabName.state.component);
    }
  }, [tabName.state,activeComponent]);

  const handleButtonClick = (component) => {
    setActiveComponent(component);
    navigate("/ExpenditureForm/", { state: { component } });
  };

  const validComponents = [
    "ProgramStatus1",
    "CoastedAnnualizedPlan1",
    "AttachFiles1",
    "ProjectFrameworks2",
    "ProgramRegistration1",
  ];

  return (
    <div className="expendcontainer">
      <div className="Efsidecontainer">
        <ul>
          <li>
            <button
              className={
                activeComponent === "ProgramStatus1" ? "active-link focus" : ""
              }
              onClick={() => handleButtonClick("ProgramStatus1")}
            >
              <span>
                <GrStatusUnknown /> Program Status
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "CoastedAnnualizedPlan1"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("CoastedAnnualizedPlan1")}
            >
              <span>
                <MdAppRegistration /> Coasted Annualized Plan
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "AttachFiles1" ? "active-link focus" : ""
              }
              onClick={() => handleButtonClick("AttachFiles1")}
            >
              <span>
                <IoDocumentAttachSharp />
                Attach Files
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "ProjectFrameworks2"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("ProjectFrameworks2")}
            >
              <span>
                <SiInfracost /> Project Frameworks
              </span>
            </button>
          </li>
          <li>
            <button
              className={
                activeComponent === "ProgramRegistration1"
                  ? "active-link focus"
                  : ""
              }
              onClick={() => handleButtonClick("ProgramRegistration1")}
            >
              <span>
                <SiRobotframework /> Program Registration
              </span>
            </button>
          </li>
        </ul>
      </div>
      <div className="expendbodycontainer">
        {validComponents.includes(activeComponent) ? (
          <>
            {activeComponent === "ProgramStatus1" && <ProgramStatus1 />}
            {activeComponent === "CoastedAnnualizedPlan1" && (
              <CoastedAnnualizedPlan1 />
            )}
            {activeComponent === "AttachFiles1" && <AttachFiles1 />}
            {activeComponent === "ProjectFrameworks2" && <ProjectFrameworks2 />}
            {activeComponent === "ProgramRegistration1" && (
              <ProgramRegistration1 />
            )}
          </>
        ) : (
          <div>Component not found</div>
        )}
      </div>
    </div>
  );
};

export default ExpenditureForm;
