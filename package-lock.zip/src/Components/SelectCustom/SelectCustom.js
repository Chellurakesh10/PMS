import React from "react";
import "./SelectCustom.css";


const SelectCustom = (props) => {
  const { value, name, className, options, onChange } = props; 

  return (
    <div>
      <select
        name={name}
        className={className || "info"}
        value={value}
        onChange={onChange} 
      >
        {options &&
          options.map((option, index) => (
            <option key={index} value={option.value}>
              {option.label}
            </option>
          ))}
      </select>
    </div>
  );
};

export default SelectCustom;
