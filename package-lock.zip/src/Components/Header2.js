import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import { NavLink } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars, faTimes } from "@fortawesome/free-solid-svg-icons";
import AvatarDropdown from "./AvatarDropdown";
// import NavigationLinks from "./NavigationLinks";
import "../CSS/Header2.css"; // External CSS
import { RxDashboard } from "react-icons/rx";
import { RxActivityLog } from "react-icons/rx";
import { GiExpense } from "react-icons/gi";
import { GiMasterOfArms } from "react-icons/gi";
import { AiOutlineTeam } from "react-icons/ai";
import { TbReport } from "react-icons/tb";
import NavigationLinks from "./NavigationLinks";
// import SidebarNav from "./SidebarNav/SidebarNav";

const Header2 = ({ isAuthenticated, logout, toggleSlider, sliderOpen }) => {
  const location = useLocation();
  const [focusedLink, setFocusedLink] = useState(null);

  const handleLinkClick = (path) => {
    setFocusedLink(path);
  };

  if (location.pathname === "/") {
    return null; // Hide header on the login page
  }

  return (
    <div className="pf-container">
      <div className="pf-container-fluid">
        <div className="pf-form">
          {/* Logo and Avatar together in Header */}
          <div className="Header">
            <div className="header-center">
              {/* Logo */}
              <img
                src="\logoImages\WhatsApp Image 2024-08-26 at 12.50.32_f3555b0e.jpg"
                alt="logo"
                className="logo-img"
              />
            </div>

            {/* Navigation Links */}
            <ul className="nav-links">
              <li>
                <NavLink
                  to="/dashboard"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/dashboard"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/dashboard")}
                >
                  <span>
                    <RxDashboard />
                    Dashboard
                  </span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/activityDashboard"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/activityDashboard"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/activityDashboard")}
                >
                  <span>
                    <RxActivityLog />
                    Activity Dashboard
                  </span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/budgetingForm"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/budgetingForm"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/budgetingForm")}
                >
                  <span>
                    <AiOutlineTeam />
                    Budgeting Form
                  </span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/expenditureForm"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/expenditureForm"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/expenditureForm")}
                >
                  <span>
                    <GiExpense />
                    Expenditure Form
                  </span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/masters"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/masters"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/masters")}
                >
                  <span>
                    <GiMasterOfArms />
                    Masters
                  </span>
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/Reports"
                  className={({ isActive }) =>
                    isActive || focusedLink === "/Reports"
                      ? "active-link focus"
                      : ""
                  }
                  onClick={() => handleLinkClick("/Reports")}
                >
                  <span>
                    <TbReport />
                    Reports
                  </span>
                </NavLink>
              </li>
            </ul>

            <div className="avatar-container">
              <AvatarDropdown logout={logout} />
            </div>
          </div>
        </div>

        <div className="Slider">
          <div className="slider-menu" onClick={toggleSlider}>
            <FontAwesomeIcon icon={faBars} />
          </div>
          <div className={`Slider-form ${sliderOpen ? "active" : ""}`}>
            <div className="slider-cross" onClick={toggleSlider}>
              <FontAwesomeIcon icon={faTimes} />
            </div>
            <NavigationLinks toggleSlider={toggleSlider} />
          </div>
          <div className="header-center">
            {/* Logo */}
            
            <img
              src="\logoImages\WhatsApp Image 2024-08-26 at 12.50.32_f3555b0e.jpg"
              alt="logo"
              className="logo-img"
            />
          </div>
          <div className="avatar-container">
            <AvatarDropdown logout={logout} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header2;
