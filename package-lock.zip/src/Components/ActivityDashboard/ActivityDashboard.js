import React, { useState } from "react";
import { GoFileSubmodule } from "react-icons/go";
import { RiFolderReceivedLine } from "react-icons/ri";
import { GrInProgress } from "react-icons/gr";
import { FcApproval } from "react-icons/fc";
import { VscReferences } from "react-icons/vsc";
// import { MdApproval } from "react-icons/md";
import { NavLink } from "react-router-dom";
import "./ActivityDashboard.css";

const ActivityDashboard = () => {


  const [focusedLink, setFocusedLink] = useState("SubmittedForms");

  const handleLinkClick = (path) => {
    setFocusedLink(path);
  };

  return (
    <div className="Ad-container">
      <div className="Ad-fluid-container">
        <div className="Ad-head">
          <h1>Activity Dashboard</h1>
        </div>
        <div className="Ad-form">
          <ul>
            <li>
              <NavLink
                to="/activityDashboard/SubmittedForms"
                className={({ isActive }) =>
                  isActive || focusedLink === "/activityDashboard/SubmittedForms"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleLinkClick("/activityDashboard/SubmittedForms")}
              >
                <span><GoFileSubmodule />Submitted Form</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/activityDashboard/receivedForms"
                className={({ isActive }) =>
                  isActive || focusedLink === "/activityDashboard/receivedForms"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleLinkClick("/activityDashboard/receivedForms")}
              >
                <span><RiFolderReceivedLine />Received Form</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/activityDashboard/inProgressForms"
                className={({ isActive }) =>
                  isActive || focusedLink === "/activityDashboard/inProgressForms"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleLinkClick("/activityDashboard/inProgressForms")}
              >
                <span><GrInProgress/>InProgress Form</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/activityDashboard/approvedForms"
                className={({ isActive }) =>
                  isActive || focusedLink === "/activityDashboard/approvedForms"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleLinkClick("/activityDashboard/approvedForms")}
              >
                <span>< FcApproval /> Approved Forms</span>
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/activityDashboard/referBackForms"
                className={({ isActive }) =>
                  isActive || focusedLink === "/activityDashboard/referBackForms"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleLinkClick("/activityDashboard/referBackForms")}
              >
                <span><VscReferences />Refer Back Forms</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ActivityDashboard;
