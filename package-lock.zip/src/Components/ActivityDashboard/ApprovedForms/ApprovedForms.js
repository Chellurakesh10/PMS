import React from "react";
// import Header from "../../Header";
import "./ApprovedForm.css";
import CustomInput from "../../CustomInput/CustomInput";
import ActivityDashboard from "../ActivityDashboard";
import { AiFillEye } from "react-icons/ai";
import CustomButton from "../../CustomButton/CustomButton";

const ApprovedForms = () => {
  return (
    <div className="App-Container">
      {/* <Header /> */}
      <ActivityDashboard />
      <div className="App-fluid-container">
        <h1>Approved Forms</h1>
        <div className="App-form">
          <CustomInput type={"text"} placeholder={"Search"} />
        </div>
        <div className="App-Tab">
          <table>
            <thead>
              <tr>
                <th>Program Name</th>
                <th>Program Code</th>
                <th>Project Name</th>
                <th>Project Code</th>
                <th>Department</th>
                <th>Application Type</th>
                <th>Application Status</th>
                <th>Approved By</th>
                <th>Approved Date</th>
                <th>Form View</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td> </td>
                <td>
                  <CustomButton ButtonName={<AiFillEye />} />
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ApprovedForms;
