import React from "react";
import './SubmittedForms.css'
// import Header from '../../Header'
import CustomInput from "../../CustomInput/CustomInput";
import ActivityDashboard from "../ActivityDashboard";

const SubmittedForms = () => {
  console.log("SubmittedForms component is rendered.");
  return (
    <div className="Ap-Container">
      {/* <Header /> */}
      <ActivityDashboard />
      <div className="Ap-fluid-container">
        <h1>SubmittedForms</h1>
        <div className="Ap-form">
          <div className="Ap-input">
            <CustomInput type={"text"} placeholder={"Search"} />
          </div>
        </div>
        {/* <div className="sub-Tab">
          <table className="sub-input">
            <thead>
              <tr>
                <th>Program Name</th>
                <th>Program Code</th>
                <th>Project Name</th>
                <th>Project Code</th>
                <th>Department</th>
                <th>Application Type</th>
                <th>Application Status</th>
                <th>Submitted Date</th>
                <th>Form View</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                  <button>Status</button>
                </td>
                <td>
                  <button>Submit</button>
                </td>
                <td>
                  <button>fromveiw</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div> */}
      </div>
    </div>
  );
};

export default SubmittedForms;
