import React from "react";
// import Header from '../../Header'
import './InprogressForms.css'
import CustomInput from "../../CustomInput/CustomInput";
import ActivityDashboard from "../ActivityDashboard";
// import CustomButton from "../../CustomButton/CustomButton";

const InProgressForms = () => {
  return (
    <div className="inp-Container">
      {/* <Header /> */}
      <ActivityDashboard />
      <div className="inp-fluid-container">
        <h1>InProgress Forms</h1>
        <div className="inp-form">
          <CustomInput type={"text"} placeholder={"Search"} />
        </div>
        {/* <div className="inp-Tab">
          <table className="inp-input">
            <thead>
              <tr>
                <th>Program Name</th>
                <th>Program Code</th>
                <th>Project Name</th>
                <th>Project Code</th>
                <th>Department</th>
                <th>Application Type</th>
                <th>Application Status</th>
                <th>Current User</th>
                <th>Forwarded Date</th>
                <th>Form View</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                  <CustomButton ButtonName={"Form View"}/>
                </td>
              </tr>
            </tbody>
          </table>
        </div> */}
      </div>
    </div>
  );
};

export default InProgressForms;
