import React from "react";
import './ReceivedForms.css'
// import Header from "../../Header";
import CustomInput from "../../CustomInput/CustomInput";
import ActivityDashboard from "../ActivityDashboard";
// import CustomButton from "../../CustomButton/CustomButton";

const ReceivedForms = () => {
  return (
    <div className="rec-Container">
      {/* <Header /> */}
      <ActivityDashboard />
      <div className="rec-fluid-container">
        <h1>Received Forms</h1>
        <div className="Ap-form">
          <CustomInput type={"text"} placeholder={"Search"} />
        </div>
        {/* <div className="rec-Tab">
          <table className="rec-input">
            <thead>
              <tr>
                <th>Program Name</th>
                <th>Program Code</th>
                <th>Project Name</th>
                <th>Project Code</th>
                <th>Department</th>
                <th>Application Type</th>
                <th>Application Status</th>
                <th>Forwarded By</th>
                <th>Forwarded Date</th>
                <th>Form View</th>
                <th>Approve</th>
                <th>Refer Back</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td><CustomButton ButtonName={"Forwarded By"} /></td>
                <td><CustomButton ButtonName={"FormView"}/></td>
                <td>
                
                  <CustomButton  ButtonName={"Approve"}/>
                </td>
                <td>
                  <CustomButton  ButtonName={"Refer Back"}/>

                </td>
              </tr>
            </tbody>
          </table>
        </div> */}
      </div>
    </div>
  );
};

export default ReceivedForms;
