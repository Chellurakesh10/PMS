import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserCircle, faSignOutAlt } from "@fortawesome/free-solid-svg-icons";

const AvatarDropdown = ({ userName }) => {
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleLogout = () => {
    // Perform any logout logic here, e.g., clearing user tokens
    localStorage.removeItem('token'); // Assuming you're using localStorage to store the auth token
    navigate("/"); // Redirect to the home page
  };

  return (
    <div className="avatar-container">
      <img
        src="/logoImages/Avatar1.png"
        alt="avatar"
        className="avatar-image"
        onClick={toggleDropdown}
      />
      {dropdownOpen && (
        <div className="dropdown-menu">
          <div className="dropdown-item">
            <span className="user-name">{userName}</span>
          </div>
          <Link to="/my-profile" className="dropdown-item">
            <FontAwesomeIcon icon={faUserCircle} /> My Profile
          </Link>
          <div className="dropdown-item" onClick={handleLogout}>
            <FontAwesomeIcon icon={faSignOutAlt} /> Logout
          </div>
        </div>
      )}
    </div>
  );
};

export default AvatarDropdown;
