import React, { useState } from "react";
import NavigationLinks from "./NavigationLinks";
import BudgetingForm from "../Components/BugetingForms/BudgetingForm";

const ButtonNavLink = ({ to, toggleSlider, label, className }) => {
  const [selectedForm, setSelectedForm] = useState(""); // Shared state

  const handleFormSelection = (form) => {
    setSelectedForm(form); // Update state when a form is selected from navigation
  };

  return (
    <div>
      <NavigationLinks handleFormSelection={handleFormSelection} />
      <BudgetingForm selectedForm={selectedForm} />
    </div>
  );
};

export default ButtonNavLink;
