import React from "react";
import Select from "react-select";

const CustomSelectMultiple = (props) => {
  const { value, name, options, onChange, isMulti } = props;
  return (
    <div>
      <Select
        name={name}
        options={options}
        value={options.filter((option) => value.includes(option.value))} // Match selected values
        onChange={(selectedOptions) => {
          const values = selectedOptions
            ? selectedOptions.map((option) => option.value)
            : [];
          onChange({ name, value: values }); // Pass the selected values (array) to the onChange handler
        }}
        isMulti={isMulti}
      />
    </div>
  );
};

export default CustomSelectMultiple;
