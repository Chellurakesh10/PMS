import React from "react";
import "./Reports.css";
import SelectCustom from "../SelectCustom/SelectCustom";
import CustomButton from "../CustomButton/CustomButton";

function Reports() {
  // const [formdata, setFormdata] = useState({
  //   FilterBy: "",
  // });
  const FilterByOptions = [
    { value: "Over All Project", label: "Over All Project" },
    { value: "Project Wise", label: "Project Veiw" },
    { value: "OverView", label: "OverView" },
  ];
  const ProjectNameOptions = [
    { value: "Sanitation of the country", label: "Over All Project" },
    { value: " Permits", label: "Permits" },
    { value: "Test", label: "Test" },
    { value: "Compliance", label: "Compliance" },
  ];
  const ProjectCodeOptions = [
    { value: "141414", label: "141414" },
    { value: "65", label: "65" },
    { value: "777", label: "777" },
    { value: "3468", label: "3468" },
  ];
  const ProjectFilterByOptions = [
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
    { value: "2024", label: "2024" },
  ];
  return (
    <div className="reportconatiner">
      <div className="reportfluid-container">
        <div className="head">
          <h1>Reports</h1>
        </div>
        <div className="reportform">
          <div className="reportinput">
            <label>Filter By</label>
            <SelectCustom
              name={"FilterBy"}
              value={"formdata.FilterBy"}
              options={FilterByOptions}
            />
          </div>
        </div>

        <div className="reportform">
          <div className="reportinput">
            <label>Project Name</label>
            <SelectCustom
              name={"ProjectName"}
              value={"formdata.ProjectName"}
              options={ProjectNameOptions}
            />
          </div>
          <div>
            <label>Project Code</label>
            <SelectCustom
              name={"ProjectCode"}
              value={"formdata.ProjectCode"}
              options={ProjectCodeOptions}
            />
          </div>
          <div>
            <label>Filter By</label>
            <SelectCustom
              name={"ProjectFilterBy"}
              value={"formdata.ProjectFilterBy"}
              options={ProjectFilterByOptions}
            />
          </div>
        </div>

        <div>
          <CustomButton ButtonName={"Get Report"} />
        </div>
      </div>
    </div>
  );
}

export default Reports;
