import React, { useRef } from "react";
import html2pdf from "html2pdf.js";
import "./BudgetPdf.css";
import ProgramRegistration2 from "../ProgramRegistration/ProgramRegistration2/ProgramRegistration2";
import ProjectRegistration from "../ProjectFrameworks/ProjectRegistration/ProjectRegistration";
import ProjectGoalsAndOutcomes from "../ProjectFrameworks/ProjectGoalsAndOutcomes/ProjectGoalsAndOutcomes";
import Indicators from "../ProjectFrameworks/Indicators/Indicators";
import PerfomanceIndicator from "../ProjectFrameworks/PerfomanceIndicator/PerfomanceIndicator";
import ProjectActivities from "../ProjectFrameworks/ProjectActivities/ProjectActivities";
import OutputsannualCost from "../CoastedAnnualizedPlan/OutputsAnnualCost/OutputsannualCost";
import AcitivitiesAnnualCost from "../CoastedAnnualizedPlan/AcitivitiesAnnualCost/AcitivitiesAnnualCost";
import ActivitiesCodeAnnualCost from "../CoastedAnnualizedPlan/ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCost";
import AttachFiles from "../AttachFiles/AttachFiles";
import ProjectList from "../ProgramRegistration/ProjectList/ProjectList";
import { AiFillEye } from "react-icons/ai";

const BudgetPdf = () => {
  const printRef = useRef();
  const [budgeting, setBudgeting] = useState({
    ProgramName: "",
    ProgramCode: "",
    StakeHoldersDepartment: "",
    StartDate: "",
    DurationYear: "0",
    EndDate: "",
    submitted: false,
  });
  const [listdata, setListData] = useState({
    ProgramName: "",
    ProgramCode: "",
    EnterAllFundersWithCommaSeperate: "",
    EstimatedProjectCostwithoutCommaUGX: "",
    TotalEstimateCostUGX: "",
    submitted: false,
  });
  const [form, setForm] = useState({
    SelectFinancialYear: "",
    Description: "",
    AttachFiles: null,
    Submitted: false,
  });
  const [activitiesCodeData, setActivitiesCodedata] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Outputs: "",
    Activities: "",
    Code: "",
    Name: "",
    SelectFinancialYear: "",
    AnnualActivityCodeCost: "",
    AnnualActivityCodeCost: "",
    submitted: false,
  });
  const [activitiesdata, setActivitiesData] = useState({
    Activities: "",
    SelectFinancialYear: "",
    AnnualActivityCost: "",
    TotalSubTotalActivity: "",
    Outputs: "",
    submitted: false,
  });
  const [Outputdata, setOutputData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Outputs: "",
    SelectFinancialYear: "",
    AnnualOutcomesCost: "",
  });
  const [activitiesdData, setActivitiesData1] = useState({
    ProgramName: "",
    ProgramCode: "",
    Outputs: "",
    submitted: false,
  });
  const [form1, setForm1] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    TypesofFrameworks: "",
    FrameworksDescription: "",
    IndicatorsList: "",
    TypeIndicatorPerfomance: "",
    SelectFinancialYear: "",
    MeansVerification: "",
    Assumption: "",
    Risks: "",
    submitted: false,
  });
  const [form2, setForm22] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    TypesofFrameworks: "",
    FrameworksDescription: "",
    Indicators: [""], // Initial array to handle multiple indicators
    submitted: false,
  });
  const [formdata, setFormdata] = useState({
    Program: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    ProjectGoals: "",
    Outcomes: [""], // Initialize with one empty outcome
    ComponentOutputs: [""], // Initialize with one empty component/output
    Submitted: false,
  });

  const handleDownloadPdf = () => {
    const element = printRef.current;
    if (!element) {
      console.error("No element to export to PDF");
      return;
    }
    const options = {
      margin: [0.5, 0.5],
      filename: "BudgetForm.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
    };

    html2pdf()
      .set(options)
      .from(element)
      .save()
      .then(() => {
        console.log("PDF successfully generated");
      })
      .catch((err) => {
        console.error("Error generating PDF: ", err);
        alert("There was an error generating the PDF. Please try again.");
      });
  };

  return (
    <div className="Container">
      <div ref={printRef} id="budgetForm" style={{ padding: "20px" }}>
        <h1>BUDGET FORM</h1>
        {/*1. Program Registration */}
        <div className="form-container">
          <h2>PROGRAM REGISTRATION</h2>
          <ProgramRegistration2
            budgeting={budgeting}
            setBudgeting={setBudgeting}
          />
          <div className="Table1">
            <div className="form-table1">
              <h3>Main Details</h3>
              <table>
                <thead>
                  <tr>
                    <th>Program Name</th>
                    <th>Program Code</th>
                    <th>Stakeholders department</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{budgeting.ProgramName}</td>
                    <td>{budgeting.ProgramCode}</td>
                    <td>{budgeting.StakeHoldersDepartment}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="form-table1">
              <h3>Program Duration</h3>

              <table>
                <thead>
                  <tr>
                    <th>Start Date</th>
                    <th>Duration years</th>
                    <th>End Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{budgeting.StartDate}</td>
                    <td>{budgeting.DurationYear}</td>
                    <td>{budgeting.EndDate}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="form-table1">
              <h4>Project List Table</h4>
              <ProjectList listdata={listdata} setListData={setListData} />
              <table>
                <thead>
                  <tr>
                    <th>Program Name</th>
                    <th>Program Code</th>
                    <th>Funder List</th>
                    <th>Estimated Project Cost(UGX)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{listdata.ProgramName}</td>
                    <td>{listdata.ProgramCode}</td>
                    <td>{listdata.EnterAllFundersWithCommaSeperate}</td>
                    <td>{listdata.EstimatedProjectCostwithoutCommaUGX}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {/*2. Project Registration */}
        <div className="form-container">
          <h2>PROJECT REGISTRATION</h2>
          <ProjectRegistration />
          <div className="Table1">
            <div className="form-table1">
              <h3>Main Details</h3>
              <table>
                <thead>
                  <tr>
                    <th>Program Name</th>
                    <th>Program Code</th>
                    <th>Project Name</th>
                    <th>Project Code</th>
                    <th>Department</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="form-table1">
              <h3>Program Duration</h3>
              <table>
                <thead>
                  <tr>
                    <th>Start Date</th>
                    <th>Duration (years)</th>
                    <th>End Date</th>
                    <th>Funders</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="form-table1">
              <h3>Responsible Officer</h3>
              <table>
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {/* 3.Project Goals And OutComes */}
        <div className="form-container">
          <h4>Project Goals And Outcomes</h4>
          <ProjectGoalsAndOutcomes
            formdata={formdata}
            setFormdata={setFormdata}
          />
          <div className="Table">
            <div className="form-table">
              <table>
                <thead>
                  <tr>
                    <th>Outcomes</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{formdata.Outcomes} </td>
                    <td>{formdata.Name}</td>
                    <td>{formdata.MobileNumber} </td>
                    <td>{formdata.Email}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        {/* Indicators */}
        <div className="form-container">
          <h4>Indicators</h4>
          <Indicators form2={form2} setForm22={setForm22} />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Types Of Framework</th>
                  <th>Framework Description</th>
                  <th>Indicators</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{form2.TypesofFrameworks} </td>
                  <td>{form2.FrameworksDescription} </td>
                  <td>{form2.Indicators} </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Perfomance Indicator */}
        <div className="form-container">
          <h4>Yearly Performance Indicators</h4>
          <PerfomanceIndicator form1={form1} setForm1={setForm1} />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Type Of Framework</th>
                  <th>Framework Description</th>
                  <th>Indicators</th>
                  <th>Financial Year</th>
                  <th>Indicators Performance</th>
                  <th>Indicator Type</th>
                  <th>Means Of Verification</th>
                  <th>Assumptions</th>
                  <th>Risks</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{form1.TypesofFrameworks}</td>
                  <td>{form1.FrameworksDescription}</td>
                  <td>{form1.Indicators}</td>
                  <td>{form1.SelectFinancialYear}</td>
                  <td>{form1.TypeIndicatorPerfomance}</td>
                  <td>{form1.IndicatorType}</td>
                  <td>{form1.MeansVerification}</td>
                  <td>{form1.Assumption}</td>
                  <td>{form1.Risks}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Activities */}
        <div className="form-container">
          <h4>Activities</h4>
          <ProjectActivities
            activitiesdData={activitiesdData}
            setActivitiesData1={setActivitiesData1}
          />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Outputs</th>
                  <th>Activities</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{activitiesdData.Outputs}</td>
                  <td>{activitiesdData.Activities}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Output Annual Plan Cost */}
        <div className="form-container">
          <h4>Output Annual Plan Cost</h4>
          <OutputsannualCost
            Outputdata={Outputdata}
            setOutputData={setOutputData}
          />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Outputs</th>
                  <th>Financial Year</th>
                  <th>Annual Financial Year Cost</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{Outputdata.Outputs}</td>
                  <td>{Outputdata.SelectFinancialYear}</td>
                  <td>{Outputdata.AnnualOutcomesCost}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Activities Annual Plan Cost */}
        <div className="form-container">
          <h4>Activity Annual Plan Cost</h4>
          <AcitivitiesAnnualCost
            activitiesdata={activitiesdata}
            setActivitiesData={setActivitiesData}
          />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Outputs</th>
                  <th>Activities</th>
                  <th>Financial Year</th>
                  <th>Annual Financial Year Cost</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{activitiesdata.Outputs}</td>
                  <td>{activitiesdata.Activities}</td>
                  <td>{activitiesdata.SelectFinancialYear}</td>
                  <td>{activitiesdata.AnnualActivityCost}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Activities Code Annual Plan Cost */}
        <div className="form-container">
          <h4>Activity Code Annual Plan Cost</h4>
          <ActivitiesCodeAnnualCost
            activitiesCodeData={activitiesCodeData}
            setActivitiesCodedata={setActivitiesCodedata}
          />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Outputs</th>
                  <th>Activities</th>
                  <th>Activity Code</th>
                  <th>Activity Name</th>
                  <th>Financial Year</th>
                  <th>Annual Financial Year Cost(UGX)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{activitiesCodeData.Outputs}</td>
                  <td>{activitiesCodeData.Activities}</td>
                  <td>{activitiesCodeData.Code}</td>
                  <td>{activitiesCodeData.Name}</td>
                  <td>{activitiesCodeData.FinancialYear}</td>
                  <td>{activitiesCodeData.AnnualActivityCodeCost}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        {/* Attach Files */}
        <div className="form-container">
          <h4>Attach Files</h4>
          <AttachFiles form={form} setForm={setForm} />
          <div className="form-table">
            <table>
              <thead>
                <tr>
                  <th>Financial Year</th>
                  <th>Description</th>
                  <th>Attach Files</th>
                  <th>View</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{form.FinancialYear}</td>
                  <td>{form.Description}</td>
                  <td>{form.AttachFiles}</td>
                  <td>
                    <button className="view">
                      <AiFillEye />
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="form-but">
          <div>
            <button onClick={handleDownloadPdf}>Download</button>
          </div>
          <div>
            <button onClick={() => console.log("Close action")}>Close</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetPdf;
