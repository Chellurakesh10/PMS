import React, { useState } from "react";
import "./ActivitiesCodeAnnualCost.js";
import SelectCustom from "../../../SelectCustom/SelectCustom.js";
import CustomInput from "../../../CustomInput/CustomInput.js";
import CustomButton from "../../../CustomButton/CustomButton.js";
import { useNavigate } from "react-router-dom";

const ActivitiesCodeAnnualCost = () => {
  const [activitiesCodeData, setActivitiesCodedata] = useState({
    ProgramName:"",
    ProgramCode:"",
    ProjectName:"",
    ProjectCode:"",
    Outputs:"",
    Activities:"",
    Code:"",
    Name:"",
    SelectFinancialYear:"",
    AnnualActivityCodeCost:"",
    TotalSubTotalCostActivityCode:"",
    submitted: false,
  });
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleNext = (e) => {
    const isValid = validateForm();

    if (isValid) {
      setActivitiesCodedata({
        ...activitiesCodeData,
        submitted: true,
      });
      navigate("/budgetingForm", {
        state: { component: "attachFiles" },
      });
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;

    setActivitiesCodedata({
      ...activitiesCodeData,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];
  const ActivitiesOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  return (
    <div className="ACA-container">
      <div className="ACA-fluid-container">
        <div className="ACA-head">
          <h1>Activities Code Annual Cost</h1>
        </div>
        <div className="ACA-form">
          <div className="ACA-inputs">
            <label>Program NAme :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"Program Name"}
            />
          </div>
          <div className="ACA-inputs">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
            />
          </div>
          <div className="ACA-inputs">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
            />
          </div>
          <div className="ACA-inputs">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
            />
          </div>
        </div>
        <div className="ACA-form">
          <div className="ACA-inputs">
            <label>Output</label>
            <SelectCustom
              name="Outputs"
              options={OutputsOptions}
              value={activitiesCodeData.Outputs}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="ACA-inputs">
            <label>Activities</label>
            <SelectCustom
              name="Activities"
              options={ActivitiesOptions}
              value={activitiesCodeData.Activities}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="ACA-inputs">
            <label>Code :</label>
            <CustomInput type={"text"} name={"Code"} placeholder={"Code"} />
          </div>
        </div>
        <div className="ACA-form">
          <div className="ACA-inputs">
            <label>Name:</label>
            <CustomInput type={"text"} name={"Code"} placeholder={"Code"} />
          </div>
          <div className="ACA-inputs">
            <label>Select FinancialYear :</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={activitiesCodeData.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>
          <div className="ACA-inputs">
            <label>Annual Activity Code Cost(UGX):</label>
            <CustomInput
              type={"text"}
              name={"AnnualActivityCodeCost"}
              placeholder={"Annual Activity Code Cost(UGX)"}
            />
          </div>
          <div className="ACA-add">
            <CustomButton buttonstyle={"int"} ButtonName={"+Add"} />
          </div>
        </div>
        <div className="ACA-form4">
          <label>Total Sub Total Cost Activity Code(UGX):</label>
          <CustomInput
            type={"text"}
            name={"TotalSubTotalCostActivityCode"}
            placeholder={"Annual Activity Code Cost(UGX)"}
          />
        </div>
        <div className="ACA-form5">
          <CustomButton
            buttonstyle={"But"}
            onClick={handleNext}
            ButtonName={"Next"}
          />
        </div>
      </div>
    </div>
  );
};

export default ActivitiesCodeAnnualCost;
