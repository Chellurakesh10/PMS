import React, { useState } from 'react';
import SelectCustom from '../../../SelectCustom/SelectCustom';
import CustomInput from '../../../CustomInput/CustomInput';
import CustomButton from '../../../CustomButton/CustomButton';
import { useNavigate } from 'react-router-dom';
import './OutputsAnnualCost.css';

const OutputsannualCost = () => {
  const [Outputdata, setOutputData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Outputs: "",
    SelectFinancialYear: "",
    AnnualOutcomesCost: "",
  });

  const [addedEntries, setAddedEntries] = useState([]); // State to store added entries
  const [errors, setErrors] = useState({}); // Errors state
  const navigate = useNavigate();

  // Validation logic for Outputs, Financial Year, and Annual Outcomes Cost
  const validateFields = () => {
    let newErrors = {};
    if (!Outputdata.Outputs) newErrors.Outputs = "Outputs is required";
    if (!Outputdata.SelectFinancialYear) newErrors.SelectFinancialYear = "Financial Year is required";
    if (!Outputdata.AnnualOutcomesCost) newErrors.AnnualOutcomesCost = "Annual Outcomes Cost is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Add button handler: validates, adds the data, and clears the input fields
  const handleAdd = () => {
    if (validateFields()) {
      // Add the data to addedEntries state
      setAddedEntries([
        ...addedEntries,
        {
          Outputs: Outputdata.Outputs,
          SelectFinancialYear: Outputdata.SelectFinancialYear,
          AnnualOutcomesCost: Outputdata.AnnualOutcomesCost,
        },
      ]);

      // Reset the form fields after adding
      setOutputData({
        ...Outputdata,
        Outputs: "",
        SelectFinancialYear: "",
        AnnualOutcomesCost: "",
      });

      // Clear any previous error messages
      setErrors({});
    } else {
      alert("Please fill in all the fields before adding.");
    }
  };

  // Save button handler: Navigates to the next page
const handleSave = () => {
  if (addedEntries.length > 0) {
    console.log("Navigating with addedEntries:", addedEntries);
    navigate("/budgetingForm/CoastedAnnualizedPlan", {
      state: { component: "AcitivitiesAnnualCost" },
    });
  } else {
    alert("Please add at least one entry.");
  }
};

  // Handle changes in input fields
  const handleChange = (e) => {
    const { name, value } = e.target;
    setOutputData({
      ...Outputdata,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];

  return (
    <div className="container">
      <div className="Oac-container-fluid">
        <div className="Oac-Head">
          <h1>Outputs Annual Cost</h1>
        </div>

        <div className="Oac-form">
          <div className="Oac-form-input">
            <label>Program :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"Program Name"}
              value={Outputdata.ProgramName}
              onChange={handleChange}
            />
          </div>

          <div className="Oac-form-input">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
              value={Outputdata.ProgramCode}
              onChange={handleChange}
            />
          </div>

          <div className="Oac-form-input">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
              value={Outputdata.ProjectName}
              onChange={handleChange}
            />
          </div>

          <div className="Oac-form-input">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
              value={Outputdata.ProjectCode}
              onChange={handleChange}
            />
          </div>
        </div>
        <div className="Oac-form">
          <div className="Oac-form-input">
            <label>Outputs</label>
            <SelectCustom
              name="Outputs"
              options={OutputsOptions}
              value={Outputdata.Outputs}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="Oac-form-input">
            <label>Select Financial Year :</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={Outputdata.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>

          <div className="Oac-form-input">
            <label>Annual Outcomes Cost (UGX):</label>
            <CustomInput
              type={"text"}
              name={"AnnualOutcomesCost"}
              placeholder={"Annual Outcomes Cost (UGX)"}
              value={Outputdata.AnnualOutcomesCost}
              onChange={handleChange}
            />
            {errors.AnnualOutcomesCost && (
              <p className="error">{errors.AnnualOutcomesCost}</p>
            )}
          </div>
          <div className="Oac-form-input1">
            <CustomButton ButtonName={"+Add"} onClick={handleAdd} />
          </div>
          {/* Display added entries */}
          <div className="added-entries">
            <h3>Added Entries:</h3>
            {addedEntries.length === 0 ? (
              <p>No entries added yet</p>
            ) : (
              <ul>
                {addedEntries.map((entry, index) => (
                  <li key={index}>
                    {`Outputs: ${entry.Outputs}, Financial Year: ${entry.SelectFinancialYear}, Annual Cost: ${entry.AnnualOutcomesCost}`}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <div className="Oac-form3">
          <div className="Oac-form-input">
            <label>Total Sub Total Outputs(UGX) :</label>
            <CustomInput
              type={"text"}
              name={"TotalSubTotalOutputs "}
              value={Outputdata.TotalSubTotalOutputs}
              placeholder={"Total Sub Total Outputs(UGX) "}
            />
          </div>
        </div>
        <div className="Oac-form4">
          <CustomButton
            buttonstyle={"but"}
            onClick={handleSave}
            ButtonName={"Next"}
          />
        </div>
      </div>
    </div>
  );
};

export default OutputsannualCost;
