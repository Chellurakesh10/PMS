import React, { useState } from "react";
import "./AcitivitiesAnnualCost.css";
import CustomButton from "../../../CustomButton/CustomButton";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import CustomInput from "../../../CustomInput/CustomInput";
import { useNavigate } from "react-router-dom";

const AcitivitiesAnnualCost = () => {
  const [activitiesdata, setActivitiesData] = useState({
    programName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    Activities: "",
    SelectFinancialYear: "",
    AnnualActivityCost: "",
    TotalSubTotalActivity: "",
    Outputs: "",
    submitted: false,
  });
  const [errors, setErrors] = useState("");
  const navigate = useNavigate();
  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();

    if (isValid) {
      setActivitiesData({
        ...activitiesdata,
        submitted: true,
      });
      navigate("/budgetingForm/CoastedAnnualizedPlan", {
        state: { component: "ActivitiesCodeAnnualCost" },
      });
    } else {
      alert("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setActivitiesData({
      ...activitiesdata,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];
  const ActivitiesOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  return (
    <div className="container">
      <div className="from-container-fluid">
        <div className="form-head">
          <h1>Activities Annual Cost</h1>
        </div>
        <div className="form-from1">
          <div className="form-input">
            <label>Program Name :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName "}
              placeholder={"Program Name"}
            />
          </div>
          <div className="form-input">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
            />
          </div>
          <div className="form-input">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
            />
          </div>
          <div className="form-input">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
            />
          </div>
        </div>
        <div className="Form-form2">
          <div className="form-input">
            <label>Output</label>
            <SelectCustom
              name="Outputs"
              options={OutputsOptions}
              value={activitiesdata.Outputs}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
          <div className="form-input">
            <label>Activities</label>
            <SelectCustom
              name="Activities"
              options={ActivitiesOptions}
              value={activitiesdata.Activities}
              onChange={handleChange}
            />
            {errors.Outputs && <p className="error">{errors.Outputs}</p>}
          </div>
        </div>
        <div className="form-from1">
          <div className="form-input">
            <label>Select FinancialYear</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={activitiesdata.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>
          <div className="form-input">
            <label>Annual Activity Cost(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>
          <div className="form-input">
            <label>Total Sub Total Activity Cost(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"AnnualActivityCost(UGx)"}
            />
          </div>
          <div className="form-sec">
            <CustomButton ButtonName={"Add"} />
          </div>
        </div>
        <div className="Form-form4">
          <div className="form-but">
            <CustomButton
              buttonStyle={"Net"}
              onClick={handleNext}
              ButtonName={"Next"}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AcitivitiesAnnualCost;
