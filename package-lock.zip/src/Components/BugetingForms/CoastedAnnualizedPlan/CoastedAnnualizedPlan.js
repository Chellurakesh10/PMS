import React, { useEffect, useState } from "react";
import "./CoastedAnnualizedPlan.css";
import { useLocation, useNavigate } from "react-router-dom";
import OutputsannualCost from "./OutputsAnnualCost/OutputsannualCost";
import ActivitiesCodeAnnualCost from "./ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCost";
import AcitivitiesAnnualCost from "./AcitivitiesAnnualCost/AcitivitiesAnnualCost";
import { MdOutput } from "react-icons/md";
import { SiActivision } from "react-icons/si";
import { SiActivitypub } from "react-icons/si";

const CoastedAnnualizedPlan = () => {
  const screen = useLocation();
  // const navigate = useNavigate();

  // Use state from the URL or default to "OutputsannualCost"
  const [activeComponent, setActiveComponent] = useState(
    screen.state?.component || "OutputsannualCost"
  );

  useEffect(() => {
    if (screen.state?.component && screen.state.component !== activeComponent) {
      setActiveComponent(screen.state.component);
    }
  }, [screen.state]);

  const handleButtonClick = (component) => {
    setActiveComponent(component);

    window.history.pushState(
      null,
      "",
      `/budgetingForm/CoastedAnnualizedPlan${component}`
    );

    // Use React Router's navigate function to update the URL
    // navigate(`/budgetingForm/CoastedAnnualizedPlan`, {
    //   state: { component: component },
    // });
  };

  return (
    <div className="plancontainer">
      <div className="planFluid-container">
        <div className="Head">
          <h1>Coasted Annualized Plan</h1>
        </div>
        <div className="planForm">
          <ul>
            <li>
              <button
                className={
                  activeComponent === "OutputsannualCost"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleButtonClick("OutputsannualCost")}
              >
                <span>
                  <MdOutput />
                  Outputs Annual Cost
                </span>
              </button>
            </li>
            <li>
              <button
                className={
                  activeComponent === "AcitivitiesAnnualCost"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleButtonClick("AcitivitiesAnnualCost")}
              >
                <span>
                  <SiActivision />
                  Activities Annual Cost
                </span>
              </button>
            </li>
            <li>
              <button
                className={
                  activeComponent === "ActivitiesCodeAnnualCost"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleButtonClick("ActivitiesCodeAnnualCost")}
              >
                <span>
                  <SiActivitypub />
                  Activities Code Annual Cost
                </span>
              </button>
            </li>
          </ul>
        </div>
        <div className="formbodycontainer">
          {activeComponent === "OutputsannualCost" && <OutputsannualCost />}
          {activeComponent === "AcitivitiesAnnualCost" && (
            <AcitivitiesAnnualCost />
          )}
          {activeComponent === "ActivitiesCodeAnnualCost" && (
            <ActivitiesCodeAnnualCost />
          )}
        </div>
      </div>
    </div>
  );
};

export default CoastedAnnualizedPlan;
