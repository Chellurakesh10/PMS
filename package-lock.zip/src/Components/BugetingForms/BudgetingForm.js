import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { MdAppRegistration } from "react-icons/md";
import { SiRobotframework, SiInfracost } from "react-icons/si";
import { IoDocumentAttachSharp } from "react-icons/io5";
import { GrStatusUnknown } from "react-icons/gr";
import "./BudgetingForm.css";
import ProgramStatus from "./ProgramStatus/ProgramStatus";
import ProgramRegistration from "./ProgramRegistration/ProgramRegistration";
import ProjectFrameworks1 from "./ProjectFrameworks/ProjectFrameworks1";
import CoastedAnnualizedPlan from "./CoastedAnnualizedPlan/CoastedAnnualizedPlan";
import AttachFiles from "./AttachFiles/AttachFiles";
import ProjectRegistration from "./ProjectFrameworks/ProjectRegistration/ProjectRegistration";
import ProjectList from "./ProgramRegistration/ProjectList/ProjectList";
import OutputsannualCost from "./CoastedAnnualizedPlan/OutputsAnnualCost/OutputsannualCost";
import ActivitiesCodeAnnualCost from "./CoastedAnnualizedPlan/ActivitiesCodeAnnualCost/ActivitiesCodeAnnualCost";
import AcitivitiesAnnualCost from "./CoastedAnnualizedPlan/AcitivitiesAnnualCost/AcitivitiesAnnualCost";
import ProgramRegistration2 from "./ProgramRegistration/ProgramRegistration2/ProgramRegistration2";
import ProjectGoalsAndOutcomes from "./ProjectFrameworks/ProjectGoalsAndOutcomes/ProjectGoalsAndOutcomes";
import Indicators from "./ProjectFrameworks/Indicators/Indicators";
import PerfomanceIndicator from "./ProjectFrameworks/PerfomanceIndicator/PerfomanceIndicator";
import ProjectActivities from "./ProjectFrameworks/ProjectActivities/ProjectActivities";

const BudgetingForm = () => {
  const location = useLocation();

  const [activeComponent, setActiveComponent] = useState( location.state || "programStatus");


  useEffect(() => {
    if (location.state) {
      setActiveComponent(location.state);
    }
  }, [location.state]);

  const handleButtonClick = (component) => {
    setActiveComponent(component);
  };

  const validComponents = [
    "programStatus",
    "programRegistration",
    "projectFrameworks",
    "coastedAnnualizedPlan",
    "attachFiles",
    "ProgramRegistration2",
    "ProjectRegistration",
    "ProjectGoalsAndOutcomes",
    "ProjectActivities",
    "PerfomanceIndicator",
    "Indicators",
    "ProjectList",
    "OutputsannualCost",
    "ActivitiesCodeAnnualCost",
    "AcitivitiesAnnualCost",
    "DepartmentMasters",
  ];

  return (
    <div className="maincontainer">
      <div className="sidecontainer">
        <ul>
          <li>
            <button
              className={activeComponent === "programStatus" ? "active-link focus" : ""}
              onClick={() => handleButtonClick("programStatus")}
            >
              <span>
                <GrStatusUnknown /> Program Status
              </span>
            </button>
          </li>
          <li>
            <button
              className={activeComponent === "programRegistration" ? "active-link focus" : ""}
              onClick={() => handleButtonClick("programRegistration")}
            >
              <span>
                <MdAppRegistration /> Program Registration
              </span>
            </button>
          </li>
          <li>
            <button
              className={activeComponent === "projectFrameworks" ? "active-link focus" : ""}
              onClick={() => handleButtonClick("projectFrameworks")}
            >
              <span>
                <SiRobotframework /> Project Frameworks
              </span>
            </button>
          </li>
          <li>
            <button
              className={activeComponent === "coastedAnnualizedPlan" ? "active-link focus" : ""}
              onClick={() => handleButtonClick("coastedAnnualizedPlan")}
            >
              <span>
                <SiInfracost /> Costed Annualized Plan
              </span>
            </button>
          </li>
          <li>
            <button
              className={activeComponent === "attachFiles" ? "active-link focus" : ""}
              onClick={() => handleButtonClick("attachFiles")}
            >
              <span>
                <IoDocumentAttachSharp /> Attach Files
              </span>
            </button>
          </li>
        </ul>
      </div>
      <div className="bodycontainer">
        {validComponents.includes(activeComponent) ? (
          <>
            {activeComponent === "programStatus" && <ProgramStatus />}
            {activeComponent === "programRegistration" && <ProgramRegistration />}
            {activeComponent === "projectFrameworks" && <ProjectFrameworks1 />}
            {activeComponent === "coastedAnnualizedPlan" && <CoastedAnnualizedPlan />}
            {activeComponent === "attachFiles" && <AttachFiles />}
            {activeComponent === "ProgramRegistration2" && <ProgramRegistration2 />}
            {activeComponent === "ProjectList" && <ProjectList />}
            {activeComponent === "ProjectRegistration" && <ProjectRegistration />}
            {activeComponent === "ProjectGoalsAndOutcomes" && <ProjectGoalsAndOutcomes />}
            {activeComponent === "Indicators" && <Indicators />}
            {activeComponent === "PerfomanceIndicator" && <PerfomanceIndicator />}
            {activeComponent === "ProjectActivities" && <ProjectActivities />}
            {activeComponent === "OutputsannualCost" && <OutputsannualCost />}
            {activeComponent === "AcitivitiesAnnualCost" && <AcitivitiesAnnualCost />}
            {activeComponent === "ActivitiesCodeAnnualCost" && <ActivitiesCodeAnnualCost />}
          </>
        ) : (
          <div>Component not found</div>
        )}
      </div>
    </div>
  );
};

export default BudgetingForm;
