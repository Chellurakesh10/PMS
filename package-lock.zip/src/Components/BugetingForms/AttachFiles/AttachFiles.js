import React, { useState, useEffect } from "react";
import "./AttachFiles.css";
import CustomInput from "../../CustomInput/CustomInput";
import CustomButton from "../../CustomButton/CustomButton";
import SelectCustom from "../../SelectCustom/SelectCustom";
import { AiFillEye } from "react-icons/ai";

const AttachFiles = () => {
  const [editingIndex, setEditingIndex] = useState(null);
  const [isEditing, setIsEditing] = useState(false);

  const [form, setForm] = useState({
    SelectFinancialYear: "",
    Description: "",
    AttachFiles: null,
    Submitted: false,
  });
  const [preview, setPreview] = useState(null);
  const [formList, setFormList] = useState([]);

  const validateForm = () => {
    return (
      form.Description.trim() !== "" &&
      form.AttachFiles !== null &&
      form.SelectFinancialYear !== ""
    );
  };

  const handleSave = async () => {
    if (validateForm()) {
      const formData = new FormData();
      formData.append("SelectFinancialYear", form.SelectFinancialYear);
      formData.append("Description", form.Description);
      formData.append("AttachFiles", form.AttachFiles);
      formData.append("Submitted", form.Submitted.toString());
      try {
        let response;
        if (isEditing) {
          response = await fetch(
            `http://localhost:4000/api/attachments/${formList[editingIndex].id}`,
            {
              method: "PUT",
              body: formData,
            }
          );
        } else {
          response = await fetch("http://localhost:4000/api/attachments", {
            method: "POST",
            body: formData,
          });
        }

        const data = await response.json();
        if (response.ok && data.success) {
          alert(data.message || "Submitted successfully");

          // Add the new form data to the list
          setFormList([
            ...formList,
            {
              SelectFinancialYear: form.SelectFinancialYear,
              Description: form.Description,
              AttachFiles: form.AttachFiles,
            },
          ]);

          // Reset form
          setForm({
            SelectFinancialYear: "",
            Description: "",
            AttachFiles: null,
            Submitted: false,
          });
          setPreview(null);
        } else {
          alert(data.message || "Failed to submit data");
        }
      } catch (error) {
        alert("An error occurred. Please try again.");
      }
    } else {
      alert("Please fill out the form correctly.");
    }
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;

    if (name === "AttachFiles") {
      const file = files[0];
      if (file && file.size > 5 * 1024 * 1024) {
        alert("File size exceeds 5MB limit");
        return;
      }
      setForm({ ...form, AttachFiles: file });
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  const handleSelectChange = (selectedOption) => {
    setForm({ ...form, SelectFinancialYear: selectedOption.value });
  };

  const handlePreview = (attachment) => {
    if (attachment.AttachFiles) {
      // Check if AttachFiles is a File object
      if (attachment.AttachFiles instanceof File) {
        setPreview({
          SelectFinancialYear: attachment.SelectFinancialYear,
          Description: attachment.Description,
          AttachFiles: URL.createObjectURL(attachment.AttachFiles),
        });
      } else {
        alert("Invalid file type for preview.");
      }
    } else {
      alert("No file available for preview.");
    }
  };
  
  const SelectFinancialYearOptions = [
    { value: "", label: "Choose List" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
    { value: "2024", label: "2024" },
  ];

  useEffect(() => {
    return () => {
      if (preview && preview.AttachFiles) {
        URL.revokeObjectURL(preview.AttachFiles);
      }
    };
  }, [preview]);

  const handleEdit = (index) => {
    const attachment = formList[index];
    setForm({
      SelectFinancialYear: attachment.SelectFinancialYear,
      Description: attachment.Description,
      AttachFiles: attachment.AttachFiles, // You may need to keep the previous file if you don't want to upload a new one
      Submitted: false,
    });
    setEditingIndex(index);
    setIsEditing(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this attachment?")) {
      try {
        const response = await fetch(
          `http://localhost:4000/api/attachments/${id}`,
          {
            method: "DELETE",
          }
        );
        const data = await response.json();
        if (response.ok && data.success) {
          setFormList(formList.filter((_, index) => index !== editingIndex));
          alert(data.message);
        } else {
          alert(data.message || "Failed to delete attachment.");
        }
      } catch (error) {
        alert("An error occurred while deleting the attachment.");
      }
    }
  };

  return (
    <div className="filescontainer">
      <div className="filesfluid-container">
        <div className="re-container">
          <div className="af-head">
            <h1>Attach Files</h1>
          </div>
          <div className="af-form">
            <div className="af-input">
              <label>Select Financial Year</label>
              <SelectCustom
                name="SelectFinancialYear"
                options={SelectFinancialYearOptions}
                value={form.SelectFinancialYear}
                onChange={handleSelectChange}
              />
            </div>
            <div className="af-input">
              <label>Description</label>
              <CustomInput
                type={"text"}
                placeholder={"Description"}
                name={"Description"}
                value={form.Description}
                onChange={handleChange}
              />
            </div>
            <div className="af-input">
              <label>Attach Files (up to 5 MB) *</label>
              <CustomInput
                type={"file"}
                name={"AttachFiles"}
                onChange={handleChange}
              />
            </div>
          </div>
          <div className="af-form1">
            <div className="af-input">
              <CustomButton ButtonName={"Add"} onClick={handleSave} />
            </div>
          </div>

          <div className="Af-Tab">
            <table>
              <thead>
                <tr>
                  <th>Financial Year</th>
                  <th>File Description</th>
                  <th>Attach Files</th>
                  <th>View</th>
                  <th>Update</th>
                  <th>Update With File</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {formList.map((form, index) => (
                  <tr key={index}>
                    <td>{form.SelectFinancialYear}</td>
                    <td>{form.Description}</td>
                    <td>{form.AttachFiles.name}</td>
                    <td>
                      <button onClick={() => handlePreview(form.AttachFiles)}>
                        <AiFillEye />
                      </button>
                    </td>
                    <td>
                      <button onClick={() => handleEdit(index)}>Update</button>
                    </td>
                    <td>
                      <button onClick={() => handleEdit(index)}>
                        Update With File
                      </button>
                    </td>
                    <td>
                      <button onClick={() => handleDelete(form.id)}>
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="af-button">
            <div className="af-button1">
              <CustomButton ButtonName={"Preview"} onClick={handlePreview} />
            </div>
          </div>
          <div className="af-butt">
            <CustomButton ButtonName={"Final Submit"} onClick={handleSave} />
          </div>
        </div>
        {preview && (
          <div className="preview-modal">
            <h2>Preview</h2>
            <p>Financial Year: {preview.SelectFinancialYear}</p>
            <p>Description: {preview.Description}</p>
            <a
              href={preview.AttachFiles}
              target="_blank"
              rel="noopener noreferrer"
            >
              View File
            </a>
            <button onClick={() => setPreview(null)}>Close</button>
          </div>
        )}

        {/* {preview && (
          <div className="preview-section">
            <h2>Preview</h2>

            <p>
              <strong>Financial Year:</strong>{" "}
              {preview.SelectFinancialYear || "N/A"}
            </p>

            <p>
              <strong>Description:</strong> {preview.Description}
            </p>
            {form.AttachFiles && (
              <div>
                <strong>Attached File:</strong>
                {form.AttachFiles.type.startsWith("image/") ? (
                  <img
                    src={preview.AttachFiles}
                    alt="Preview"
                    style={{ maxWidth: "100%", height: "auto" }}
                  />
                ) : form.AttachFiles.type === "application/pdf" ? (
                  <embed
                    src={preview.AttachFiles}
                    type="application/pdf"
                    width="100%"
                    height="600px"
                  />
                ) : (
                  <p>Preview not available for this file type.</p>
                )}
              </div>
            )}
          </div>
        )} */}
      </div>
    </div>
  );
};

export default AttachFiles;
