import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import CustomInput from "../../../CustomInput/CustomInput";
import CustomButton from "../../../CustomButton/CustomButton";
import "./ProjectList.css";
import { RiDeleteBin5Line } from "react-icons/ri";
import { GrDocumentUpdate } from "react-icons/gr";
import CustomSelectMultiple from "../../../CustomSelectMultiple/CustomSelectMultiple";

const ProjectList = () => {
  const [funder, SetFunder] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const [listdata, setListData] = useState({
    ProgramName: "",
    ProgramCode: "",
    SelectFunders: [],
    EstimatedProjectCostwithoutComma: "",
    TotalEstimateCostUGX: "",
    submitted: false,
  });

  const [errors, setErrors] = useState({});
  const [projects, setProjects] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);

  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;
  const handleSelectChange = (selected) => {
    console.log("Selected options:", selected);
    setSelectedOptions(selected);
    setListData((prevData) => ({
      ...prevData,
      SelectFunders: selected,
    }));
  };

  useEffect(() => {
    if (state) {
      setListData((prevData) => ({
        ...prevData,
        ProgramName: state.ProgramName || "",
        ProgramCode: state.ProgramCode || "",
      }));
    }
  }, [state]);

  useEffect(() => {
    const totalCost = projects.reduce(
      (sum, project) =>
        sum + parseFloat(project.EstimatedCost.replace(/,/g, "")) || 0,
      0
    );

    setListData((prevData) => ({
      ...prevData,
      TotalEstimateCostUGX: totalCost
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ","),
    }));
  }, [projects]);

  const validateForm = () => {
    let newErrors = {};
    if (!listdata.ProgramName) {
      newErrors.ProgramName = "Program Name is required";
    }
    if (!listdata.ProgramCode) {
      newErrors.ProgramCode = "Program Code is required";
    }
    if (!listdata.SelectFunders) {
      newErrors.SelectFunders =
        "Select Funder is required";
    }
    if (!listdata.EstimatedProjectCostwithoutCommaUGX) {
      newErrors.EstimatedProjectCostwithoutCommaUGX =
        "Estimated Project Cost is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      setListData((prevData) => ({
        ...prevData,
        submitted: true,
      }));
      navigate("/budgetingForm/ProjectFrameworks1", {
        state: { component: "ProjectRegistration" },
      });
    } else {
      alert("Fill Data Correctly");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setListData((prevData) => {
      const newData = {
        ...prevData,
        [name]: value,
      };

      const estimatedCost =
        parseFloat(
          name === "EstimatedProjectCostwithoutCommaUGX"
            ? value.replace(/,/g, "")
            : newData.EstimatedProjectCostwithoutCommaUGX.replace(/,/g, "")
        ) || 0;

      if (
        name === "EstimatedProjectCostwithoutCommaUGX" ||
        name === "EnterAllFundersWithCommaSeperate"
      ) {
        const funders = newData.EnterAllFundersWithCommaSeperate.split(",").map(
          (funder) => parseFloat(funder.trim()) || 0
        );

        const fundersTotal = funders.reduce((acc, curr) => acc + curr, 0);
        const totalEstimateCost = fundersTotal + estimatedCost;

        newData.TotalEstimateCostUGX = totalEstimateCost
          .toString()
          .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }

      return newData;
    });
  };

  const handleAdd = () => {
    if (validateForm()) {
      const newProject = {
        ProgramName: listdata.ProgramName,
        ProgramCode: listdata.ProgramCode,
        Funders: listdata.EnterAllFundersWithCommaSeperate,
        EstimatedCost: listdata.EstimatedProjectCostwithoutCommaUGX,
      };

      if (editingIndex !== null) {
        const updatedProjects = [...projects];
        updatedProjects[editingIndex] = newProject;
        setProjects(updatedProjects);
        setEditingIndex(null);
      } else {
        setProjects([...projects, newProject]);
      }

      setListData({
        ...listdata,
        EnterAllFundersWithCommaSeperate: "",
        EstimatedProjectCostwithoutCommaUGX: "",
      });
    } else {
      alert("Fill Data Correctly");
    }
  };

  const handleEdit = (index) => {
    setEditingIndex(index);
    setListData({
      ...listdata,
      ProgramName: projects[index].ProgramName,
      ProgramCode: projects[index].ProgramCode,
      EnterAllFundersWithCommaSeperate: projects[index].Funders,
      EstimatedProjectCostwithoutCommaUGX: projects[index].EstimatedCost,
    });
  };

  const handleDelete = (index) => {
    const updatedProjects = projects.filter((_, i) => i !== index);
    setProjects(updatedProjects);
    if (editingIndex === index) {
      setEditingIndex(null);
      setListData({
        ...listdata,
        EnterAllFundersWithCommaSeperate: "",
        EstimatedProjectCostwithoutCommaUGX: "",
      });
    }
  };

  // Fetch departments when component mounts
  useEffect(() => {
    const fetchfundermaster = async () => {
      try {
        const response = await fetch("http://localhost:4000/fundermaster");
        const data = await response.json();
        SetFunder(data);
      } catch (error) {
        console.error("Error fetching fundeMaster:", error);
      }
    };

    fetchfundermaster();
  }, []);

  // Transform fundeMaster into options format for SelectCustom
  const SelectFundersOptions = funder.map((dept) => ({
    value: dept.name,
    label: dept.name,
  }));

  return (
    <div className="listcontainer">
      <div className="listFulid-container">
        <div className="head">
          <h1>Add project list under this program</h1>
        </div>
        <div className="form">
          <div className="form-input">
            <label>Project Name</label>
            <CustomInput
              type={"text"}
              name="ProgramName"
              value={listdata.ProgramName}
              placeholder={"Program Name"}
              onChange={handleChange}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="form-input">
            <label>Project Code</label>
            <CustomInput
              type={"text"}
              name="ProgramCode"
              value={listdata.ProgramCode}
              placeholder={"Program Code"}
              onChange={handleChange}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
        </div>
        <div className="form1">
          <div className="form-input1">
            <label>Select Funders</label>
            <CustomSelectMultiple
              name="SelectFunders"
              options={SelectFundersOptions}
              value={selectedOptions}
              // value={listdata.SelectFunders}
              onChange={handleSelectChange}
              // onChange={(selectedOptions) =>
              //   setListData((prev) => ({
              //     ...prev,
              //     SelectFunders: selectedOptions.map(option => option.value),
              //   }))
              // }
              multiple
            />
            {errors.SelectFunders && (
              <p className="error">{errors.SelectFunders}</p>
            )}
          </div>
          <div className="form-input1">
            <label>Estimated Project Cost without Comma</label>
            <CustomInput
              type={"text"}
              name="EstimatedProjectCostwithoutComma"
              value={listdata.EstimatedProjectCostwithoutComma}
              placeholder={"Estimated Project Cost "}
              onChange={handleChange}
            />
            {errors.EstimatedProjectCostwithoutComma && (
              <p className="error">{errors.EstimatedProjectCostwithoutComma}</p>
            )}
          </div>
        </div>
        <div className="form">
          <div className="form-input3">
            <CustomButton
              ButtonName={editingIndex !== null ? "Update" : "+ADD"}
              onClick={handleAdd}
            />
          </div>
        </div>

        <div className="list-Tab">
          <table className="list-input">
            <thead>
              <tr>
                <th>Program Name</th>
                <th>Program Code</th>
                <th>Funders List</th>
                <th>Estimated Project Cost (UGX)</th>
                <th>Update</th>
                <th>Delete</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project, index) => (
                <tr key={index}>
                  <td>{project.ProgramName}</td>
                  <td>{project.ProgramCode}</td>
                  <td>
                    {Array.isArray(project.Funders)
                      ? project.Funders.map((funder) => funder.label).join(", ")
                      : project.Funders}
                  </td>

                  <td>{project.EstimatedCost}</td>
                  <td>
                    <button onClick={() => handleEdit(index)}>
                      <GrDocumentUpdate />
                    </button>
                  </td>
                  <td>
                    <button onClick={() => handleDelete(index)}>
                      <RiDeleteBin5Line />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="form-data">
          <div className="form-input2">
            <label>Total Estimated Cost (UGX) :</label>
            <CustomInput
              type={"text"}
              name={"TotalEstimateCostUGX"}
              className={"def"}
              value={listdata.TotalEstimateCostUGX}
              readOnly
            />
          </div>
        </div>
        <div className="form1">
          <div className="form-input3">
            <CustomButton
              className={"dut"}
              onClick={handleNext}
              ButtonName={"Next"}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectList;
