import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./ProgramRegistration2.css";
import CustomInput from "../../../CustomInput/CustomInput";
import CustomButton from "../../../CustomButton/CustomButton";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import { Switch } from "antd";

const ProgramRegistration2 = () => {
  const location = useLocation();
  const { state } = location;
  const [departments, setDepartments] = useState([]);

  const [budgeting, setBudgeting] = useState(
    state?.data || {
      ProgramName: "",
      ProgramCode: "",
      SelectDepartment: "",
      StartDate: "",
      DurationYear: "0",
      DurationType: "",
      EndDate: "",
      submitted: false,
    }
  );

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
  const [activeSwitch, setActiveSwitch] = useState(null);

  // Fetch departments when component mounts
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await fetch("http://localhost:4000/departments");
        const data = await response.json();
        setDepartments(data);
      } catch (error) {
        console.error("Error fetching departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  // Transform departments into options format for SelectCustom
  const SelectDepartmentOptions = departments.map((dept) => ({
    value: dept.name,
    label: dept.name,
  }));

  const handleSwitchChange = (switchName) => {
    setActiveSwitch(switchName === activeSwitch ? null : switchName);
  };

  // Update state from location if exists
  useEffect(() => {
    if (state?.data) {
      setBudgeting((prevBudgeting) => ({
        ...prevBudgeting,
        ...state.data,
      }));
    }
  }, [state]);

  // Calculate Duration Year
  const calculateEndDate = (startDate, durationType, durationValue) => {
    if (!startDate || !durationType || !durationValue) return "";

    const start = new Date(startDate);
    const value = parseInt(durationValue);

    if (isNaN(value) || value < 0) return "";

    const end = new Date(start);

    switch (durationType) {
      case "Days":
        end.setDate(start.getDate() + value);
        break;
      case "Months":
        end.setMonth(start.getMonth() + value);
        break;
      case "Years":
        end.setFullYear(start.getFullYear() + value);
        break;
      default:
        return "";
    }

    return end.toISOString().split("T")[0];
  };

  const handleDurationChange = (e) => {
    const { name, value } = e.target;
    setBudgeting((prev) => {
      const newBudgeting = {
        ...prev,
        [name]: value,
      };

      if (
        newBudgeting.StartDate &&
        newBudgeting.DurationType &&
        newBudgeting.DurationYear
      ) {
        const endDate = calculateEndDate(
          newBudgeting.StartDate,
          newBudgeting.DurationType,
          newBudgeting.DurationYear
        );
        newBudgeting.EndDate = endDate;
      }

      return newBudgeting;
    });
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validateForm = () => {
    let newErrors = {};
    if (!budgeting.ProgramName.trim()) {
      newErrors.ProgramName = "Program Name is required.";
    }
    if (!budgeting.ProgramCode.trim()) {
      newErrors.ProgramCode = "Program Code is required.";
    }
    if (!budgeting.SelectDepartment.trim()) {
      newErrors.SelectDepartment = "Select Department is required.";
    }
    if (!budgeting.StartDate) {
      newErrors.StartDate = "Start Date is required.";
    }
    if (!budgeting.DurationType) {
      newErrors.DurationType = "Duration Type is required.";
    }
    if (!budgeting.DurationYear) {
      newErrors.DurationYear = "Duration Year is required.";
    }
    if (!budgeting.EndDate) {
      newErrors.EndDate = "End Date is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      setBudgeting((prevBudgeting) => ({
        ...prevBudgeting,
        submitted: true,
      }));
      navigate("/budgetingForm/ProgramRegistration/ProjectList", {
        state: { component: "ProjectList" },
      });
    } else {
      alert("Submission failed due to validation errors.");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBudgeting((prevBudgeting) => ({
      ...prevBudgeting,
      [name]: value,
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  };

  const DurationTypeOptions = [
    { value: "", label: "Select" },
    { value: "Days", label: "Days" },
    { value: "Months", label: "Months" },
    { value: "Years", label: "Years" },
  ];

  const DirectionOptions = [
    { value: "", label: "N" },
    { value: "S", label: "S" },
    { value: "E", label: "E" },
    { value: "W", label: "W" },
  ];

  return (
    <div className="programContainer">
      <div className="programcontainer-fluid">
        <div className="Heading">
          <h3>Program Registration Form</h3>
        </div>
        <div className="Form">
          <div className="Form-input">
            <label>Program Name:</label>
            <CustomInput
              type="text"
              name="ProgramName"
              placeholder="Program Name"
              value={budgeting.ProgramName}
              onChange={handleChange}
              readOnly
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="Form-input">
            <label>Program Code:</label>
            <CustomInput
              type="text"
              name="ProgramCode"
              placeholder="Program Code"
              value={budgeting.ProgramCode}
              onChange={handleChange}
              readOnly
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
          <div className="Form-input">
            <label>Select Department:</label>
            <SelectCustom
              name="SelectDepartment"
              options={SelectDepartmentOptions}
              value={budgeting.SelectDepartment}
              onChange={handleChange}
            />
            {errors.SelectDepartment && (
              <p className="error">{errors.SelectDepartment}</p>
            )}
          </div>
        </div>
        <div className="Program">
          <div className="Heading1">
            <h4>Program Duration</h4>
          </div>
          <div className="Form">
            <div className="Form-input">
              <label>Start Date:</label>
              <CustomInput
                type="date"
                name="StartDate"
                placeholder="Start Date"
                value={budgeting.StartDate}
                onChange={handleDurationChange}
              />
              {errors.StartDate && <p className="error">{errors.StartDate}</p>}
            </div>
            <div className="Form-input">
              <label>Duration Type:</label>
              <SelectCustom
                name="DurationType"
                options={DurationTypeOptions}
                value={budgeting.DurationType}
                onChange={handleDurationChange}
              />
              {errors.DurationType && (
                <p className="error">{errors.DurationType}</p>
              )}
            </div>
            <div className="Form-input">
              <label>Duration Value:</label>
              <CustomInput
                type="number"
                name="DurationYear"
                placeholder="Enter duration"
                value={budgeting.DurationYear}
                onChange={handleDurationChange}
                min="0"
              />
              {errors.DurationYear && (
                <p className="error">{errors.DurationYear}</p>
              )}
            </div>
            <div className="Form-input">
              <label>End Date:</label>
              <CustomInput
                type="date"
                name="EndDate"
                placeholder="End Date"
                value={budgeting.EndDate}
                readOnly
              />
              {errors.EndDate && <p className="error">{errors.EndDate}</p>}
            </div>
          </div>
        </div>
        <div className="Program">
          <div className="Heading1">
            <h5>Program Location</h5>
          </div>
          <div className="Form">
            <div className="Form-input">
              <label>Area(Eg:Delhi)</label>
              <CustomInput
                type="text"
                name="Area"
                placeholder="Area"
                value={budgeting.Area}
                onChange={handleChange}
              />
              {errors.Area && <p className="error">{errors.Area}</p>}
            </div>
            <div className="Form-input">
              <label>BreifAboutLocation</label>
              <CustomInput
                type="text"
                name="BreifAboutLocation"
                placeholder="Breif About Location"
                value={budgeting.BreifAboutLocation}
                onChange={handleChange}
              />
              {errors.BreifAboutLocation && (
                <p className="error">{errors.BreifAboutLocation}</p>
              )}
            </div>
          </div>
          <div className="Pr-form1">
            <div className="switch-group">
              <label>UTM</label>
              <Switch
                checked={activeSwitch === "UTM"}
                onChange={() => handleSwitchChange("UTM")}
              />
              <label>Lat/Long</label>
              <Switch
                checked={activeSwitch === "Lat/Long"}
                onChange={() => handleSwitchChange("Lat/Long")}
              />
              <label>DMS</label>
              <Switch
                checked={activeSwitch === "DMS"}
                onChange={() => handleSwitchChange("DMS")}
              />
            </div>

            {activeSwitch === "UTM" && (
              <div className="Pr-form-group">
                <div className="Pr-input-inline">
                  <label>UTM Zone</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"UTM Zone"}
                    name={"UTMZone"}
                    value={budgeting.UTMZone}
                    onChange={handleChange}
                  />
                  {errors.UTMZone && <p className="error">{errors.UTMZone}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Zone Letter</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Zone Letter"}
                    name={"ZoneLetter"}
                    value={budgeting.ZoneLetter}
                    onChange={handleChange}
                  />
                  {errors.ZoneLetter && (
                    <p className="error">{errors.ZoneLetter}</p>
                  )}
                </div>
                <div className="Pr-input-inline">
                  <label>UTM Easting</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"UTM Easting"}
                    name={"UTMEasting"}
                    value={budgeting.UTMEasting}
                    onChange={handleChange}
                  />
                  {errors.UTMEasting && (
                    <p className="error">{errors.UTMEasting}</p>
                  )}
                </div>
                <div className="Pr-input-inline">
                  <label>UTM Northing</label>
                  <CustomInput
                    type={"text"}
                    name={"UTMNorthing"}
                    value={budgeting.UTMNorthing}
                    placeholder={"UTM Northing"}
                  />
                  {errors.UTMNorthing && (
                    <p className="error">{errors.UTMNorthing}</p>
                  )}
                </div>
              </div>
            )}

            {activeSwitch === "Lat/Long" && (
              <div className="Pr-form-group1">
                <div className="Pr-input-inline">
                  <label>Latitude</label>
                  <CustomInput
                    type={"number"}
                    placeholder={"Latitude"}
                    name={"Latitude"}
                    value={budgeting.Latitude}
                    onChange={handleChange}
                  />
                  {errors.Latitude && (
                    <p className="error">{errors.Latitude}</p>
                  )}
                </div>
                <div className="Pr-input-inline">
                  <label>Longitude</label>
                  <CustomInput
                    type={"number"}
                    placeholder={"Longitude"}
                    name={"Longitude"}
                    value={budgeting.Longitude}
                    onChange={handleChange}
                  />
                  {errors.Longitude && (
                    <p className="error">{errors.Longitude}</p>
                  )}
                </div>
              </div>
            )}

            {activeSwitch === "DMS" && (
              <div className="Pr-form-group">
                <div className="Pr-form-group1">
                  <div className="Pr-input-inline">
                    <label>Deg</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Deg"}
                      name={"Deg"}
                      value={budgeting.Deg}
                      onChange={handleChange}
                    />
                    {errors.Deg && <p className="error">{errors.Deg}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Min</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Min"}
                      name={"Min"}
                      value={budgeting.Min}
                      onChange={handleChange}
                    />
                    {errors.Min && <p className="error">{errors.Min}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Sec</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Sec"}
                      name={"Sec"}
                      value={budgeting.Sec}
                      onChange={handleChange}
                    />
                    {errors.Sec && <p className="error">{errors.Sec}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Direction</label>
                    <SelectCustom
                      name="Direction"
                      options={DirectionOptions}
                      value={budgeting.Direction}
                      onChange={handleChange}
                    />
                    {errors.Direction && (
                      <p className="error">{errors.Direction}</p>
                    )}
                  </div>
                </div>
                <div className="Pr-form-group1">
                  <div className="Pr-input-inline">
                    <label>Deg</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Deg"}
                      name={"Deg"}
                      value={budgeting.Deg}
                      onChange={handleChange}
                    />
                    {errors.Deg && <p className="error">{errors.Deg}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Min</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Min"}
                      name={"Min"}
                      value={budgeting.Min}
                      onChange={handleChange}
                    />
                    {errors.Min && <p className="error">{errors.Min}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Sec</label>
                    <CustomInput
                      type={"text"}
                      placeholder={"Sec"}
                      name={"Sec"}
                      value={budgeting.Sec}
                      onChange={handleChange}
                    />
                    {errors.Sec && <p className="error">{errors.Sec}</p>}
                  </div>
                  <div className="Pr-input-inline">
                    <label>Direction</label>
                    <SelectCustom
                      name="Direction"
                      options={DirectionOptions}
                      value={budgeting.Direction}
                      onChange={handleChange}
                    />
                    {errors.Direction && (
                      <p className="error">{errors.Direction}</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="last">
          <CustomButton onClick={handleSave} ButtonName={"Save"} />
        </div>
      </div>
    </div>
  );
};

export default ProgramRegistration2;
