import React, { useEffect, useState } from "react";
import "./ProgramRegistration.css";
import { GoGoal } from "react-icons/go";
import { MdAppRegistration } from "react-icons/md";
import {  useLocation } from "react-router-dom";
import ProjectList from "./ProjectList/ProjectList";
import ProgramRegistration2 from "./ProgramRegistration2/ProgramRegistration2";

const ProgramRegistration = () => {
  const loc = useLocation()
  console.log(loc.state,"hai")
  const [activeComponent, setActiveComponent] = useState("ProgramRegistration2" || loc.state.component);
 
  useEffect(() => {

    console.log("Current Location state:", loc.state);
   
    // Log current location state
    console.log("current activeComponent:",activeComponent);

    if (loc.state?.component && loc.state.component === activeComponent) {
      setActiveComponent(loc.state.component);
    }
  }, [loc.state,activeComponent]); 
  const handleButtonClick = (component) => {
    console.log("Clicked Component:", component);
    
    setActiveComponent(component);

    // navigate(`/BudgetingForm/ProgramRegistration/${component}`, { state: { component } });
    window.history.pushState(null, '', `/budgetingForm/ProgramRegistration${component}`);


  };
  return (
    <div className="registercontainer">
      <div className="registerConatiner_fluid">
        <div className="Pr_head">
          <h1>Program Registration</h1>
        </div>
        <div className="registerForm">
          <ul>
            <li>
              <button
                className={
                  activeComponent === "ProgramRegistration2"
                    ? "active-link focus"
                    : ""
                }
                onClick={() => handleButtonClick("ProgramRegistration2")}
              >
                <span><GoGoal/>Program Registration</span>
              </button>
            </li>
            <li>
              <button
                className={
                  activeComponent === "ProjectList" ? "active-link focus" : ""
                }
                onClick={() => handleButtonClick("ProjectList")}
              >
                <span><MdAppRegistration/>ProjectList</span>
              </button>
            </li>
          </ul>
        </div>
        <div className="formbodycontainer">
          {activeComponent === "ProgramRegistration2" && <ProgramRegistration2 />}
          {activeComponent === "ProjectList" && (
            <ProjectList />
          )}
        </div>
      </div>
    </div>
  );
};

export default ProgramRegistration;
