import React, { useEffect, useState } from "react";
import "./ProjectRegistration.css";
// import Header from '../../../Header'
// import BudgetingForm from '../../BudgetingForm'
import SelectCustom from "../../../SelectCustom/SelectCustom";
import CustomInput from "../../../CustomInput/CustomInput";
import CustomButton from "../../../CustomButton/CustomButton";
import { Switch } from "antd";
import { useNavigate } from "react-router-dom";
import CustomSelectMultiple from "../../../CustomSelectMultiple/CustomSelectMultiple";

const ProjectRegistration = () => {
  const [activeSwitch, setActiveSwitch] = useState(null);
  const [departments, setDepartments] = useState([]);

  const handleSwitchChange = (switchName) => {
    setActiveSwitch(switchName === activeSwitch ? null : switchName);
  };

  const navigate = useNavigate();

  const [regdata, setRegData] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    SelectDepartment: [],
    StartDate: "",
    DurationYears: "",
    EndDate: "",
    EnterFunderswithCommaseperated: "",
    EstimatedProjectCost: "",
    Funders: "",
    Tittle: "",
    Name: "",
    MobileNumber: "",
    Email: "",
    Latitude: "",
    Longitude: "",
    Deg: "",
    Min: "",
    Sec: "",
    UTMZone: "",
    ZoneLetter: "",
    UTMEasting: "",
    UTMNorthing: "",
    Direction: "",
    BriefAboutLocationInformation: "",
    Submitted: false,
  });

  const [errors, setErrors] = useState("");

  const isValidMobileNumber = (MobileNumber) => {
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(MobileNumber);
  };
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  // Calculate Duration Year
  const calculateEndDate = (startDate, durationType, durationValue) => {
    if (!startDate || !durationType || !durationValue) return "";

    const start = new Date(startDate);
    const value = parseInt(durationValue);

    if (isNaN(value) || value < 0) return "";

    const end = new Date(start);

    switch (durationType) {
      case "Days":
        end.setDate(start.getDate() + value);
        break;
      case "Months":
        end.setMonth(start.getMonth() + value);
        break;
      case "Years":
        end.setFullYear(start.getFullYear() + value);
        break;
      default:
        return "";
    }

    return end.toISOString().split("T")[0];
  };

  const handleDurationChange = (e) => {
    const { name, value } = e.target;
    setRegData((prev) => {
      const newRegData = {
        ...prev,
        [name]: value,
      };

      if (
        newRegData.StartDate &&
        newRegData.DurationType &&
        newRegData.DurationYears
      ) {
        const endDate = calculateEndDate(
          newRegData.StartDate,
          newRegData.DurationType,
          newRegData.DurationYears
        );
        newRegData.EndDate = endDate;
      }

      return newRegData;
    });
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validationForm = () => {
    let newErrors = {};

    if (!regdata.ProgramName)
      newErrors.ProgramName = "Program Name is Required";
    if (!regdata.ProgramCode)
      newErrors.ProgramCode = "Program Code is Required";
    if (!regdata.ProjectName)
      newErrors.ProjectName = "Project Name is Required";
    if (!regdata.ProjectCode)
      newErrors.ProjectCode = "Project Code is Required";
    if (regdata.SelectDepartment.length === 0) {
      newErrors.SelectDepartment = "Department is Required";
    }
    if (regdata.StartDate && regdata.EndDate) {
      const start = new Date(regdata.StartDate);
      const end = new Date(regdata.EndDate);
      if (start >= end) {
        newErrors.EndDate = "End Date must be after Start Date.";
      }
    }
    if (!regdata.DurationYears)
      newErrors.DurationYears = "Duration Years is Required";
    if (!regdata.EstimatedProjectCost)
      newErrors.EstimatedProjectCost =
        "Estimated Project Cost (UGX) is Required";
    if (!regdata.EnterFunderswithCommaseperated)
      newErrors.Funders =
        "Enter Funders with Comma separated (UGX) is Required";
    if (!regdata.Name) newErrors.Name = "Name is Required";
    if (!regdata.Tittle) newErrors.Tittle = "Title is Required";

    if (!regdata.MobileNumber) {
      newErrors.MobileNumber = "Mobile Number is Required";
    } else if (!isValidMobileNumber(regdata.MobileNumber)) {
      newErrors.MobileNumber = "Mobile Number must be 10 digits";
    }

    if (!regdata.Email) {
      newErrors.Email = "Email is Required";
    } else if (!isValidEmail(regdata.Email)) {
      newErrors.Email = "Email is Invalid";
    }

    // Set errors to state and return whether the form is valid
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Returns true if there are no errors
  };

  const handleSave = (e) => {
    e.preventDefault();
    const isValid = validationForm();

    if (isValid) {
      // Navigate and reset form if needed
      navigate("/budgetingForm/ProjectFrameworks1", {
        state: { component: "ProjectGoalsAndOutcomes" },
      });
      // Optionally reset the form here
    } else {
      alert("Fill the form correctly");
    }
  };
  const handleChange = (e) => {
    if (e.target) {
      // Handle regular input changes
      const { name, value } = e.target;
      setRegData((prev) => ({
        ...prev,
        [name]: value,
      }));
    } else if (Array.isArray(e)) {
      // Handle multi-select changes - e will be array of selected options
      setRegData((prev) => ({
        ...prev,
        SelectDepartment: e.map((option) => option.value),
      }));
    } else if (e.name && e.value !== undefined) {
      // Handle single select changes
      setRegData((prev) => ({
        ...prev,
        [e.name]: e.value,
      }));
    }
  };
  // Fetch departments when component mounts
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await fetch("http://localhost:4000/departments");
        const data = await response.json();
        setDepartments(data);
      } catch (error) {
        console.error("Error fetching departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  // Transform departments into options format for SelectCustom
  const SelectDepartmentOptions = departments.map((dept) => ({
    value: dept.name,
    label: dept.name,
  }));

  const programNameOptions = [
    { value: "", label: "Choose List" },
    { value: "Wemis", label: "Wemis" },
    { value: "Water", label: "Water" },
    { value: "TestOne", label: "Test One" },
    { value: "Sanitation", label: "Sanitation" },
  ];

  const DirectionOptions = [
    { value: "", label: "N" },
    { value: "S", label: "S" },
    { value: "E", label: "E" },
    { value: "W", label: "W" },
  ];
  const DurationTypeOptions = [
    { value: "", label: "Select" },
    { value: "Days", label: "Days" },
    { value: "Months", label: "Months" },
    { value: "Years", label: "Years" },
  ];
  return (
    <div className="proregcontainer">
      {/* <Header/> */}
      {/* <BudgetingForm/> */}

      <div className="Proreg-fluid-container">
        <div className="Head">
          <h1>Project Registration</h1>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Program Name</label>
            <SelectCustom
              name="ProgramName"
              options={programNameOptions}
              value={regdata.ProgramName}
              onChange={handleChange}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Program Code</label>
            <CustomInput
              type={"text"}
              placeholder={"ProgramCode"}
              name={"ProgramCode"}
              value={regdata.ProgramCode}
              onChange={handleChange}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Project Name</label>
            <CustomInput
              type={"text"}
              placeholder={"Project Name"}
              name={"ProjectName"}
              value={regdata.ProjectName}
              onChange={handleChange}
            />
            {errors.ProjectName && (
              <p className="error">{errors.ProjectName}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Project code</label>
            <CustomInput
              type={"text"}
              placeholder={"Project Code"}
              name={"ProjectCode"}
              value={regdata.ProjectCode}
              onChange={handleChange}
            />
            {errors.ProjectCode && (
              <p className="error">{errors.ProjectCode}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Select Department:</label>
            <CustomSelectMultiple
              isMulti
              name="SelectDepartment"
              options={SelectDepartmentOptions}
              value={SelectDepartmentOptions.filter((option) =>
                regdata.SelectDepartment.includes(option.value)
              )}
              onChange={handleChange} // Changed this line - now passing handleChange directly
            />
            {errors.SelectDepartment && (
              <p className="error">{errors.SelectDepartment}</p>
            )}
          </div>
        </div>
        <div className="head">
          <p>Project Duration</p>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Start Date:</label>
            <CustomInput
              type="date"
              name="StartDate"
              placeholder="Start Date"
              value={regdata.StartDate}
              onChange={handleDurationChange}
            />
            {errors.StartDate && <p className="error">{errors.StartDate}</p>}
          </div>
          <div className="Pr-input">
            <label>Duration Type:</label>
            <SelectCustom
              name="DurationType"
              options={DurationTypeOptions}
              value={regdata.DurationType}
              onChange={handleDurationChange}
            />
            {errors.DurationType && (
              <p className="error">{errors.DurationType}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Duration Year:</label>
            <CustomInput
              type="number"
              name="DurationYears"
              placeholder="Enter duration"
              value={regdata.DurationYears}
              onChange={handleDurationChange}
              min="0"
            />
            {errors.DurationYear && (
              <p className="error">{errors.DurationYear}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>End Date:</label>
            <CustomInput
              type="date"
              name="EndDate"
              placeholder="End Date"
              value={regdata.EndDate}
              readOnly
            />
            {errors.EndDate && <p className="error">{errors.EndDate}</p>}
          </div>
        </div>

        <div className="Head">
          <h4>Project Location Details</h4>
        </div>
        <div className="Pr-form1">
          <div className="switch-group">
            <label>UTM</label>
            <Switch
              checked={activeSwitch === "UTM"}
              onChange={() => handleSwitchChange("UTM")}
            />
            <label>Lat/Long</label>
            <Switch
              checked={activeSwitch === "Lat/Long"}
              onChange={() => handleSwitchChange("Lat/Long")}
            />
            <label>DMS</label>
            <Switch
              checked={activeSwitch === "DMS"}
              onChange={() => handleSwitchChange("DMS")}
            />
          </div>

          {activeSwitch === "UTM" && (
            <div className="Pr-form-group">
              <div className="Pr-input-inline">
                <label>UTM Zone</label>
                <CustomInput
                  type={"text"}
                  placeholder={"UTM Zone"}
                  name={"UTMZone"}
                  value={regdata.UTMZone}
                  onChange={handleChange}
                />
                {errors.UTMZone && <p className="error">{errors.UTMZone}</p>}
              </div>
              <div className="Pr-input-inline">
                <label>Zone Letter</label>
                <CustomInput
                  type={"text"}
                  placeholder={"Zone Letter"}
                  name={"ZoneLetter"}
                  value={regdata.ZoneLetter}
                  onChange={handleChange}
                />
                {errors.ZoneLetter && (
                  <p className="error">{errors.ZoneLetter}</p>
                )}
              </div>
              <div className="Pr-input-inline">
                <label>UTM Easting</label>
                <CustomInput
                  type={"text"}
                  placeholder={"UTM Easting"}
                  name={"UTMEasting"}
                  value={regdata.UTMEasting}
                  onChange={handleChange}
                />
                {errors.UTMEasting && (
                  <p className="error">{errors.UTMEasting}</p>
                )}
              </div>
              <div className="Pr-input-inline">
                <label>UTM Northing</label>
                <CustomInput
                  type={"text"}
                  name={"UTMNorthing"}
                  value={regdata.UTMNorthing}
                  placeholder={"UTM Northing"}
                />
                {errors.UTMNorthing && (
                  <p className="error">{errors.UTMNorthing}</p>
                )}
              </div>
            </div>
          )}

          {activeSwitch === "Lat/Long" && (
            <div className="Pr-form-group1">
              <div className="Pr-input-inline">
                <label>Latitude</label>
                <CustomInput
                  type={"number"}
                  placeholder={"Latitude"}
                  name={"Latitude"}
                  value={regdata.Latitude}
                  onChange={handleChange}
                />
                {errors.Latitude && <p className="error">{errors.Latitude}</p>}
              </div>
              <div className="Pr-input-inline">
                <label>Longitude</label>
                <CustomInput
                  type={"number"}
                  placeholder={"Longitude"}
                  name={"Longitude"}
                  value={regdata.Longitude}
                  onChange={handleChange}
                />
                {errors.Longitude && (
                  <p className="error">{errors.Longitude}</p>
                )}
              </div>
            </div>
          )}

          {activeSwitch === "DMS" && (
            <div className="Pr-form-group">
              <div className="Pr-form-group1">
                <div className="Pr-input-inline">
                  <label>Deg</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Deg"}
                    name={"Deg"}
                    value={regdata.Deg}
                    onChange={handleChange}
                  />
                  {errors.Deg && <p className="error">{errors.Deg}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Min</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Min"}
                    name={"Min"}
                    value={regdata.Min}
                    onChange={handleChange}
                  />
                  {errors.Min && <p className="error">{errors.Min}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Sec</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Sec"}
                    name={"Sec"}
                    value={regdata.Sec}
                    onChange={handleChange}
                  />
                  {errors.Sec && <p className="error">{errors.Sec}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Direction</label>
                  <SelectCustom
                    name="Direction"
                    options={DirectionOptions}
                    value={regdata.Direction}
                    onChange={handleChange}
                  />
                  {errors.Direction && (
                    <p className="error">{errors.Direction}</p>
                  )}
                </div>
              </div>
              <div className="Pr-form-group1">
                <div className="Pr-input-inline">
                  <label>Deg</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Deg"}
                    name={"Deg"}
                    value={regdata.Deg}
                    onChange={handleChange}
                  />
                  {errors.Deg && <p className="error">{errors.Deg}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Min</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Min"}
                    name={"Min"}
                    value={regdata.Min}
                    onChange={handleChange}
                  />
                  {errors.Min && <p className="error">{errors.Min}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Sec</label>
                  <CustomInput
                    type={"text"}
                    placeholder={"Sec"}
                    name={"Sec"}
                    value={regdata.Sec}
                    onChange={handleChange}
                  />
                  {errors.Sec && <p className="error">{errors.Sec}</p>}
                </div>
                <div className="Pr-input-inline">
                  <label>Direction</label>
                  <SelectCustom
                    name="Direction"
                    options={DirectionOptions}
                    value={regdata.Direction}
                    onChange={handleChange}
                  />
                  {errors.Direction && (
                    <p className="error">{errors.Direction}</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Brief About Location Information</label>
            <textarea
              name="BriefAboutLocationInformation"
              // value={regdata.ProjectGoals}
              placeholder="Brief About Location Information"
              className="goal-custom"
              value={regdata.BriefAboutLocationInformation}
              onChange={handleChange}
            />
            {errors.BriefAboutLocationInformation && (
              <p className="error">{errors.BriefAboutLocationInformation}</p>
            )}
          </div>
        </div>
        <div className="head">
          <p>Project Funding Details</p>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Estimated Project Cost(UGX)</label>
            <CustomInput
              type={"text"}
              placeholder={"Estimated Project Cost"}
              name={"EstimatedProjectCost"}
              value={regdata.EstimatedProjectCost}
              onChange={handleChange}
            />
            {errors.EstimatedProjectCost && (
              <p className="error">{errors.EstimatedProjectCost}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Enter Funders with Comma seperated</label>
            <CustomInput
              type={"text"}
              placeholder={"Estimated Project Cost"}
              name={"EnterFunderswithCommaseperated"}
              value={regdata.EnterFunderswithCommaseperated}
              onChange={handleChange}
            />
            {errors.EnterFunderswithCommaseperated && (
              <p className="error">{errors.EnterFunderswithCommaseperated}</p>
            )}
          </div>
        </div>
        <div className="head">
          <p>Responsible officer Details</p>
        </div>
        <div className="Pr-form">
          <div className="Pr-input">
            <label>Tittle</label>
            <CustomInput
              type={"text"}
              placeholder={"Tittle"}
              name={"Tittle"}
              value={regdata.Tittle}
              onChange={handleChange}
            />
            {errors.Tittle && <p className="error">{errors.Tittle}</p>}
          </div>
          <div className="Pr-input">
            <label>Name</label>
            <CustomInput
              type={"text"}
              placeholder={"Name"}
              name={"Name"}
              value={regdata.Name}
              onChange={handleChange}
            />
            {errors.Name && <p className="error">{errors.Name}</p>}
          </div>
          <div className="Pr-input">
            <label>Mobile Number</label>
            <CustomInput
              type={"text"}
              placeholder={"Mobile Number"}
              name={"MobileNumber"}
              value={regdata.MobileNumber}
              onChange={handleChange}
            />
            {errors.MobileNumber && (
              <p className="error">{errors.MobileNumber}</p>
            )}
          </div>
          <div className="Pr-input">
            <label>Email</label>
            <CustomInput
              type={"text"}
              placeholder={"Email"}
              name={"Email"}
              value={regdata.Email}
              onChange={handleChange}
            />
            {errors.Email && <p className="error">{errors.Email}</p>}
          </div>
        </div>
        <div className="Pr-but">
          <CustomButton
            onClick={handleSave}
            buttonstyle={"button"}
            ButtonName={"Save&Next"}
          />
        </div>
      </div>
    </div>
  );
};

export default ProjectRegistration;
