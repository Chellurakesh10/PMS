import React, { useState } from "react";
import "./ProjectActivities.css";
import CustomButton from "../../../CustomButton/CustomButton";
import CustomInput from "../../../CustomInput/CustomInput";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import { useNavigate } from "react-router-dom";

const ProjectActivities = () => {
  const [activitiesdData, setActivitiesData1] = useState({
    ProgramName: "",
    ProgramCode: "",
    Outputs: "",
    Lattitude: "",
    Longitude: "",
    Activities: "",
    submitted: false,
  });
  const navigate = useNavigate();
  const [errors, setErrors] = useState("");

  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();

    if (isValid) {
      setActivitiesData1({
        ...activitiesdData,
        submitted: true,
      });
      navigate("/budgetingForm/CoastedAnnualizedPlan", {
        state: { component: "OutputsannualCost" },
      });
    } else {
      alert("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setActivitiesData1({
      ...activitiesdData,
      [name]: value,
    });
  };

  const OutputsOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];
  return (
    <div className="container">
      <div className="Pa-fluid-container">
        <div className="Pa-head">
          <h1>Project Activities</h1>
        </div>
        <div className="Pa-form">
          <div className="Pa-input">
            <label>Program Name:</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"Program Name"}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="Pa-input">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
          <div className="Pa-input">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
            />
            {errors.ProjectName && (
              <p className="error">{errors.ProjectName}</p>
            )}
          </div>
          <div className="Pa-input">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
            />
            {errors.ProjectCode && (
              <p className="error">{errors.ProjectCode}</p>
            )}
          </div>
        </div>
        <div className="Pa-form2">
          <div className="Pa-form3">
            <div className="Pa-info">
              <label>Outputs</label>
              <SelectCustom
                name="Outputs"
                options={OutputsOptions}
                value={activitiesdData.TypesofFrameworks}
                onChange={handleChange}
              />
              {errors.Outputs && <p className="error">{errors.Outputs}</p>}
            </div>
            <div className="Pa-info">
              <label>Activities</label>
              <CustomInput type={"textarea"} placeholder={"Activities"} />
              {errors.Activities && (
                <p className="error">{errors.Activities}</p>
              )}
            </div>
          </div>
        </div>
        <div className="Pa-form">
          <div className="Pa-info">
            <label>Lattitude</label>
            <CustomInput
              type={"text"}
              name={"Lattitude"}
              placeholder={"Lattitude"}
            />
            {errors.Lattitude && <p className="error">{errors.Lattitude}</p>}
          </div>
          <div className="Pa-info">
            <label>Longitude</label>
            <CustomInput
              type={"text"}
              name={"Longitude"}
              placeholder={"Project Code"}
            />
            {errors.Longitude && <p className="error">{errors.Longitude}</p>}
          </div>
          <div className="Pa-info">
            <CustomButton ButtonName={"+Add"}  buttonstyle={"Pa-but1"} />
          </div>
        </div>
        <div className="Pa-form3">
          <CustomButton
            buttonstyle={"Pa-but"}
            onClick={handleNext}
            ButtonName={"Next"}
          />
        </div>
      </div>
    </div>
  );
};

export default ProjectActivities;
