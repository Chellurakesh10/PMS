import React, { useEffect, useState } from "react";
import "./ProjectFrameworks1.css";
import { MdAppRegistration, MdLocalActivity } from "react-icons/md";
import { GoGoal } from "react-icons/go";
import { GrDocumentPerformance } from "react-icons/gr";
import { BsAppIndicator } from "react-icons/bs";
import ProjectActivities from "./ProjectActivities/ProjectActivities";
import ProjectGoalsAndOutcomes from "./ProjectGoalsAndOutcomes/ProjectGoalsAndOutcomes";
import PerfomanceIndicator from "./PerfomanceIndicator/PerfomanceIndicator";
import Indicators from "./Indicators/Indicators";
import ProjectRegistration from "./ProjectRegistration/ProjectRegistration";
import { useLocation } from "react-router-dom";

const ProjectFrameworks1 = () => {
  const tabName = useLocation();
  const [activeComponent, setActiveComponent] = useState("ProjectRegistration"
    ||  tabName.state?.component 
  );

  useEffect(() => {
    console.log("Location state:", tabName.state);

    if (tabName.state?.component && tabName.state.component === activeComponent) {
      setActiveComponent(tabName.state.component);
    }
  },[tabName.state ,activeComponent]);

  const handleButtonClick = (component) => {
    setActiveComponent(component);
    window.history.pushState(null, '', `/budgetingForm/ProjectFrameworks1/${component}`);
  };
  useEffect(() => {
    // Trigger a re-render when activeComponent changes
    console.log("Active component changed:", activeComponent);
  }, [activeComponent]);

  return (
    <div className="frameworkscontainer">
      <div className="frameworksConatiner_fluid">
        <div className="Pf_head">
          <h1>Project Frameworks</h1>
        </div>
        <div className="frame-Form">
          <ul>
            <li>
              <button
                className={activeComponent === "ProjectRegistration" ? "active-link focus" : ""}
                onClick={() => handleButtonClick("ProjectRegistration")}
              >
                <span>
                  <MdAppRegistration />
                  Project Registration
                </span>
              </button>
            </li>
            <li>
              <button
                className={activeComponent === "ProjectGoalsAndOutcomes" ? "active-link focus" : ""}
                onClick={() => handleButtonClick("ProjectGoalsAndOutcomes")}
              >
                <span>
                  <GoGoal />
                  Project Goals And Outcomes
                </span>
              </button>
            </li>
            <li>
              <button
                className={activeComponent === "Indicators" ? "active-link focus" : ""}
                onClick={() => handleButtonClick("Indicators")}
              >
                <span>
                  <BsAppIndicator />
                  Indicators
                </span>
              </button>
            </li>
            <li>
              <button
                className={activeComponent === "PerfomanceIndicator" ? "active-link focus" : ""}
                onClick={() => handleButtonClick("PerfomanceIndicator")}
              >
                <span>
                  <GrDocumentPerformance />
                  Performance Indicators
                </span>
              </button>
            </li>
            <li>
              <button
                className={activeComponent === "ProjectActivities" ? "active-link focus" : ""}
                onClick={() => handleButtonClick("ProjectActivities")}
              >
                <span>
                  <MdLocalActivity />
                  Project Activities
                </span>
              </button>
            </li>
          </ul>
        </div>
        <div className="formbodycontainer">
          {activeComponent === "ProjectRegistration" && <ProjectRegistration />}
          {activeComponent === "ProjectGoalsAndOutcomes" && <ProjectGoalsAndOutcomes />}
          {activeComponent === "Indicators" && <Indicators />}
          {activeComponent === "PerfomanceIndicator" && <PerfomanceIndicator />}
          {activeComponent === "ProjectActivities" && <ProjectActivities />}
        </div>
      </div>
    </div>
  );
};

export default ProjectFrameworks1;
