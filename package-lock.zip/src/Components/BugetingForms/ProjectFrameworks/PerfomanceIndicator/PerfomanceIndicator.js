import React, { useState } from "react";
import "./PerfomanceIndicator.css";
import CustomInput from "../../../CustomInput/CustomInput";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import CustomButton from "../../../CustomButton/CustomButton";
import { useNavigate } from "react-router-dom";

const PerfomanceIndicator = () => {
  const [form1, setForm1] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    TypesofFrameworks: "",
    FrameworksDescription: "",
    IndicatorsList: "",
    TypeIndicatorPerfomance: "",
    SelectFinancialYear: "",
    MeansVerification: "",
    Assumption: "",
    Risks: "",
    submitted: false,
  });

  const navigate = useNavigate();
  const [errors, setErrors] = useState("");

  const validateForm = () => {
    let newErrors = {};
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveNext = (e) => {
    e.preventDefault();
    const isValid = validateForm();

    if (isValid) {
      setForm1({
        ...form1,
        submitted: true,
      });
      navigate("/budgetingForm/ProjectFrameworks1", {
        state: { component: "ProjectActivities" },
      });
    } else {
      alert("Error");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm1({
      ...form1,
      [name]: value,
    });
  };

  const TypesofFrameworksOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  const FrameworksDescriptionOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  const IndicatorsListOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  const TypeIndicatorPerfomanceOptions = [
    { value: "", label: "Select One" },
    { value: "Percentage", label: "Percentage" },
    { value: "Number", label: "Number" },
  ];

  const SelectFinancialYearOptions = [
    { value: "", label: "Select One" },
    { value: "2021", label: "2021" },
    { value: "2022", label: "2022" },
    { value: "2023", label: "2023" },
  ];

  return (
    <div className="container">
      <div className="i-fluid-container">
        <div className="pi-head">
          <h1>Yearly Performance Indicators</h1>
        </div>
        <div className="pi-form">
          <div className="pi-input">
            <label>Program Name:</label>
            <CustomInput
              type="text"
              name="ProgramName"
              placeholder="Program Name"
              value={form1.ProgramName} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-input">
            <label>Program Code:</label>
            <CustomInput
              type="text"
              name="ProgramCode"
              placeholder="Program Code"
              value={form1.ProgramCode} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-input">
            <label>Project Name:</label>
            <CustomInput
              type="text"
              name="ProjectName"
              placeholder="Project Name"
              value={form1.ProjectName} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-input">
            <label>Project Code:</label>
            <CustomInput
              type="text"
              name="ProjectCode"
              placeholder="Project Code"
              value={form1.ProjectCode} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
        </div>

        {/* Form for dropdowns */}
        <div className="pi-form">
          <div className="pi-form1">
            <label>Type of Frameworks</label>
            <SelectCustom
              name="TypesofFrameworks"
              options={TypesofFrameworksOptions}
              value={form1.TypesofFrameworks}
              onChange={handleChange}
            />
            {errors.TypesofFrameworks && (
              <p className="error">{errors.TypesofFrameworks}</p>
            )}
          </div>
          <div className="pi-form1">
            <label>Frameworks Description</label>
            <SelectCustom
              name="FrameworksDescription"
              value={form1.FrameworksDescription}
              options={FrameworksDescriptionOptions}
              onChange={handleChange}
            />
            {errors.FrameworksDescription && (
              <p className="error">{errors.FrameworksDescription}</p>
            )}
          </div>
          <div className="pi-form1">
            <label>Indicators List</label>
            <SelectCustom
              name="IndicatorsList"
              value={form1.IndicatorsList}
              options={IndicatorsListOptions}
              onChange={handleChange}
            />
            {errors.IndicatorsList && (
              <p className="error">{errors.IndicatorsList}</p>
            )}
          </div>
        </div>

        {/* More form fields */}
        <div className="pi-form">
          <div className="pi-form1">
            <label>Select Financial Year</label>
            <SelectCustom
              name="SelectFinancialYear"
              value={form1.SelectFinancialYear}
              options={SelectFinancialYearOptions}
              onChange={handleChange}
            />
            {errors.SelectFinancialYear && (
              <p className="error">{errors.SelectFinancialYear}</p>
            )}
          </div>
          <div className="pi-form1">
            <label>Indicator Performance</label>
            <CustomInput
              type="text"
              placeholder="Indicator Performance"
              name="IndicatorPerfomance"
              value={form1.IndicatorPerfomance} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-form1">
            <label>Type Indicator Performance</label>
            <SelectCustom
              name="TypeIndicatorPerfomance"
              value={form1.TypeIndicatorPerfomance}
              options={TypeIndicatorPerfomanceOptions}
              onChange={handleChange}
            />
            {errors.TypeIndicatorPerfomance && (
              <p className="error">{errors.TypeIndicatorPerfomance}</p>
            )}
          </div>
        </div>

        {/* More form fields */}
        <div className="pi-form">
          <div className="pi-form1">
            <label>Means Verification</label>
            <CustomInput
              type="text"
              placeholder="Means Verification"
              name="MeansVerification"
              value={form1.MeansVerification} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-form1">
            <label>Assumption</label>
            <CustomInput
              type="text"
              placeholder="Assumption"
              name="Assumption"
              value={form1.Assumption} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
          <div className="pi-form1">
            <label>Risks</label>
            <CustomInput
              type="text"
              placeholder="Risks"
              name="Risks"
              value={form1.Risks} // Corrected
              onChange={handleChange} // Added missing onChange
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="find">
          <CustomButton ButtonName={"Add"} />
        </div>
        <div className="pi-but1">
          <CustomButton
            buttonstyle="pi-but"
            onClick={handleSaveNext}
            ButtonName="Next"
          />
        </div>
      </div>
    </div>
  );
};

export default PerfomanceIndicator;
