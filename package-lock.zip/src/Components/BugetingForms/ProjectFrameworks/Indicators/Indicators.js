import React, { useState } from "react";
import "./Indicators.css";
import SelectCustom from "../../../SelectCustom/SelectCustom";
import CustomInput from "../../../CustomInput/CustomInput";
import CustomButton from "../../../CustomButton/CustomButton";
import { useNavigate } from "react-router-dom";

const Indicators = () => {
  const [form2, setForm22] = useState({
    ProgramName: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    TypesofFrameworks: "",
    FrameworksDescription: "",
    Indicators: [""], // Initial array to handle multiple indicators
    submitted: false,
  });

  const navigate = useNavigate();
  const [errors, setErrors] = useState("");

  const validateForm = () => {
    let newErrors = {};

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();

    if (isValid) {
      setForm22({
        ...form2,
        submitted: true,
      });
      navigate("/budgetingForm/ProjectFrameworks1", {
        state: { component: "PerfomanceIndicator" },
      });
    } else {
      alert("Filled Correctly");
    }
  };

  const handleChange = (e, index = null) => {
    const { name, value } = e.target;

    if (name === "Indicators") {
      const newIndicators = [...form2.Indicators];
      newIndicators[index] = value;
      setForm22({
        ...form2,
        Indicators: newIndicators,
      });
    } else {
      setForm22({
        ...form2,
        [name]: value,
      });
    }
  };

  const handleAddIndicator = () => {
    setForm22({
      ...form2,
      Indicators: [...form2.Indicators, ""],
    });
  };

  const handleDeleteIndicator = (index) => {
    const newIndicators = [...form2.Indicators];
    newIndicators.splice(index, 1);
    setForm22({
      ...form2,
      Indicators: newIndicators,
    });
  };

  const TypesofFrameworksOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  const FrameworksDescriptionOptions = [
    { value: "", label: "Select One" },
    { value: "Goals", label: "Goals" },
    { value: "Outcomes", label: "Outcomes" },
    { value: "Outputs", label: "Outputs" },
  ];

  return (
    <div className="indicatorcontainer">
      <div className="ind-fluid-container">
        <div className="ind-head">
          <h1>Indicators</h1>
        </div>
        <div className="ind-put">
          <div className="ind-form">
            <label>Program Name :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              placeholder={"Program Name"}
              value={form2.ProgramName}
              onChange={handleChange}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="ind-form">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              placeholder={"Program Code"}
              value={form2.ProgramCode}
              onChange={handleChange}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
          <div className="ind-form">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              placeholder={"Project Name"}
              value={form2.ProjectName}
              onChange={handleChange}
            />
            {errors.ProjectName && (
              <p className="error">{errors.ProjectName}</p>
            )}
          </div>
          <div className="ind-form">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              placeholder={"Project Code"}
              value={form2.ProjectCode}
              onChange={handleChange}
            />
            {errors.ProjectCode && (
              <p className="error">{errors.ProjectCode}</p>
            )}
          </div>
        </div>
        <div className="ind-put">
          <div className="ind-form">
            <label>Types of Frameworks</label>
            <SelectCustom
              name="TypesofFrameworks"
              options={TypesofFrameworksOptions}
              value={form2.TypesofFrameworks}
              onChange={handleChange}
            />
            {errors.TypesofFrameworks && (
              <p className="error">{errors.TypesofFrameworks}</p>
            )}
          </div>
          <div className="ind-form">
            <label>Frameworks Description</label>
            <SelectCustom
              name="FrameworksDescription"
              value={form2.FrameworksDescription}
              options={FrameworksDescriptionOptions}
              onChange={handleChange}
            />
            {errors.FrameworksDescription && (
              <p className="error">{errors.FrameworksDescription}</p>
            )}
          </div>
          <div className="ind-form">
            <label>Indicators</label>
            {form2.Indicators.map((indicator, index) => (
              <div key={index} className="indicator-row">
                <CustomInput
                  type={"text"}
                  name={"Indicators"}
                  value={indicator}
                  placeholder={"Indicator"}
                  onChange={(e) => handleChange(e, index)}
                />
                {form2.Indicators.length > 1 && (
                  <button
                    type="button"
                    className="delete-button"
                    onClick={() => handleDeleteIndicator(index)}
                  >
                    Delete
                  </button>
                )}
              </div>
            ))}
            <CustomButton
              buttonstyle={"fig"}
              ButtonName={"+Add"}
              onClick={handleAddIndicator}
            />
          </div>
        </div>
        <div className="ind-but">
          <CustomButton
            buttonstyle={"dump"}
            onClick={handleSaveNext}
            ButtonName={"Next"}
          />
        </div>
      </div>
    </div>
  );
};

export default Indicators;
