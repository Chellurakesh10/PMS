import React, { useState } from "react";
import "./ProjectGoalsAndOutcomes.css";
import { MdOutlineAdd } from "react-icons/md";
import { MdDelete } from "react-icons/md";
import CustomInput from "../../../CustomInput/CustomInput";
import CustomButton from "../../../CustomButton/CustomButton";
import { useNavigate } from "react-router-dom";

const ProjectGoalsAndOutcomes = () => {
  const navigate = useNavigate();
  const [formdata, setFormdata] = useState({
    Program: "",
    ProgramCode: "",
    ProjectName: "",
    ProjectCode: "",
    ProjectGoals: "",
    Outcomes: [""],
    ComponentOutputs: [""],
    Submitted: false,
  });

  const [errors, setErrors] = useState("");

  const validateForm = () => {
    let newErrors = {};
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSaveNext = (e) => {
    e.preventDefault();

    const isValid = validateForm();
    if (isValid) {
      setFormdata({
        ...formdata,
        Submitted: false,
      });

      navigate("/budgetingForm/ProjectFrameworks1", {
        state: { component: "Indicators" },
      });
    } else {
      alert("Form Failed");
    }
  };

  const handleChange = (e, index = 1, type = null) => {
    const { name, value } = e.target;

    if (type === "Outcomes") {
      const newOutcomes = [...formdata.Outcomes];
      newOutcomes[index] = value;
      setFormdata({
        ...formdata,
        Outcomes: newOutcomes,
      });
    } else if (type === "ComponentOutputs") {
      const newComponentOutputs = [...formdata.ComponentOutputs];
      newComponentOutputs[index] = value;
      setFormdata({
        ...formdata,
        ComponentOutputs: newComponentOutputs,
      });
    } else {
      setFormdata({
        ...formdata,
        [name]: value,
      });
    }
  };

  const handleAddRow = (type) => {
    if (type === "Outcomes") {
      setFormdata({
        ...formdata,
        Outcomes: [...formdata.Outcomes, ""],
      });
    } else if (type === "ComponentOutputs") {
      setFormdata({
        ...formdata,
        ComponentOutputs: [...formdata.ComponentOutputs, ""],
      });
    }
  };

  const handleDeleteRow = (index, type) => {
    if (type === "Outcomes") {
      const newOutcomes = [...formdata.Outcomes];
      newOutcomes.splice(index, 1);
      setFormdata({
        ...formdata,
        Outcomes: newOutcomes,
      });
    } else if (type === "ComponentOutputs") {
      const newComponentOutputs = [...formdata.ComponentOutputs];
      newComponentOutputs.splice(index, 1);
      setFormdata({
        ...formdata,
        ComponentOutputs: newComponentOutputs,
      });
    }
  };

  return (
    <div className="container">
      <div className="pgo-fluid-container">
        <div className="goal-info">
          <h1>Project Goal And Outcomes</h1>
        </div>
        <div className="goal-form">
          <div className="goal-input">
            <label>Program Name :</label>
            <CustomInput
              type={"text"}
              name={"ProgramName"}
              value={formdata.ProgramName}
              placeholder={"ProgramName"}
              onChange={handleChange}
            />
            {errors.ProgramName && (
              <p className="error">{errors.ProgramName}</p>
            )}
          </div>
          <div className="goal-input">
            <label>Program Code :</label>
            <CustomInput
              type={"text"}
              name={"ProgramCode"}
              value={formdata.ProgramCode}
              placeholder={"Program Code"}
              onChange={handleChange}
            />
            {errors.ProgramCode && (
              <p className="error">{errors.ProgramCode}</p>
            )}
          </div>
          <div className="goal-input">
            <label>Project Name :</label>
            <CustomInput
              type={"text"}
              name={"ProjectName"}
              value={formdata.ProjectName}
              placeholder={"Project Name"}
              onChange={handleChange}
            />
            {errors.ProjectName && (
              <p className="error">{errors.ProjectName}</p>
            )}
          </div>
          <div className="goal-input">
            <label>Project Code :</label>
            <CustomInput
              type={"text"}
              name={"ProjectCode"}
              value={formdata.ProjectCode}
              placeholder={"Project Code"}
              onChange={handleChange}
            />
            {errors.ProjectCode && (
              <p className="error">{errors.ProjectCode}</p>
            )}
          </div>
        </div>
        <div className="outcomes-info">
          <label>Project Goals :</label>
          <textarea
            name="ProjectGoals"
            value={formdata.ProjectGoals}
            placeholder="Project Goals"
            className="goal-custom"
            onChange={handleChange}
          />
          {errors.ProjectGoal && <p className="error">{errors.ProjectGoal}</p>}
        </div>
        <div className="goal-table">
          <div className="outcomes-table">
            <table>
              <tbody>
                <tr>
                  <th>Outcomes</th>
                  <th>Add/Delete</th>
                </tr>
                {formdata.Outcomes.map((outcome, index) => (
                  <tr key={index}>
                    <td>
                      <CustomInput
                        type={"text"}
                        name={"Outcomes"}
                        value={outcome}
                        placeholder={"Outcomes"}
                        onChange={(e) => handleChange(e, index, "Outcomes")}
                      />
                    </td>
                    <td>
                      <button onClick={() => handleAddRow("Outcomes")}>
                        <MdOutlineAdd />
                      </button>
                      <button
                        onClick={() => handleDeleteRow(index, "Outcomes")}
                      >
                        <MdDelete />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="goal-table">
          <div className="outcomes-table">
            <table>
              <tbody>
                <tr>
                  <th>Component/Outputs</th>
                  <th>Add/Delete</th>
                </tr>
                {formdata.ComponentOutputs.map((component, index) => (
                  <tr key={index}>
                    <td>
                      <CustomInput
                        type={"text"}
                        name={"Component/Outputs"}
                        value={component}
                        placeholder={"description of Components/Output"}
                        onChange={(e) =>
                          handleChange(e, index, "ComponentOutputs")
                        }
                      />
                    </td>
                    <td>
                      <button onClick={() => handleAddRow("ComponentOutputs")}>
                        <MdOutlineAdd />
                      </button>
                      <button
                        onClick={() =>
                          handleDeleteRow(index, "ComponentOutputs")
                        }
                      >
                        <MdDelete />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="goal-button">
          <CustomButton
            onClick={handleSaveNext}
            buttonstyle={"button"}
            ButtonName={"Save&next"}
          />
        </div>
      </div>
    </div>
  );
};

export default ProjectGoalsAndOutcomes;
